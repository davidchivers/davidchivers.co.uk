# Your outputs

Ask the assistant to save the slide you make in this folder. Open the generated
HTML in a browser and compare its chart, labels and calculations with the notes.
