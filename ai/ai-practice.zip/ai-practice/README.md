# Try AI beyond the chat

Make one interactive slide, then try a study coach. Use these invented examples
to practise; follow your assessment instructions for assessed work.

This is optional practice. For everyday study, start with [Ask Durham](https://ask.durham.ac.uk/)
or [Microsoft 365 Copilot Chat](https://m365.cloud.microsoft/) using your Durham account.
**You do not need to buy an AI subscription.** The activities below use the separate
GitHub Copilot student benefit in VS Code. While waiting for access, you can
[explore the prepared example](reference/study-slides.html) in your browser.

<div id="download-route" class="intro-box">
You have the practice folder. Open <strong>START-HERE.html</strong> in your browser
for this guide with copy buttons. Keep it open beside VS Code.
</div>

## Get ready

1. **Extract the ZIP.** On Windows, right-click it and choose **Extract All**.
   On a Mac, double-click it. Work in the extracted folder.
2. **Open the folder in VS Code:** File → Open Folder → **ai-practice**.
   Choose the folder containing `README.md`, `notes` and `START-HERE.html`,
   rather than opening a single file.
3. **Open the chat and select Agent.** Sign in to GitHub Copilot with the
   account that has your student access. If a model picker is shown, Auto is
   a reasonable starting point when available.

If VS Code shows **Restricted Mode**, review this supplied folder, then use
**Manage** in the banner to trust it if you are happy with its contents.
Copilot needs a trusted workspace for this exercise.

Need VS Code or Copilot first? Follow the
[setup guide](https://davidchivers.co.uk/ai_install/).
You need internet access for Copilot. **No Quarto, LaTeX, Python or other
software is needed for this practice.**

## 1. Make a slide

A *skill* is a saved method the assistant can reuse. Paste this into the chat:

> Use the study-slides skill and the spending example in notes/slide-examples.md.
> Make one slide with a button to switch between pounds and percentage growth.
> Save it as outputs/spending-chart.html. Keep it simple: no animation or installs.
> Check the values and buttons, then give me a link to open the file.

It may take a few minutes. Look for a permission request if it seems to be
waiting: read the proposed action before allowing it. You do not need to turn
off approvals.

**Open the result:** follow the file link in the reply. If you see HTML code
instead of a slide, find `outputs/spending-chart.html` in File Explorer or Finder
and open it with your usual web browser. Refresh that browser tab after edits.

**Check it:** does the switch change the units and scale? Which category has the
larger increase in pounds, and which has the larger percentage increase?

<details>
<summary>Check your answer</summary>

Food rises from £240 to £300: **£60, or 25%**. Energy rises from £80 to £120:
**£40, or 50%**. Food has the larger cash increase; energy the larger percentage
increase. The chart should use £0–£400 for pounds and 0–60% for growth, with both
growth lines starting at zero. These are invented spending figures, not inflation
estimates.

</details>

Want to change it? Ask in your own words: “Make the labels larger” or “Add a
short transition when I press the button.” Recheck both views after a change.

<details>
<summary>Explore a prepared example while you wait</summary>

[Open the example slides](reference/study-slides.html). Try the spending switch,
score distributions, worked calculation and revealable answer. This file works
without Copilot or an internet connection once downloaded. It is a prepared
example: your generated slide will look different and needs its own checks.

</details>

## 2. Try a study coach

An *agent* has a saved role and a set of tools. Start a **new chat**, then choose
**Study coach** from the agent picker, where you selected Agent. Paste:

> Read notes/slide-examples.md. I can follow the standard deviation calculation,
> but I don't understand why we square the differences. Help me reason it
> through. Ask one question and wait for my attempt before explaining.

Answer its question. Ask for a hint, challenge its explanation or say where you
are stuck. The point is to work through the idea, not just receive an answer.

Study coach can read and discuss your files. **Switch back to Agent to edit
them.** You can ask it to adapt the skill or coach for another subject, then
inspect the changed instructions and try them in a new chat.

<details>
<summary>Optional: save a preference for next time</summary>

A fresh chat will not necessarily know your earlier decisions. Ask Agent:

> Save a short project note in notes/project-memory.md: use cream, teal and
> orange. Next time, check that both chart views have the right axis labels.

Then start a new chat and ask:

> Read notes/project-memory.md and tell me our design choice and next check.

Open the saved note to see what it recorded. This is memory in a file that you
ask it to read, rather than an assumption that it remembers every chat.

</details>

## Stuck?

<details>
<summary>I cannot see Copilot, Agent or my student access</summary>

Check the [setup guide](https://davidchivers.co.uk/ai_install/) and that you are
signed into the intended GitHub account. The folder recommends the GitHub
Copilot Chat extension; accepting that recommendation does not sign you in or
activate student access. If access is pending or you reach a usage limit, explore
the prepared example and its notes for now. You do not need to buy a plan to
read this material. Your organisation may control which features are available.

</details>

<details>
<summary>It cannot find the skill or Study coach</summary>

Check that you opened the extracted **ai-practice** folder, not the ZIP, its
parent folder or an individual file. Use a current version of VS Code and the
GitHub Copilot Chat extension. In versions with a session-target picker, choose
the local Copilot session for these exercises.

For the skill, type `/study-slides`, or ask it to read and follow
`.github/skills/study-slides/SKILL.md` explicitly.

For the coach, start a new chat and look in the agent picker. Its instructions
are in `.github/agents/study-coach.agent.md`. You can attach that file to a normal
chat to try the tutoring style, but that does not give the chat the custom
agent's read-only tool configuration.

</details>

<details>
<summary>It has stopped, wants permission or proposes an installation</summary>

Read any request waiting in the chat. A request to read files, edit the requested
output or open that output for checking may be part of the task. Approve only an
action you understand and want; an approval may cover just that action or the
session, depending on the prompt. Keep the normal approval settings.

This exercise needs no extra software. If it proposes an installation, decline
and ask: “Use one self-contained HTML file with no installs or external libraries.”
If a tool fails, ask it to explain the error and use a simpler approach. If it
cannot check the browser itself, open the result and use the checks above.

</details>

<details>
<summary>The slide is blank, broken or has the wrong numbers</summary>

Check that you opened the generated file in `outputs`, then refresh the browser.
Tell Agent what you expected and what happened, for example: “The percentage
button does nothing. Fix it and recheck both views.” Include any visible error
text. Ask it to compare the result with `notes/slide-examples.md`.

You can still use the prepared example if generation fails. A plausible-looking
slide is not proof that its calculations or controls work.

</details>

<details>
<summary>What is in the folder? Is it uploaded to GitHub?</summary>

The `.github` folder holds Copilot's skill and agent instructions. It does not
upload anything to GitHub. The files stay in your local folder, although Copilot
can send relevant content to its online service. The supplied data are invented;
do not add private or restricted material without checking the applicable rules.

The `.vscode` folder contains a few display settings: wrapped text, no minimap
or sticky headings, and readable Markdown maths. It recommends Copilot Chat.
It contains no account details, paid model selection or changes to permissions.
These are folder settings; they do not copy the lecturer's personal profile.

You can read the [skill](.github/skills/study-slides/SKILL.md),
[coach instructions](.github/agents/study-coach.agent.md) and
[example notes](notes/slide-examples.md). Copilot needs internet access; the
downloaded guide and prepared HTML example do not.

</details>

<details>
<summary>Can I use Quarto later?</summary>

Yes. Ask explicitly for Quarto if you want editable `.qmd` slides. Unlike this
HTML exercise, rendering Quarto needs the Quarto application installed. Start
with a plain theme and your own details.
[Quarto presentations](https://quarto.org/docs/presentations/revealjs/).

For current tool help, see VS Code's
[custom agents](https://code.visualstudio.com/docs/agent-customization/custom-agents)
and [approval controls](https://code.visualstudio.com/docs/agents/run/approvals).

</details>
