# AI practice

One slide-making skill and one study-coach agent, with interactive examples.
This is for practice. Use your assessment instructions for assessed work.

## Open the folder

Unzip the download. In VS Code, use File > Open Folder and select
`ai-practice`, the folder containing this README and `.github`.
Sign in to GitHub Copilot with the account that has your student benefit.
[Setup guide](https://davidchivers.co.uk/ai_install/).

You do not need to upload your folder to GitHub or install extra document
software for this example. The files are on your computer; Copilot can send relevant content
to its service. These supplied notes contain no personal data.

## 1. Make slides with the skill

Open Copilot Chat, select Agent, then ask:

> Use study-slides with notes/slide-examples.md. Make a spending-chart slide
> with a pounds/percentage-growth switch. Save the HTML in outputs.
> Open it and help me check it.

The reusable method is `.github/skills/study-slides/SKILL.md`.
You can also type `/study-slides` to select it. If it is not discovered, attach
that file or explicitly ask the assistant to read and follow it.

First open `reference/study-slides.html`: switch spending between pounds and percentage growth,
reveal the score distributions, walk through an equation and reveal an answer.
This is a prepared showcase, not a live preview of your generated file. It is
one HTML file with its presentation code and diagrams included; opening it
does not require Quarto. You can start by making just one of these features.

Review requested permissions and file changes. Open your generated HTML in a
browser and compare it with `notes/slide-examples.md`. Food spending rises by £60 (25%); energy spending rises by £40 (50%).
Both score groups average 50, but their standard deviations differ. Check the chart data, controls and any explanation as well.

## 2. Try the Study coach agent

Start a new Copilot chat. Choose Study coach from the agent picker and ask:

> Read notes/slide-examples.md. I'm trying to understand standard deviation.
> I can follow the calculation, but I'm unsure why we square the differences.
> Help me reason it through without just telling me.

Describe your own learning goal and where you are stuck. As you go, ask for a
hint, a different explanation or feedback on your attempt. You can ask the
standard Agent to help write or adapt the tutor's saved instructions for your
subject and the kind of support you want.
Its role and read-only tools are
configured in `.github/agents/study-coach.agent.md`. If it is missing, check you
opened the extracted root folder and that VS Code and Copilot are up to date.
You can attach the instruction file in a normal chat to try the tutoring style,
but that alone does not activate the custom agent's tool restrictions.

## Adapt it

Return to Agent when you want to edit a skill, agent or output file. For example:
"Add a staged calculation to my slides."
Or: "Make Study coach check my assumptions before my algebra."
Inspect the edited instruction file, then try it in a new chat.

For Quarto slides, ask for that format explicitly. Quarto must be installed to
render the `.qmd` source; the agent should explain what is available before
promising an HTML output. Use a plain theme and your own details.
[Quarto presentations](https://quarto.org/docs/presentations/revealjs/).

## Your next step

Ask Agent to record your decisions and next step here, keeping this guide.
For example: "Keep the cream, teal and orange design. Next time, check that my
spending chart updates its axis labels when switching between pounds and
percentage growth."
In a later chat, ask it to read this README before continuing.

Prepared example files have been checked locally. The revised pack has not yet
been rehearsed through Copilot using a student's account.
