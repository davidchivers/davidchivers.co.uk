EDITABLE QUARTO READING EXAMPLE

Open reading.qmd to edit the lesson. Keep reading.css, budget-comparison.svg and assets/ beside it.
Render with: quarto render reading.qmd
Verified with Quarto 1.10.18 on 19 October 2026.

The rendered HTML embeds fonts, the logo, diagram and mathematics. It can be read independently of these source files. Links to the interactive studio, design notes and original course require their corresponding pages or internet access.

This is newly written illustrative content for a proposed companion to the existing MSc preparation course. It is not a transcript of the original video or a replacement for approved course content. The original course is unchanged.
