"""Approved two-column 2019 geography audit; detailed diagnostics stay private."""

import argparse
import json
import math
from numbers import Integral, Real
import time
from datetime import datetime, timezone
from pathlib import Path

import duckdb
import pyarrow.parquet as pq

from metro_population_reference import read_membership, read_county_populations
from prepare_metro_population_reference import PROJECT, digest, outside_repo, verify_sources
from run_within_venue_measurement_audit import literal, sha256
from venue_count_pilot import SOURCE_HASHES


PROTOCOL = 'docs/protocols/metro_assignment_check_20261019.md'


def normalized_area_sql():
    # Strip only an all-zero fractional part; integer casts could round bad keys.
    raw = 'CAST(MSA_CODE AS VARCHAR)'
    return (f"CASE WHEN regexp_full_match({raw}, '[1-9][0-9]{{4}}(\\.0+)?') "
            f"THEN substr({raw}, 1, 5) ELSE {raw} END")


def classify_sql():
    return """
      SELECT CASE
        WHEN county IS NULL OR NOT regexp_full_match(county, '[0-9]{5}')
          THEN 'missing_or_malformed_county'
        WHEN county_scope.fips IS NULL THEN 'outside_US2019_county_reference'
        WHEN msa IS NULL OR NOT regexp_full_match(msa, '[1-9][0-9]{4}')
          THEN 'missing_or_malformed_recorded_area'
        WHEN county_map.cbsa IS NULL THEN 'county_outside_CBSA'
        WHEN area_map.cbsa IS NULL THEN 'recorded_code_outside_delineation'
        WHEN county_map.cbsa <> msa THEN 'county_recorded_code_conflict'
        ELSE 'compatible' END AS status, msa, county, n_rows
      FROM input_pairs
      LEFT JOIN county_scope ON input_pairs.county = county_scope.fips
      LEFT JOIN county_map ON input_pairs.county = county_map.fips
      LEFT JOIN area_map ON input_pairs.msa = area_map.cbsa
    """


def candidate(profile, total):
    def valid_count(value):
        if isinstance(value, bool):
            return False
        return ((isinstance(value, Integral) and value >= 0) or
                (isinstance(value, Real) and math.isfinite(value) and
                 value >= 0 and int(value) == value))

    invalid = {'release_screen_passed': False, 'reason': 'binary_profile_support_or_total'}
    expected = {'compatible', 'not_demonstrated_compatible'}
    if not valid_count(total) or total == 0 or not isinstance(profile, list) or len(profile) != 2:
        return invalid
    if any(not isinstance(row, dict) or set(row) != {'group', 'n_rows', 'n_recorded_areas'} or
           not isinstance(row['group'], str) or
           not valid_count(row['n_rows']) or not valid_count(row['n_recorded_areas']) or
           row['n_recorded_areas'] > row['n_rows'] for row in profile):
        return invalid
    groups = {row['group']: row for row in profile}
    if set(groups) != expected or sum(int(row['n_rows']) for row in profile) != total:
        return invalid
    total = int(total)
    if any(int(row['n_rows']) < 1000 or int(row['n_recorded_areas']) < 20 for row in profile):
        return {'release_screen_passed': False, 'reason': 'whole_profile_withheld_small_support'}
    return {'release_screen_passed': True, 'year': 2019,
            'classification_reference': 'September 2018; US50DC',
            'rows_total': total,
            'groups': [{'group': name, 'rows': int(groups[name]['n_rows']),
                        'percent': 100 * int(groups[name]['n_rows']) / total}
                       for name in ['compatible', 'not_demonstrated_compatible']],
            'independent_review': 'pending', 'full_geolocation_or_source_vintage_validated': False,
            'scope': 'one_national_binary_profile_no_private_codes_or_weighted_outcomes'}


def run(config_path, public_source, output):
    start = time.perf_counter()
    config_path, public_source, output = map(outside_repo, (config_path, public_source, output))
    config = json.loads(config_path.read_text(encoding='utf-8'))
    sources = [s for s in config['sources'] if int(s['year']) == 2019]
    if len(sources) != 1:
        raise ValueError('Expected exactly one approved 2019 source')
    source = outside_repo(sources[0]['path'])
    if source.name != 'poi_indices_harmonized_2019.parquet':
        raise ValueError('Not the approved final source')
    if output.exists() or source == output or source in output.parents:
        raise ValueError('Use a new separate private output')
    before = source.stat()
    if sha256(source) != SOURCE_HASHES[2019]:
        raise ValueError('Approved source fingerprint differs')
    with pq.ParquetFile(source) as parquet:
        expected_rows = parquet.metadata.num_rows
    public_manifest = verify_sources(public_source)
    files = ['code/analysis/audit_poi_metro_assignment.py', 'code/analysis/metro_population_reference.py',
             'code/analysis/prepare_metro_population_reference.py',
             'docs/protocols/metro_population_reference_20261019.md', PROTOCOL]
    hashes = {name: digest(PROJECT / name) for name in files}
    county_scope = read_county_populations(public_source / 'county_population_2019.csv')[['fips']]
    output.mkdir(parents=True, exist_ok=False)
    con = duckdb.connect()
    try:
        con.execute("SET threads=4")
        con.execute("SET memory_limit='2GB'")
        con.execute('SET temp_directory=' + literal(output / 'spill'))
        con.execute("CREATE TABLE input_pairs AS SELECT " + normalized_area_sql() + " AS msa, "
                    "CAST(destination_county AS VARCHAR) AS county, COUNT(*)::BIGINT AS n_rows "
                    "FROM read_parquet(" + literal(source) + ") GROUP BY 1,2")
        if int(con.execute('SELECT SUM(n_rows) FROM input_pairs').fetchone()[0]) != expected_rows:
            raise ValueError('Footer and scan row counts disagree')
        con.register('county_scope', county_scope)
        private_reports, primary_profile = {}, None
        for year in [2013, 2018, 2020]:
            members = read_membership(public_source / f'delineation_{year}.xls', year)
            us = members.loc[members.scope.eq('US50DC')]
            con.register('county_map', us[['fips', 'cbsa']])
            con.register('area_map', us[['cbsa']].drop_duplicates())
            con.execute('CREATE OR REPLACE TEMP VIEW classified AS ' + classify_sql())
            detailed = output / f'private_county_code_diagnostics_{year}.parquet'
            con.execute('COPY (SELECT * FROM classified) TO ' + literal(detailed) + ' (FORMAT PARQUET)')
            private_reports[str(year)] = con.execute(
                'SELECT status, SUM(n_rows)::BIGINT AS n_rows FROM classified GROUP BY status ORDER BY status'
            ).fetchdf().to_dict('records')
            if year == 2018:
                primary_profile = con.execute("""SELECT CASE WHEN status='compatible' THEN 'compatible'
                  ELSE 'not_demonstrated_compatible' END AS "group", SUM(n_rows)::BIGINT AS n_rows,
                  COUNT(DISTINCT CASE WHEN regexp_full_match(msa, '[1-9][0-9]{4}')
                    THEN msa ELSE NULL END)::BIGINT AS n_recorded_areas
                  FROM classified GROUP BY 1 ORDER BY 1""").fetchdf().to_dict('records')
        after = source.stat()
        if (before.st_size, before.st_mtime_ns) != (after.st_size, after.st_mtime_ns):
            raise ValueError('Input changed during scan')
        verify_sources(public_source)
        if any(digest(PROJECT / name) != value for name, value in hashes.items()):
            raise ValueError('Execution code or protocol changed')
        release = candidate(primary_profile, expected_rows)
        receipt = {'completed_utc': datetime.now(timezone.utc).isoformat(),
                   'scope': 'approved_final_2019_two_column_geography_check_only',
                   'source_sha256': SOURCE_HASHES[2019], 'source_bytes': before.st_size,
                   'source_size_mtime_unchanged': True, 'source_rows': expected_rows,
                   'source_columns': ['MSA_CODE', 'destination_county'],
                   'public_source_hashes': {r['file']: r['sha256'] for r in public_manifest['sources']},
                   'execution_sha256': hashes, 'private_status_counts': private_reports,
                   'private_primary_support': primary_profile,
                   'elapsed_seconds': time.perf_counter() - start,
                   'new_annual_flow_or_acs_access': False, 'originals_changed': False,
                   'full_geolocation_or_source_vintage_validated': False}
        for name, data in [('private_receipt.json', receipt), ('national_candidate.json', release)]:
            with (output / name).open('x', encoding='utf-8') as stream:
                json.dump(data, stream, indent=2, allow_nan=False)
                stream.write('\n')
        print('Two-column geography audit complete; candidate remains private pending review. No codes or rows emitted.')
    finally:
        con.close()


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--config', required=True, type=Path)
    parser.add_argument('--public-source', required=True, type=Path)
    parser.add_argument('--output', required=True, type=Path)
    args = parser.parse_args()
    try:
        run(args.config, args.public_source, args.output)
    except Exception as exc:
        print('Geography audit stopped: ' + type(exc).__name__ + '. No private values or paths emitted.')
        raise SystemExit(1) from None
