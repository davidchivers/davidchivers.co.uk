"""Small artificial tests, independent of any mobility inputs."""

import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import pandas as pd

import metro_population_reference as m


def fixture():
    membership = m.validate_membership(pd.DataFrame([
        ['10180', 'Example, AL', 'Metropolitan Statistical Area', '01', '001'],
        ['10180', 'Example, AL', 'Metropolitan Statistical Area', '01', '003'],
        ['20000', 'Small, AK', 'Micropolitan Statistical Area', '02', '013'],
        ['30000', 'Puerto Rico example', 'Metropolitan Statistical Area', '72', '001'],
    ], columns=['cbsa', 'name', 'type', 'state', 'county']))
    counties = pd.DataFrame([['01001', '01', 100, 105, 110],
                             ['01003', '01', 200, 210, 220],
                             ['02013', '02', 50, 55, 60]],
                            columns=['fips', 'state', '2017', '2018', '2019'])
    totals = pd.DataFrame([['10180', 'Example, AL', 'Metropolitan Statistical Area', 300, 315, 330],
                           ['20000', 'Small, AK', 'Micropolitan Statistical Area', 50, 55, 60]],
                          columns=['cbsa', 'name', 'type', '2017', '2018', '2019'])
    components = counties[['fips', '2017', '2018', '2019']].copy()
    components['cbsa'] = ['10180', '10180', '20000']
    return membership, counties, totals, components


class ReferenceTests(unittest.TestCase):
    def test_normalized_codes(self):
        self.assertEqual(m.code('1', 2), '01')
        self.assertEqual(m.code('001', 3), '001')

    def test_invalid_codes(self):
        for value in ('', 'nan', '-1', '12.5', '1e2', '123456'):
            with self.subTest(value=value), self.assertRaises(ValueError):
                m.code(value, 5)

    def test_invalid_populations(self):
        for value in ('', 'nan', '-1', '0', '1.1', '1e9'):
            with self.subTest(value=value), self.assertRaises(ValueError):
                m.positive_integer(value)

    def test_unique_county_even_if_duplicate_is_identical(self):
        a, *_ = fixture()
        with self.assertRaises(ValueError):
            m.validate_membership(pd.concat([a, a.iloc[:1]]))

    def test_ambiguous_type(self):
        a, *_ = fixture()
        a.loc[1, 'type'] = 'Micropolitan Statistical Area'
        with self.assertRaises(ValueError):
            m.validate_membership(a)

    def test_ambiguous_title(self):
        a, *_ = fixture()
        a.loc[1, 'name'] = 'Different'
        with self.assertRaises(ValueError):
            m.validate_membership(a)

    def test_unknown_scope(self):
        a, *_ = fixture()
        a.loc[1, 'state'] = '99'
        with self.assertRaises(ValueError):
            m.validate_membership(a)

    def test_county_not_state_total(self):
        a, *_ = fixture()
        a.loc[0, 'county'] = '000'
        with self.assertRaises(ValueError):
            m.validate_membership(a)

    def test_reconciles_three_years_and_excludes_pr(self):
        result = m.reconcile(*fixture())
        self.assertEqual(len(result), 6)
        self.assertEqual(set(result.cbsa), {'10180', '20000'})
        self.assertEqual(set(result.population_year), {2017, 2018, 2019})
        self.assertEqual(set(result.boundary_vintage), {'September 2018'})
        self.assertEqual(set(result.population_vintage), {2019})
        self.assertEqual(set(result.scope), {'US50DC'})
        self.assertEqual(result.loc[result.cbsa.eq('10180'), 'population'].tolist(), [300, 315, 330])

    def test_component_mismatch_stops(self):
        a, b, c, d = fixture()
        d.loc[0, '2019'] += 1
        with self.assertRaises(ValueError):
            m.reconcile(a, b, c, d)

    def test_total_mismatch_stops(self):
        a, b, c, d = fixture()
        c.loc[0, '2018'] += 1
        with self.assertRaises(ValueError):
            m.reconcile(a, b, c, d)

    def test_missing_county_stops(self):
        a, b, c, d = fixture()
        with self.assertRaises(ValueError):
            m.reconcile(a, b.iloc[1:], c, d)

    def test_county_membership_disagreement_stops(self):
        a, b, c, d = fixture()
        d.loc[0, 'cbsa'] = '20000'
        with self.assertRaises(ValueError):
            m.reconcile(a, b, c, d)

    def test_same_code_changed_counties_not_same_object(self):
        a, b, *_ = fixture()
        changed = a.copy()
        changed.loc[changed.fips.eq('01003'), ['county', 'fips']] = ['005', '01005']
        b = pd.concat([b, pd.DataFrame([['01005', '01', 500, 500, 500]], columns=b.columns)])
        comparison, summary = m.compare_memberships(a, changed, b, 2013, 2018)
        self.assertEqual(summary['common_changed_county_sets'], 1)
        self.assertEqual(summary['common_metro_changed_county_sets'], 1)
        row = comparison.loc[comparison.cbsa.eq('10180')].iloc[0]
        self.assertAlmostEqual(row.population_pct_difference, 100 * (610 / 330 - 1))

    def test_missing_historical_county_is_not_imputed(self):
        a, b, *_ = fixture()
        changed = a.copy()
        changed.loc[changed.fips.eq('01003'), ['county', 'fips']] = ['005', '01005']
        comparison, summary = m.compare_memberships(a, changed, b, 2013, 2018)
        row = comparison.loc[comparison.cbsa.eq('10180')].iloc[0]
        self.assertEqual(row.right_missing_2019_county_keys, '01005')
        self.assertTrue(pd.isna(row.right_population_2019_on_county_2019))
        self.assertTrue(pd.isna(row.population_pct_difference))
        self.assertEqual(summary['common_incomplete_county_population'], 1)

    def test_type_changes_are_separate_from_membership(self):
        a, b, *_ = fixture()
        changed = a.copy()
        changed.loc[changed.cbsa.eq('20000'), 'type'] = 'Metropolitan Statistical Area'
        _, summary = m.compare_memberships(a, changed, b, 2013, 2018)
        self.assertEqual(summary['common_changed_types'], 1)
        self.assertEqual(summary['common_changed_county_sets'], 0)

    def test_left_right_presence_is_explicit(self):
        a, b, *_ = fixture()
        changed = a.copy()
        changed.loc[changed.cbsa.eq('20000'), 'cbsa'] = '21000'
        _, summary = m.compare_memberships(a, changed, b, 2013, 2018)
        self.assertEqual(summary['only_left'], 1)
        self.assertEqual(summary['only_right'], 1)
        self.assertEqual(summary['common_codes'], 1)

    def test_known_footer_but_not_bad_key_is_discarded(self):
        a, *_ = fixture()
        raw = a[['cbsa', 'name', 'type', 'state', 'county']]
        footer = pd.DataFrame([['Source: official', None, None, None, None]], columns=raw.columns)
        with patch.object(m.pd, 'read_excel', side_effect=[pd.DataFrame([['SEPTEMBER 2018']]),
                                                          pd.concat([raw, footer])]):
            self.assertEqual(len(m.read_membership(Path('unused'), 2018)), 4)
        raw.loc[0, 'cbsa'] = 'mistyped-code'
        with patch.object(m.pd, 'read_excel', side_effect=[pd.DataFrame([['SEPTEMBER 2018']]), raw]):
            with self.assertRaises(ValueError):
                m.read_membership(Path('unused'), 2018)

    def test_wrong_heading_fails(self):
        with patch.object(m.pd, 'read_excel', return_value=pd.DataFrame([['MARCH 2020']])):
            with self.assertRaises(ValueError):
                m.read_membership(Path('unused'), 2018)

    def test_divisions_not_counted_as_cbsa_totals(self):
        rows = [['10180', '', '', 'Example', 'Metropolitan Statistical Area', '100', '110', '120'],
                ['10180', '12345', '', 'Division', 'Metropolitan Division', '100', '110', '120'],
                ['10180', '12345', '01001', 'County', 'County or equivalent', '100', '110', '120']]
        raw = pd.DataFrame(rows, columns=['CBSA', 'MDIV', 'STCOU', 'NAME', 'LSAD',
                                         *[f'POPESTIMATE{y}' for y in m.YEARS]])
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / 'public_synthetic.csv'
            raw.to_csv(path, index=False)
            totals, parts, divisions = m.read_cbsa_populations(path)
        self.assertEqual((len(totals), len(parts), divisions), (1, 1, 1))


if __name__ == '__main__':
    unittest.main()
