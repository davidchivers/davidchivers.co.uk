"""Acquire and validate an outcome-blind official public metro reference."""

from __future__ import annotations

import argparse
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path

import requests


PROJECT = Path(__file__).resolve().parents[2]
BASE = 'https://www2.census.gov/programs-surveys/'
SOURCES = {
    'delineation_2013.xls': BASE + 'metro-micro/geographies/reference-files/2013/delineation-files/list1.xls',
    'delineation_2018.xls': BASE + 'metro-micro/geographies/reference-files/2018/delineation-files/list1_Sep_2018.xls',
    'delineation_2020.xls': BASE + 'metro-micro/geographies/reference-files/2020/delineation-files/list1_2020.xls',
    'cbsa_population_2019.csv': BASE + 'popest/datasets/2010-2019/metro/totals/cbsa-est2019-alldata.csv',
    'county_population_2019.csv': BASE + 'popest/datasets/2010-2019/counties/totals/co-est2019-alldata.csv',
    'cbsa_population_layout.pdf': BASE + 'popest/datasets/2010-2019/metro/totals/cbsa-est2019-alldata.pdf',
    'county_population_layout.pdf': BASE + 'popest/datasets/2010-2019/counties/totals/co-est2019-alldata.pdf',
}


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def outside_repo(path):
    path = Path(path)
    if not path.is_absolute():
        raise ValueError('Source destination must be absolute')
    path = path.resolve()
    repo = PROJECT.parents[1]
    if path == repo or repo in path.parents:
        raise ValueError('Public source data must remain outside the repository')
    return path


def acquire(destination):
    destination = outside_repo(destination)
    destination.mkdir(parents=True, exist_ok=False)
    records = []
    for name, url in SOURCES.items():
        response = requests.get(url, timeout=90)
        response.raise_for_status()
        body = response.content
        if not 20 <= len(body) <= 20_000_000 or b'<html' in body[:500].lower():
            raise ValueError('Unexpected download payload')
        if name.endswith('.pdf') and not body.startswith(b'%PDF-'):
            raise ValueError('Not a PDF')
        if name.endswith('.xls') and not body.startswith(bytes.fromhex('D0CF11E0A1B11AE1')):
            raise ValueError('Not the expected Excel binary format')
        path = destination / name
        with path.open('xb') as stream:
            stream.write(body)
        records.append({'file': name, 'url': url, 'final_url': response.url,
                        'retrieved_utc': datetime.now(timezone.utc).isoformat(),
                        'bytes': len(body), 'sha256': digest(path)})
        print(json.dumps({'acquired': name, 'bytes': len(body), 'sha256': digest(path)}))
    manifest = {'scope': 'official_public_census_only_no_restricted_data',
                'acquisition_code_sha256': digest(Path(__file__)), 'sources': records}
    with (destination / 'source_manifest.json').open('x', encoding='utf-8') as stream:
        json.dump(manifest, stream, indent=2, allow_nan=False)
        stream.write('\n')


def verify_sources(source):
    source = outside_repo(source)
    manifest = json.loads((source / 'source_manifest.json').read_text(encoding='utf-8'))
    if len(manifest['sources']) != len(SOURCES):
        raise ValueError('Incomplete source acquisition')
    if {r['file'] for r in manifest['sources']} != set(SOURCES):
        raise ValueError('Unexpected source set')
    for record in manifest['sources']:
        path = source / record['file']
        if (record['url'] != SOURCES[record['file']] or record['final_url'] != record['url'] or
                path.stat().st_size != record['bytes'] or digest(path) != record['sha256']):
            raise ValueError('Source provenance changed')
    return manifest


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--acquire', type=Path, required=True)
    acquire(parser.parse_args().acquire)
