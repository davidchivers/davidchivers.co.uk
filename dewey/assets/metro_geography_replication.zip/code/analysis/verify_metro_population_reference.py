"""Compare two public-reference runs and draw a public-definition-only figure."""

import argparse
import json
from pathlib import Path

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import pandas as pd

from prepare_metro_population_reference import PROJECT, digest, outside_repo, verify_sources


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source', required=True, type=Path)
    parser.add_argument('--first', required=True, type=Path)
    parser.add_argument('--replicate', required=True, type=Path)
    args = parser.parse_args()
    source, first, replicate = map(outside_repo, (args.source, args.first, args.replicate))
    manifest = verify_sources(source)
    a = json.loads((first / 'verification.json').read_text(encoding='utf-8'))
    b = json.loads((replicate / 'verification.json').read_text(encoding='utf-8'))
    ignored = {'completed_utc', 'elapsed_seconds'}
    if {k: v for k, v in a.items() if k not in ignored} != {k: v for k, v in b.items() if k not in ignored}:
        raise ValueError('Deterministic verification differs')
    for root in (first, replicate):
        for name, expected in a['output_sha256'].items():
            if digest(root / name) != expected:
                raise ValueError('Output hash differs')
    for name, expected in a['execution_sha256'].items():
        if digest(PROJECT / name) != expected:
            raise ValueError('Execution source changed')
    if a['source_sha256'] != {r['file']: r['sha256'] for r in manifest['sources']}:
        raise ValueError('Public inputs changed')
    comparison = pd.read_csv(first / 'comparison_2013_2018.csv', dtype={'cbsa': str})
    metros = comparison.loc[comparison.common_code & comparison.left_type.eq('metro') &
                            comparison.right_type.eq('metro')]
    counts = [int(metros.same_counties.eq(True).sum()), int(metros.same_counties.eq(False).sum())]
    differences = metros.population_pct_difference
    pop_counts = [int(differences.abs().le(5).sum()), int(differences.abs().gt(5).sum()),
                  int(differences.isna().sum())]
    if counts != [306, 73] or pop_counts != [337, 41, 1]:
        raise ValueError('Aggregate correspondence differs')
    out = PROJECT / 'output/metro_population_reference_20261019'
    out.mkdir(parents=True, exist_ok=True)
    receipt_path = out / 'public_reference_verification.json'
    graph_path = out / 'metro_definition_comparison.png'
    if receipt_path.exists() or graph_path.exists():
        raise ValueError('Preserve completed public verification')
    plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 11})
    fig, axes = plt.subplots(1, 2, figsize=(12, 4.7), constrained_layout=True)
    fig.suptitle('The same metro code can represent different county lists', fontsize=16)
    series = [(counts, ['Same list', 'Different list'], ['#208275', '#B44449'],
               '2013 versus September 2018 definitions'),
              (pop_counts, ['At most 5%', 'More than 5%', 'Not comparable'],
               ['#2D709B', '#B44449', '#777777'], 'Absolute difference in population denominator')]
    for ax, (values, labels, colors, title) in zip(axes, series):
        bars = ax.barh(labels, values, color=colors, height=0.55)
        ax.invert_yaxis()
        ax.set_xlim(0, 390)
        ax.set_xlabel('Number of metro codes (379 metro in both definitions)')
        ax.set_title(title, fontsize=12, pad=15)
        ax.bar_label(bars, padding=5)
        ax.spines[['top', 'right']].set_visible(False)
    fig.supxlabel('Both population sums use the same 2019 county estimates. Not population growth or a POI result.\n'
                  'One historical county key cannot be matched; it is not imputed. Source: Census delineations and Vintage 2019 PEP.',
                  fontsize=9)
    fig.savefig(graph_path, dpi=180, facecolor='white')
    plt.close(fig)
    report = {'scope': 'public_definitions_only_no_POI_results',
              'all_seven_output_hashes_match': True, 'all_deterministic_receipt_fields_match': True,
              'execution_seconds': [a['elapsed_seconds'], b['elapsed_seconds']],
              'first_receipt_sha256': digest(first / 'verification.json'),
              'replicate_receipt_sha256': digest(replicate / 'verification.json'),
              'verification': a, 'figure_sha256': digest(graph_path),
              'same_changed_county_lists': counts, 'population_difference_le5_gt5_missing': pop_counts,
              'verifier_sha256': digest(Path(__file__))}
    with receipt_path.open('x', encoding='utf-8') as stream:
        json.dump(report, stream, indent=2, allow_nan=False)
        stream.write('\n')
    print('Seven public outputs and deterministic receipts match; public-only figure verified.')


if __name__ == '__main__':
    main()
