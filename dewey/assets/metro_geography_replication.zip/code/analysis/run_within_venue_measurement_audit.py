"""Local-only Phase A audit. No automatic estimation, downloads or default inputs.

Only call execute after file-specific processing approval. Config flags are
guards against accidental execution, not proof of licence or human approval.
Detailed cells and input paths stay in the approved private output directory.
The CLI prints no rows, paths or database error text. Tests use synthetic data.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import re
from pathlib import Path

import duckdb


PROJECT = Path(__file__).resolve().parents[2]
RACES = ("white_nh", "black_nh", "asian_nh", "hispanic")
RACE_COLUMNS = tuple(f"race_share_{g}_tdw" for g in RACES)
REQUIRED = (
    "ID_STORE", "year", "MSA_CODE", "SUB_CATEGORY",
    "annualized_matched_visits", *RACE_COLUMNS, "race_frac_tdw",
    "ses_frac_nat_tdw", "race_flow_coverage_tdw", "nat_decile_flow_coverage_tdw",
)
BRIDGE_COLUMNS = ("sub_category", "naics_code", "public_facing_employment_share")


def ident(name):
    if not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", name):
        raise ValueError("Invalid relation name")
    return '"' + name + '"'


def literal(value):
    return "'" + str(value).replace("'", "''") + "'"


def finite_between(column, low, high):
    return f"({column} IS NOT NULL AND isfinite({column}) AND {column} BETWEEN {low} AND {high})"


def row_dict(con, query):
    result = con.execute(query)
    return dict(zip([x[0] for x in result.description], result.fetchone()))


def require_columns(con, relation, names):
    present = {r[0] for r in con.execute(f"DESCRIBE SELECT * FROM {ident(relation)}").fetchall()}
    if not set(names) <= present:
        # Names are code-defined, never values taken from a source record.
        raise ValueError("Required schema missing: " + ", ".join(sorted(set(names) - present)))


def audit_relations(con, poi="poi", bridge="bridge"):
    """Creates audit_cells in this connection; returns only national diagnostics.

    Caller owns input permission and output review. This function does not emit
    or persist rows. It deliberately cannot certify income-between accounting
    from the historical schema, which does not retain ten income shares.
    """
    require_columns(con, poi, REQUIRED)
    require_columns(con, bridge, BRIDGE_COLUMNS)
    p, b = ident(poi), ident(bridge)
    duplicate_pois = con.execute(f"""SELECT count(*) FROM
        (SELECT year, ID_STORE FROM {p} GROUP BY year, ID_STORE HAVING count(*) > 1)""").fetchone()[0]
    if duplicate_pois:
        raise ValueError("Duplicate POI-year keys; audit stopped before joins")
    missing_ids = con.execute(f"SELECT count(*) FROM {p} WHERE ID_STORE IS NULL OR trim(cast(ID_STORE AS VARCHAR)) = ''").fetchone()[0]
    if missing_ids:
        raise ValueError("Missing POI keys; audit stopped before joins")
    if con.execute(f"SELECT count(*) FROM {p} WHERE year IS NULL OR year NOT IN (2017,2018,2019)").fetchone()[0]:
        raise ValueError("Unexpected year; no cross-period substitution permitted")
    duplicate_categories = con.execute(f"""SELECT count(*) FROM
        (SELECT trim(sub_category) FROM {b} GROUP BY trim(sub_category) HAVING count(*) > 1)""").fetchone()[0]
    if duplicate_categories:
        raise ValueError("Bridge category mapping is not unique")
    con.execute(f"""CREATE OR REPLACE TEMP TABLE audit_bridge AS
        SELECT trim(sub_category) AS category, cast(naics_code AS VARCHAR) AS naics,
               public_facing_employment_share AS public_facing_share FROM {b}""")
    invalid_bridge = con.execute("""SELECT count(*) FROM audit_bridge
        WHERE category IS NULL OR category = '' OR naics IS NULL OR trim(naics) = ''
        OR public_facing_share IS NULL OR NOT isfinite(public_facing_share)
        OR public_facing_share NOT BETWEEN 0 AND 1""").fetchone()[0]
    if invalid_bridge:
        raise ValueError("Invalid bridge score or key")
    inconsistent_scores = con.execute("""SELECT count(*) FROM
        (SELECT naics FROM audit_bridge GROUP BY naics
         HAVING max(public_facing_share)-min(public_facing_share) > 1e-10)""").fetchone()[0]
    if inconsistent_scores:
        raise ValueError("Public-facing score varies within assigned NAICS")

    shares = ", ".join(f"{col} AS p{i}" for i, col in enumerate(RACE_COLUMNS))
    con.execute(f"""CREATE OR REPLACE TEMP VIEW audit_base AS SELECT
        cast(year AS INTEGER) AS year,
        CASE WHEN try_cast(MSA_CODE AS DOUBLE) = try_cast(MSA_CODE AS BIGINT)
                  AND try_cast(MSA_CODE AS BIGINT) BETWEEN 10000 AND 99999
             THEN lpad(cast(try_cast(MSA_CODE AS BIGINT) AS VARCHAR),5,'0') END AS msa,
        trim(SUB_CATEGORY) AS category,
        annualized_matched_visits AS w, {shares},
        race_frac_tdw AS race_f, ses_frac_nat_tdw AS income_f,
        race_flow_coverage_tdw AS race_coverage,
        nat_decile_flow_coverage_tdw AS income_coverage FROM {p}""")
    race_valid = " AND ".join(finite_between(f"p{i}", 0, 1) for i in range(4))
    race_valid += " AND abs(p0+p1+p2+p3-1) <= 1e-8 AND " + finite_between("race_f", 0, .75)
    race_valid += " AND " + finite_between("race_coverage", 0, 1) + " AND race_coverage > 0"
    income_valid = finite_between("income_f", 0, .9)
    income_valid += " AND " + finite_between("income_coverage", 0, 1) + " AND income_coverage > 0"
    con.execute(f"""CREATE OR REPLACE TEMP VIEW audit_flags AS SELECT a.*, b.naics,
        b.public_facing_share,
        coalesce(w > 0 AND isfinite(w),false) AS valid_weight,
        (msa IS NOT NULL AND category IS NOT NULL AND category != '') AS valid_geo,
        coalesce(({race_valid}),false) AS valid_race,
        coalesce(({income_valid}),false) AS valid_income
        FROM audit_base a LEFT JOIN audit_bridge b USING(category)""")
    counts = row_dict(con, """SELECT count(*) AS input_rows,
        count(*) FILTER(WHERE NOT valid_weight) AS invalid_weight_rows,
        count(*) FILTER(WHERE NOT valid_geo) AS invalid_geography_rows,
        count(*) FILTER(WHERE naics IS NULL) AS unmapped_category_rows,
        count(*) FILTER(WHERE NOT valid_race) AS missing_or_invalid_race_rows,
        count(*) FILTER(WHERE NOT valid_income) AS missing_or_invalid_income_rows,
        count(*) FILTER(WHERE valid_geo AND valid_weight AND naics IS NOT NULL AND valid_race) AS maximal_race_rows,
        count(*) FILTER(WHERE valid_geo AND valid_weight AND naics IS NOT NULL AND valid_income) AS maximal_income_rows,
        coalesce(sum(w) FILTER(WHERE valid_weight),0) AS eligible_positive_weight
        FROM audit_flags""")
    con.execute("""CREATE OR REPLACE TEMP VIEW audit_common AS SELECT * FROM audit_flags
        WHERE valid_weight AND valid_geo AND valid_race AND valid_income AND naics IS NOT NULL""")
    common = row_dict(con, """SELECT count(*) AS common_rows, count(DISTINCT msa) AS msas,
        count(DISTINCT naics) AS naics, count(DISTINCT category) AS categories,
        coalesce(sum(w),0) AS common_weight,
        max(abs(race_f-(1-p0*p0-p1*p1-p2*p2-p3*p3))) AS race_index_max_error,
        sum(w*race_coverage)/sum(w) AS weighted_origin_race_coverage,
        sum(w*income_coverage)/sum(w) AS weighted_origin_income_coverage FROM audit_common""")
    if common["common_rows"] == 0:
        raise ValueError("No common valid mapped sample")
    if common["race_index_max_error"] > 1e-8:
        raise ValueError("Stored race fractionalization disagrees with four-group shares")
    expressions = []
    for i in range(4):
        expressions.extend((f"sum(w*p{i})/sum(w) AS race_mean_{i}",
                            f"sum(w*p{i}*p{i})/sum(w) AS race_second_{i}",
                            f"avg(p{i}) AS equal_race_mean_{i}",
                            f"avg(p{i}*p{i}) AS equal_race_second_{i}"))
    con.execute(f"""CREATE OR REPLACE TEMP TABLE audit_cells AS
        WITH moments AS (SELECT year, msa, category, naics, public_facing_share,
          count(*) AS n_pois, sum(w) AS weight_sum,
          sum(w*race_f)/sum(w) AS within_race,
          sum(w*income_f)/sum(w) AS within_income,
          avg(race_f) AS equal_within_race, avg(income_f) AS equal_within_income,
          {', '.join(expressions)} FROM audit_common
          GROUP BY year, msa, category, naics, public_facing_share)
        SELECT *,
          1-race_mean_0^2-race_mean_1^2-race_mean_2^2-race_mean_3^2 AS pooled_race,
          1-equal_race_mean_0^2-equal_race_mean_1^2-equal_race_mean_2^2-equal_race_mean_3^2 AS equal_pooled_race,
          race_second_0-race_mean_0^2+race_second_1-race_mean_1^2+
          race_second_2-race_mean_2^2+race_second_3-race_mean_3^2 AS between_race,
          equal_race_second_0-equal_race_mean_0^2+equal_race_second_1-equal_race_mean_1^2+
          equal_race_second_2-equal_race_mean_2^2+equal_race_second_3-equal_race_mean_3^2 AS equal_between_race
        FROM moments""")
    decomposition = row_dict(con, """SELECT count(*) AS cells,
        max(abs(pooled_race-within_race-between_race)) AS max_identity_error,
        max(abs(equal_pooled_race-equal_within_race-equal_between_race)) AS max_equal_identity_error,
        min(between_race) AS min_between_race,
        sum(weight_sum*within_race)/sum(weight_sum) AS mean_within_race,
        sum(weight_sum*pooled_race)/sum(weight_sum) AS mean_cell_pooled_race,
        sum(weight_sum*between_race)/sum(weight_sum) AS mean_between_race,
        sum(weight_sum*within_income)/sum(weight_sum) AS mean_within_income,
        sum(n_pois*equal_within_race)/sum(n_pois) AS equal_mean_within_race,
        sum(n_pois*equal_within_income)/sum(n_pois) AS equal_mean_within_income
        FROM audit_cells""")
    if max(decomposition["max_identity_error"], decomposition["max_equal_identity_error"]) > 1e-8 or decomposition["min_between_race"] < -1e-8:
        raise ValueError("Decomposition identity failed")
    con.execute("""CREATE OR REPLACE TEMP TABLE audit_score_support AS WITH residuals AS
        (SELECT *, public_facing_share-
            sum(weight_sum*public_facing_share) OVER(PARTITION BY year,msa)/
            sum(weight_sum) OVER(PARTITION BY year,msa) AS score_resid FROM audit_cells)
        SELECT naics, sum(weight_sum*score_resid*score_resid) AS information,
               sum(weight_sum) AS industry_weight FROM residuals GROUP BY naics""")
    support = row_dict(con, """SELECT sum(information) AS residual_score_information,
        sum(information)/sum(industry_weight) AS residual_score_variance,
        max(information)/nullif(sum(information),0) AS max_naics_information_share,
        pow(sum(information),2)/nullif(sum(information*information),0) AS information_concentration_count
        FROM audit_score_support""")
    report = {"stage":"measurement_audit_no_regression", "counts":counts, "common_sample":common,
              "race_decomposition":decomposition, "score_support":support,
              "common_weight_fraction":common["common_weight"]/counts["eligible_positive_weight"],
              "income_between_available":False,
              "income_between_reason":"Historical producer exports income indices but not ten decile shares. Do not reconstruct group means from fractionalization.",
              "worker_comparison_performed":False,
              "production_inference_cleared":False,
              "limits":["Composition opportunities, not simultaneous encounters or personal income.",
                        "Information concentration count is a design diagnostic, not degrees of freedom.",
                        "Origin race shares condition on four groups; residual population mass is not audited here.",
                        "Coverage, disclosure and industry/geographic dependence need review before any estimation."]}
    return report


def outside_repo(path):
    if not Path(path).is_absolute():
        raise ValueError("Private paths must be absolute")
    resolved = Path(path).resolve()
    # Both project and repository trees must be excluded, including junctions.
    repo = PROJECT.parents[1]
    if resolved == repo or repo in resolved.parents:
        raise ValueError("Private inputs/output must remain outside the repository")
    return resolved


def validate_config(config):
    if config.get("release") != "origin_cbg_nhgis_v1":
        raise ValueError("Exact final NHGIS release must be declared")
    if config.get("approved_local_processing") is not True:
        raise ValueError("File-specific approval not recorded")
    sources = config.get("sources", [])
    if sorted(s.get("year") for s in sources) != [2017,2018,2019]:
        raise ValueError("Exactly one source for each of 2017, 2018, 2019 is required")
    paths = [outside_repo(s["path"]) for s in sources]
    if len(set(paths)) != 3:
        raise ValueError("Source paths must be distinct")
    output = outside_repo(config["output_directory"])
    if any(p == output or output in p.parents for p in paths):
        raise ValueError("Output may not contain input files")
    if output.exists():
        raise ValueError("Use a new private output directory; overwriting is disabled")
    return sources, paths, output


def sha256(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for chunk in iter(lambda:stream.read(8*1024*1024), b""):
            h.update(chunk)
    return h.hexdigest()


def execute(config):
    sources, paths, output = validate_config(config)
    bridge_path = Path(config["bridge_path"]).resolve()
    if not all(p.is_file() for p in [*paths, bridge_path]):
        raise ValueError("An explicit input is inaccessible")
    output.mkdir(parents=True, exist_ok=False)
    con = duckdb.connect(str(output / "private_audit.duckdb"))
    try:
        con.execute("SET threads=4")
        con.execute("SET memory_limit='4GB'")
        con.execute("SET temp_directory=" + literal(output / "spill"))
        manifest = [{"year":s["year"], "path":str(p), "bytes":p.stat().st_size,
                     "sha256":sha256(p)} for s,p in zip(sources,paths)]
        for s,m in zip(sources,manifest):
            if s.get("sha256") and s["sha256"].lower() != m["sha256"]:
                raise ValueError("Source fingerprint mismatch")
        for s,p in zip(sources,paths):
            wrong = con.execute(f"SELECT count(*) FROM read_parquet({literal(p)}) WHERE year IS NULL OR year != ?", [s["year"]]).fetchone()[0]
            if wrong:
                raise ValueError("Input year differs from manifest")
        con.execute("CREATE TEMP VIEW poi AS SELECT * FROM read_parquet([" + ','.join(map(literal, paths)) + "])")
        con.execute("CREATE TEMP VIEW bridge AS SELECT * FROM read_csv_auto("+literal(bridge_path)+", all_varchar=false)")
        report = audit_relations(con)
        con.execute("COPY audit_cells TO " + literal(output / "private_cells.parquet") + " (FORMAT PARQUET)")
        report["input_fingerprints"] = manifest
        report["bridge_fingerprint"] = sha256(bridge_path)
        (output / "private_report.json").write_text(json.dumps(report,indent=2,allow_nan=False)+"\n",encoding="utf-8")
        # This file still requires an explicit disclosure review before sharing.
        safe_candidate = {k:v for k,v in report.items() if k not in {"input_fingerprints"}}
        safe_candidate["disclosure_review"] = "pending; national summaries only; not automatic release"
        if report["common_sample"]["common_rows"] >= 1000 and report["common_sample"]["msas"] >= 20:
            (output / "aggregate_review_candidate.json").write_text(json.dumps(safe_candidate,indent=2,allow_nan=False)+"\n",encoding="utf-8")
    finally:
        con.close()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--execute", action="store_true")
    args = parser.parse_args()
    try:
        config = json.loads(args.config.read_text(encoding="utf-8-sig"))
        validate_config(config)
        if args.execute:
            execute(config)
            print("Local measurement audit complete; review private report before disclosure. No regression was run.")
        else:
            print("Configuration validated only. No source file opened; --execute requires documented file-specific approval.")
    except Exception as exc:
        # Database exceptions can include data values or local paths.
        print("Audit stopped safely: " + type(exc).__name__ + ". No row/error details emitted.")
        raise SystemExit(1) from None


if __name__ == "__main__":
    main()
