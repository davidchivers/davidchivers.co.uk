"""Artificial-only classification and national disclosure checks."""

import unittest

import duckdb
import pandas as pd

from audit_poi_metro_assignment import candidate, classify_sql, normalized_area_sql


class AssignmentTests(unittest.TestCase):
    def test_area_normalization_does_not_round_or_repair(self):
        with duckdb.connect() as con:
            raw = ['10180', '10180.0', '10180.000', '10180.25', ' 10180',
                   '10180 ', '010180', '9999.0', '100000.0', 'NaN', 'inf', None]
            con.register('artificial', pd.DataFrame({'MSA_CODE': raw}))
            got = con.execute('SELECT ' + normalized_area_sql() + ' FROM artificial').fetchall()
        self.assertEqual([r[0] for r in got], ['10180', '10180', '10180'] + raw[3:])

    def test_nonfinite_boolean_negative_and_missing_counts_withhold(self):
        for bad in [float('nan'), float('inf'), -1, True, None, '1000']:
            with self.subTest(bad=bad):
                profile = [{'group': 'compatible', 'n_rows': 1000, 'n_recorded_areas': 20},
                           {'group': 'not_demonstrated_compatible', 'n_rows': bad,
                            'n_recorded_areas': 20}]
                self.assertFalse(candidate(profile, 2000)['release_screen_passed'])
                self.assertFalse(candidate(profile, bad)['release_screen_passed'])

    def test_disjoint_classification_and_denominator(self):
        pairs = pd.DataFrame([
            ['10180', '01001', 1000], ['20220', '01001', 2000],
            ['99999', '01001', 3000], [None, '01001', 4000],
            ['10180', None, 5000], ['10180', '1001', 6000],
            ['10180', '72001', 7000], ['10180', '01005', 8000],
        ], columns=['msa', 'county', 'n_rows'])
        with duckdb.connect() as con:
            con.register('input_pairs', pairs)
            con.register('county_scope', pd.DataFrame({'fips': ['01001', '01003', '01005']}))
            con.register('county_map', pd.DataFrame({'fips': ['01001', '01003'], 'cbsa': ['10180', '20220']}))
            con.register('area_map', pd.DataFrame({'cbsa': ['10180', '20220']}))
            got = con.execute(classify_sql()).fetchdf()
        self.assertEqual(int(got.n_rows.sum()), 36000)
        expected = {1000: 'compatible', 2000: 'county_recorded_code_conflict',
                    3000: 'recorded_code_outside_delineation', 4000: 'missing_or_malformed_recorded_area',
                    5000: 'missing_or_malformed_county', 6000: 'missing_or_malformed_county',
                    7000: 'outside_US2019_county_reference', 8000: 'county_outside_CBSA'}
        self.assertEqual(dict(zip(got.n_rows, got.status)), expected)

    def test_release_contains_no_area_support_or_codes(self):
        profile = [{'group': 'compatible', 'n_rows': 2000, 'n_recorded_areas': 21},
                   {'group': 'not_demonstrated_compatible', 'n_rows': 1000, 'n_recorded_areas': 20}]
        got = candidate(profile, 3000)
        self.assertTrue(got['release_screen_passed'])
        self.assertEqual(sum(g['rows'] for g in got['groups']), 3000)
        self.assertAlmostEqual(sum(g['percent'] for g in got['groups']), 100)
        self.assertEqual(set(got['groups'][0]), {'group', 'rows', 'percent'})
        self.assertEqual(got['independent_review'], 'pending')

    def test_small_complement_withholds_both(self):
        got = candidate([{'group': 'compatible', 'n_rows': 2000, 'n_recorded_areas': 21},
                         {'group': 'not_demonstrated_compatible', 'n_rows': 999, 'n_recorded_areas': 20}], 2999)
        self.assertFalse(got['release_screen_passed'])
        self.assertNotIn('groups', got)

    def test_few_codes_withholds_both(self):
        got = candidate([{'group': 'compatible', 'n_rows': 2000, 'n_recorded_areas': 21},
                         {'group': 'not_demonstrated_compatible', 'n_rows': 1000, 'n_recorded_areas': 19}], 3000)
        self.assertFalse(got['release_screen_passed'])

    def test_incorrect_total_withholds(self):
        got = candidate([{'group': 'compatible', 'n_rows': 2000, 'n_recorded_areas': 21},
                         {'group': 'not_demonstrated_compatible', 'n_rows': 1000, 'n_recorded_areas': 20}], 3001)
        self.assertFalse(got['release_screen_passed'])

    def test_one_group_withholds(self):
        got = candidate([{'group': 'compatible', 'n_rows': 3000, 'n_recorded_areas': 21}], 3000)
        self.assertFalse(got['release_screen_passed'])

    def test_extra_group_withholds(self):
        got = candidate([{'group': 'compatible', 'n_rows': 2000, 'n_recorded_areas': 21},
                         {'group': 'not_demonstrated_compatible', 'n_rows': 1000, 'n_recorded_areas': 20},
                         {'group': 'sparse_private_code', 'n_rows': 1, 'n_recorded_areas': 1}], 3001)
        self.assertFalse(got['release_screen_passed'])


if __name__ == '__main__':
    unittest.main()
