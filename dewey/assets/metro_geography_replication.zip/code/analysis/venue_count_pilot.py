"""Bounded private-cell reanalysis. No raw rows, new joins or causal inference."""
from __future__ import annotations

import argparse
import json
import time
from pathlib import Path

import numpy as np
import pandas as pd

from run_within_venue_measurement_audit import outside_repo, sha256

COLS = ['year', 'msa', 'category', 'n_pois', 'weight_sum', 'within_race',
        'pooled_race', 'between_race', 'equal_within_race',
        'equal_pooled_race', 'equal_between_race']
SOURCE_HASHES = {
    2017: '3733d38bb93335e93d1cba377b3f81d6443390200983b7cbc9f11c71079e1f9e',
    2018: '8816d91da0e2ffa53b954ddf9610978dc63bc31ab6f9a8c4313de2912b2c4044',
    2019: 'dd4aff1f85092ae17dff7e0d4b5c6ff0748e9af9caade9bfc6e706a5ab5b4890',
}


def validate(frame, original):
    if frame.empty or not set(COLS) <= set(frame):
        raise ValueError('Missing cells/schema')
    if frame[['year', 'msa', 'category']].isna().any().any():
        raise ValueError('Missing keys')
    if frame.duplicated(['year', 'msa', 'category']).any():
        raise ValueError('Duplicate keys')
    if not set(frame.year) <= {2017, 2018, 2019}:
        raise ValueError('Unexpected year')
    if not np.isfinite(frame[COLS[3:]].to_numpy(dtype=float)).all():
        raise ValueError('Nonfinite values')
    if ((frame.n_pois < 1) | (frame.n_pois != np.floor(frame.n_pois)) |
            (frame.weight_sum <= 0)).any():
        raise ValueError('Invalid counts/weights')
    errors = {}
    for prefix in ['', 'equal_']:
        within, pooled, between = [frame[prefix + x] for x in
                                  ['within_race', 'pooled_race', 'between_race']]
        error = float(np.abs(pooled - within - between).max())
        if error > 1e-8 or (between < -1e-8).any() or (within < -1e-8).any() or (pooled > .75 + 1e-8).any():
            raise ValueError('Invalid decomposition')
        errors[prefix + 'identity_error'] = error
    if int(frame.n_pois.sum()) != original['common_sample']['common_rows']:
        raise ValueError('Count reconciliation failed')
    if not np.isclose(frame.weight_sum.sum(), original['common_sample']['common_weight'], rtol=1e-10):
        raise ValueError('Weight reconciliation failed')
    for col, key in [('within_race', 'mean_within_race'),
                     ('pooled_race', 'mean_cell_pooled_race'),
                     ('between_race', 'mean_between_race')]:
        if abs(np.average(frame[col], weights=frame.weight_sum) -
               original['race_decomposition'][key]) > 1e-10:
            raise ValueError('National moment reconciliation failed')
    return errors


def releasable(frame):
    return bool(len(frame) >= 100 and frame.msa.nunique() >= 20 and frame.n_pois.sum() >= 1000)


def residual_correlation(frame):
    """Equal-cell within-subcategory association, not an inferential model."""
    d = frame.copy()
    sizes = d.groupby('category').category.transform('size')
    d = d[sizes >= 20].copy()
    if not releasable(d):
        return {'released': False}
    d['x'] = np.log(d.n_pois)
    d['y'] = d.between_race / d.pooled_race
    residuals = d[['x', 'y']] - d.groupby('category')[['x', 'y']].transform('mean')
    x, y = residuals.x.to_numpy(), residuals.y.to_numpy()
    denominator = float(np.sqrt(x @ x * (y @ y)))
    return {'released': True, 'cells': len(d), 'areas': int(d.msa.nunique()),
            'categories': int(d.category.nunique()),
            'correlation': float(x @ y / denominator) if denominator > 1e-14 else None}


def summarize(frame):
    rows, correlations, support = [], [], []
    for year, annual in frame.groupby('year', sort=True):
        d = annual[(annual.n_pois >= 2) & (annual.pooled_race >= .05)].copy()
        if not releasable(d):
            continue
        support.append({'year': int(year), 'input_cells': len(annual), 'retained_cells': len(d),
                        'retained_poi_years': int(d.n_pois.sum()),
                        'retained_visit_weight_fraction': float(d.weight_sum.sum()/annual.weight_sum.sum())})
        d['bin'] = pd.cut(d.n_pois, [1, 4, 9, 24, 99, np.inf],
                          labels=['2-4', '5-9', '10-24', '25-99', '100+'])
        for label, subset in d.groupby('bin', observed=True, sort=True):
            item = {'year': int(year), 'venue_count_bin': str(label), 'released': releasable(subset)}
            if item['released']:
                ratio = subset.between_race / subset.pooled_race
                item.update(cells=len(subset), areas=int(subset.msa.nunique()),
                            poi_years=int(subset.n_pois.sum()),
                            equal_cell_sorting=float(ratio.mean()),
                            visit_weighted_cell_sorting=float(np.average(ratio, weights=subset.weight_sum)),
                            equal_cell_distinct_venue_contrast=float((subset.equal_between_race * subset.n_pois / (subset.n_pois-1)).mean()),
                            equal_cell_within_race=float(subset.within_race.mean()),
                            equal_cell_pooled_race=float(subset.pooled_race.mean()))
            rows.append(item)
        for threshold in [.01, .05, .10]:
            s = annual[(annual.n_pois >= 2) & (annual.pooled_race >= threshold)]
            correlations.append({'year': int(year), 'pooled_diversity_minimum': threshold,
                                 **residual_correlation(s)})
    return {'stage': 'descriptive_existing_cell_reanalysis_not_structural_or_causal',
            'support': support, 'count_bins': rows,
            'within_subcategory_correlations': correlations,
            'geography': 'Recorded area codes; original metro/micro vintage unresolved',
            'disclosure_review': 'Pending manual review; national summaries with size screens only',
            'raw_inputs_rerun': False,
            'limitations': ['Recorded count is not accessible choice or product variety.',
                           'Inferred four-group origin race is not personal race or actual contact.',
                           'Density, residential geography, endogenous supply and coverage remain confounded.',
                           'Distinct-venue diagnostic does not remove share-estimation noise.',
                           'Inherited mapped-category common race/income sample; not all POIs.',
                           'No causal estimates, standard errors, preference estimates or Green Book linkage.']}


def execute(config_path):
    started = time.perf_counter()
    config_path = outside_repo(config_path)
    config = json.loads(config_path.read_text(encoding='utf-8-sig'))
    root = outside_repo(config['output_directory'])
    destination = root.parent / 'venue_count_pilot_20261019'
    if destination.exists():
        raise ValueError('No overwrite')
    report_path, cell_path = root/'private_report.json', root/'private_cells.parquet'
    original = json.loads(report_path.read_text(encoding='utf-8'))
    prior = json.loads((root/'private_cell_review_manifest.json').read_text(encoding='utf-8'))
    if {x['year']: x['sha256'] for x in original['input_fingerprints']} != SOURCE_HASHES:
        raise ValueError('Wrong original release')
    cell_hash, report_hash = sha256(cell_path), sha256(report_path)
    if cell_hash != prior['private_cells_sha256'] or report_hash != prior['private_report_sha256']:
        raise ValueError('Prior audit artifact changed')
    frame = pd.read_parquet(cell_path, columns=COLS)
    errors = validate(frame, original)
    result = summarize(frame)
    result['validation'] = errors
    result['provenance'] = {'cell_sha256': cell_hash, 'original_report_sha256': report_hash,
                            'script_sha256': sha256(__file__), 'source_hashes': SOURCE_HASHES,
                            'elapsed_seconds': time.perf_counter()-started}
    payload = json.dumps(result, indent=2, allow_nan=False)+'\n'
    destination.mkdir(exist_ok=False)
    (destination/'aggregate_candidate.json').write_text(payload, encoding='utf-8')


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--prior-config', type=Path, required=True)
    parser.add_argument('--execute', action='store_true', required=True)
    args = parser.parse_args()
    try:
        execute(args.prior_config)
        print('Private aggregate candidate complete. No raw rows, new raw processing or automatic release.')
    except Exception as exc:
        print('Stopped safely: '+type(exc).__name__+'. No source values or paths printed.')
        raise SystemExit(1) from None
