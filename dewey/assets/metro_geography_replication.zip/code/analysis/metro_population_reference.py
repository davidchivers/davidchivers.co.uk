"""Build dated public metro populations; never reads mobility or private inputs."""

from __future__ import annotations

import argparse
import json
import re
import time
from datetime import datetime, timezone
from pathlib import Path

import pandas as pd

from prepare_metro_population_reference import PROJECT, digest, outside_repo, verify_sources


YEARS = (2017, 2018, 2019)
TYPES = {'Metropolitan Statistical Area': 'metro', 'Micropolitan Statistical Area': 'micro'}
STATE_CODES = set('01 02 04 05 06 08 09 10 11 12 13 15 16 17 18 19 20 21 22 23 24 25 '
                  '26 27 28 29 30 31 32 33 34 35 36 37 38 39 40 41 42 44 45 46 47 '
                  '48 49 50 51 53 54 55 56'.split())
DATES = {2013: 'FEBRUARY 2013', 2018: 'SEPTEMBER 2018', 2020: 'MARCH 2020'}
PROTOCOL = PROJECT / 'docs/protocols/metro_population_reference_20261019.md'


def code(value, width):
    value = str(value).strip()
    if not re.fullmatch(r'\d+', value) or len(value) > width:
        raise ValueError('Invalid geographic code')
    return value.zfill(width)


def positive_integer(value):
    value = str(value).strip()
    if not re.fullmatch(r'\d+', value) or int(value) <= 0:
        raise ValueError('Population must be a positive integer')
    return int(value)


def validate_membership(frame):
    required = ['cbsa', 'name', 'type', 'state', 'county']
    result = frame[required].copy()
    if result.empty or result.isna().any().any():
        raise ValueError('Empty or missing delineation fields')
    for field, width in [('cbsa', 5), ('state', 2), ('county', 3)]:
        result[field] = result[field].map(lambda value: code(value, width))
    if not result.cbsa.str.fullmatch(r'[1-9]\d{4}').all():
        raise ValueError('Invalid CBSA range')
    if not set(result.type) <= set(TYPES) or not set(result.state) <= STATE_CODES | {'72'}:
        raise ValueError('Unknown classification or territory')
    if result.name.str.strip().eq('').any() or result.county.eq('000').any():
        raise ValueError('Missing title or county-equivalent code')
    result['fips'] = result.state + result.county
    result['scope'] = result.state.map(lambda x: 'PR' if x == '72' else 'US50DC')
    if result.fips.duplicated().any():
        raise ValueError('A county is assigned more than once')
    if (result.groupby('cbsa')[['name', 'type', 'scope']].nunique() != 1).any().any():
        raise ValueError('Ambiguous CBSA identity')
    return result.sort_values(['cbsa', 'fips']).reset_index(drop=True)


def read_membership(path, vintage):
    heading = pd.read_excel(path, header=None, nrows=2).fillna('').astype(str)
    if DATES[vintage] not in ' '.join(heading.to_numpy().ravel()):
        raise ValueError('Delineation heading does not match expected vintage')
    frame = pd.read_excel(path, header=2, dtype=str).rename(columns={
        'CBSA Code': 'cbsa', 'CBSA Title': 'name',
        'Metropolitan/Micropolitan Statistical Area': 'type',
        'FIPS State Code': 'state', 'FIPS County Code': 'county'})
    # Official footer prose occupies column A; never drop a malformed data row.
    values = frame[['cbsa', 'name', 'type', 'state', 'county']]
    blank = values.isna().all(axis=1)
    footer = (values.cbsa.fillna('').str.startswith(('Note: ', 'Source: ', 'Internet Release Date: '))
              & values[['name', 'type', 'state', 'county']].isna().all(axis=1))
    return validate_membership(frame.loc[~(blank | footer)])


def read_county_populations(path):
    frame = pd.read_csv(path, encoding='latin1', dtype=str, keep_default_na=False)
    if not set(frame.SUMLEV) <= {'040', '050'}:
        raise ValueError('Unexpected county population summary level')
    counties = frame.loc[frame.SUMLEV.eq('050')].copy()
    counties['state'] = counties.STATE.map(lambda x: code(x, 2))
    counties['county'] = counties.COUNTY.map(lambda x: code(x, 3))
    counties['fips'] = counties.state + counties.county
    if (counties.empty or counties.fips.duplicated().any() or counties.county.eq('000').any()
            or not set(counties.state) <= STATE_CODES):
        raise ValueError('Invalid US county population keys')
    for year in YEARS:
        counties[str(year)] = counties[f'POPESTIMATE{year}'].map(positive_integer)
    # The state totals are an independent aggregation level, not extra counties.
    states = frame.loc[frame.SUMLEV.eq('040')].copy()
    states['state'] = states.STATE.map(lambda x: code(x, 2))
    if states.state.duplicated().any() or set(states.state) != STATE_CODES:
        raise ValueError('Missing or duplicate state totals')
    for year in YEARS:
        actual = counties.groupby('state')[str(year)].sum().to_dict()
        expected = dict(zip(states.state, states[f'POPESTIMATE{year}'].map(positive_integer)))
        if actual != expected:
            raise ValueError('County population does not reconcile to state totals')
    return counties[['fips', 'state', *map(str, YEARS)]].reset_index(drop=True)


def read_cbsa_populations(path):
    frame = pd.read_csv(path, encoding='latin1', dtype=str, keep_default_na=False)
    if not set(frame.LSAD) <= set(TYPES) | {'County or equivalent', 'Metropolitan Division'}:
        raise ValueError('Unexpected population geography type')
    totals = frame.loc[frame.LSAD.isin(TYPES)].copy()
    if not totals.MDIV.eq('').all() or not totals.STCOU.eq('').all():
        raise ValueError('CBSA totals confused with components')
    totals['cbsa'] = totals.CBSA.map(lambda x: code(x, 5))
    totals = totals.rename(columns={'NAME': 'name', 'LSAD': 'type'})
    if totals.empty or totals.cbsa.duplicated().any():
        raise ValueError('Missing or duplicate CBSA totals')
    for year in YEARS:
        totals[str(year)] = totals[f'POPESTIMATE{year}'].map(positive_integer)
    components = frame.loc[frame.LSAD.eq('County or equivalent')].copy()
    components['cbsa'] = components.CBSA.map(lambda x: code(x, 5))
    components['fips'] = components.STCOU.map(lambda x: code(x, 5))
    if components.empty or components.fips.duplicated().any():
        raise ValueError('Missing or duplicated population county components')
    for year in YEARS:
        components[str(year)] = components[f'POPESTIMATE{year}'].map(positive_integer)
    return (totals[['cbsa', 'name', 'type', *map(str, YEARS)]],
            components[['cbsa', 'fips', *map(str, YEARS)]],
            int(frame.LSAD.eq('Metropolitan Division').sum()))


def reconcile(membership, counties, totals, components):
    us = membership.loc[membership.scope.eq('US50DC')].copy()
    expected_pairs = set(zip(us.cbsa, us.fips))
    if expected_pairs != set(zip(components.cbsa, components.fips)):
        raise ValueError('Population/delineation county memberships differ')
    identity = us[['cbsa', 'name', 'type']].drop_duplicates().set_index('cbsa').sort_index()
    if set(identity.index) != set(totals.cbsa):
        raise ValueError('Population/delineation CBSA universes differ')
    published = totals.set_index('cbsa').sort_index()
    if not identity.equals(published[['name', 'type']]):
        raise ValueError('Population/delineation identities differ')
    joined = us.merge(counties, on=['fips', 'state'], how='left', validate='one_to_one')
    if joined[list(map(str, YEARS))].isna().any().any():
        raise ValueError('Missing county population')
    component_join = components.merge(counties, on='fips', validate='one_to_one',
                                      how='left', suffixes=('_component', '_county'))
    for year in YEARS:
        if not component_join[f'{year}_component'].equals(component_join[f'{year}_county']):
            raise ValueError('CBSA component population differs from county source')
        summed = joined.groupby('cbsa')[str(year)].sum().sort_index()
        if not summed.equals(published[str(year)]):
            raise ValueError('County sums differ from published CBSA totals')
        # Independent scalar arithmetic, separate from pandas aggregation.
        lookup = dict(zip(counties.fips, counties[str(year)]))
        scalar = {cbsa: sum(lookup[f] for f in group.fips)
                  for cbsa, group in us.groupby('cbsa')}
        if scalar != published[str(year)].to_dict():
            raise ValueError('Independent population arithmetic differs')
    rows = []
    for cbsa, group in us.groupby('cbsa'):
        for year in YEARS:
            rows.append({'cbsa': cbsa, 'name': group.name.iloc[0],
                         'area_type': TYPES[group.type.iloc[0]], 'scope': 'US50DC',
                         'population_year': year, 'population_vintage': 2019,
                         'boundary_vintage': 'September 2018',
                         'county_geography_date': '2019-01-01',
                         'population': int(published.loc[cbsa, str(year)]),
                         'county_count': len(group), 'county_fips': '|'.join(group.fips)})
    return pd.DataFrame(rows).sort_values(['cbsa', 'population_year']).reset_index(drop=True)


def compare_memberships(left, right, counties, left_year, right_year):
    def objects(frame):
        return {c: {'fips': set(g.fips), 'type': g.type.iloc[0], 'name': g.name.iloc[0]}
                for c, g in frame.loc[frame.scope.eq('US50DC')].groupby('cbsa')}
    a, b = objects(left), objects(right)
    pops = dict(zip(counties.fips, counties['2019']))
    rows = []
    for c in sorted(set(a) | set(b)):
        x, y = a.get(c), b.get(c)
        common = x is not None and y is not None
        missing_left = sorted(x['fips'] - pops.keys()) if x else []
        missing_right = sorted(y['fips'] - pops.keys()) if y else []
        lp = sum(pops[f] for f in x['fips']) if x and not missing_left else None
        rp = sum(pops[f] for f in y['fips']) if y and not missing_right else None
        rows.append({'cbsa': c, 'left_vintage': left_year, 'right_vintage': right_year,
                     'common_code': common, 'only_left': x is not None and y is None,
                     'only_right': y is not None and x is None,
                     'same_counties': x['fips'] == y['fips'] if common else None,
                     'same_type': x['type'] == y['type'] if common else None,
                     'same_name': x['name'] == y['name'] if common else None,
                     'left_type': TYPES[x['type']] if x else None,
                     'right_type': TYPES[y['type']] if y else None,
                     'left_missing_2019_county_keys': '|'.join(missing_left),
                     'right_missing_2019_county_keys': '|'.join(missing_right),
                     'left_population_2019_on_county_2019': lp,
                     'right_population_2019_on_county_2019': rp,
                     'population_pct_difference': 100 * (rp / lp - 1) if lp and rp else None})
    frame = pd.DataFrame(rows)
    common = frame.loc[frame.common_code]
    both_metro = common.loc[common.left_type.eq('metro') & common.right_type.eq('metro')]
    summary = {'left_vintage': left_year, 'right_vintage': right_year,
               'left_codes': len(a), 'right_codes': len(b), 'common_codes': len(common),
               'only_left': int(frame.only_left.sum()), 'only_right': int(frame.only_right.sum()),
               'common_changed_county_sets': int(common.same_counties.eq(False).sum()),
               'common_changed_types': int(common.same_type.eq(False).sum()),
               'common_changed_names': int(common.same_name.eq(False).sum()),
               'common_metro_in_both': len(both_metro),
               'common_metro_changed_county_sets': int(both_metro.same_counties.eq(False).sum()),
               'common_incomplete_county_population': int((common.left_missing_2019_county_keys.ne('') |
                                                          common.right_missing_2019_county_keys.ne('')).sum()),
               'common_abs_population_difference_over_5pct': int(common.population_pct_difference.abs().gt(5).sum()),
               'common_metro_abs_population_difference_over_5pct': int(both_metro.population_pct_difference.abs().gt(5).sum())}
    return frame, summary


def build(source, destination):
    start = time.perf_counter()
    source, destination = outside_repo(source), outside_repo(destination)
    if source == destination or source in destination.parents or destination in source.parents:
        raise ValueError('Keep source and derived folders separate')
    if destination.exists():
        raise ValueError('Preserve earlier derived reference')
    manifest = verify_sources(source)
    execution_hashes = {name: digest(PROJECT / name) for name in (
        'code/analysis/metro_population_reference.py',
        'code/analysis/prepare_metro_population_reference.py',
        'docs/protocols/metro_population_reference_20261019.md')}
    memberships = {y: read_membership(source / f'delineation_{y}.xls', y) for y in DATES}
    counties = read_county_populations(source / 'county_population_2019.csv')
    totals, components, divisions = read_cbsa_populations(source / 'cbsa_population_2019.csv')
    reference = reconcile(memberships[2018], counties, totals, components)
    summaries, comparisons = [], {}
    for a, b in [(2013, 2018), (2018, 2020), (2013, 2020)]:
        comparison, summary = compare_memberships(memberships[a], memberships[b], counties, a, b)
        comparisons[f'comparison_{a}_{b}.csv'] = comparison
        summaries.append(summary)
    totals_by_vintage = []
    for year, frame in memberships.items():
        identity = frame[['cbsa', 'type', 'scope']].drop_duplicates()
        for (scope, kind), part in identity.groupby(['scope', 'type']):
            totals_by_vintage.append({'boundary_year': year, 'scope': scope,
                                      'type': TYPES[kind], 'codes': len(part)})
    verify_sources(source)
    if any(digest(PROJECT / name) != value for name, value in execution_hashes.items()):
        raise ValueError('Execution source changed')
    destination.mkdir(parents=True, exist_ok=False)
    outputs = {'cbsa_population_reference_2017_2019.csv': reference, **comparisons,
               **{f'county_membership_{y}.csv': frame for y, frame in memberships.items()}}
    for name, frame in outputs.items():
        frame.to_csv(destination / name, index=False, lineterminator='\n')
    report = {'completed_utc': datetime.now(timezone.utc).isoformat(),
              'scope': 'public_reference_only_no_restricted_processing_or_regression',
              'source_manifest_sha256': digest(source / 'source_manifest.json'),
              'source_sha256': {r['file']: r['sha256'] for r in manifest['sources']},
              'execution_sha256': execution_hashes,
              'primary_boundary': 'September 2018', 'population_vintage': 2019,
              'population_years': list(YEARS), 'scope_primary': 'US50DC',
              'county_population_rows': len(counties), 'published_cbsa_totals': len(totals),
              'published_county_components': len(components), 'metropolitan_divisions_excluded': divisions,
              'reference_rows': len(reference), 'all_3_year_county_sums_and_components_match_exactly': True,
              'all_3_year_state_sums_match_exactly': True,
              'independent_python_sums_match_exactly': True,
              'delineation_counts': totals_by_vintage, 'comparisons': summaries,
              'output_sha256': {name: digest(destination / name) for name in outputs},
              'elapsed_seconds': time.perf_counter() - start,
              'inherited_mobility_geography_validated': False,
              'historical_county_keys_repaired': False,
              'population_reference_is_residential_opportunity_measure': False}
    with (destination / 'verification.json').open('x', encoding='utf-8') as stream:
        json.dump(report, stream, indent=2, allow_nan=False)
        stream.write('\n')
    print(json.dumps(report, indent=2))
    return report


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source', required=True, type=Path)
    parser.add_argument('--output', required=True, type=Path)
    args = parser.parse_args()
    build(args.source, args.output)
