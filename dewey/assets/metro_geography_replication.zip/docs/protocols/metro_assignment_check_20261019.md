# Bounded 2019 recorded-geography check

19 October 2026. Frozen before execution. This is separate from the completed
public-reference construction. David's 19 October file-specific approval
covers local read-only geography checks on the three named final POI files.
This check uses only `poi_indices_harmonized_2019.parquet`, its pinned source
hash, and the official public delineation/counties already acquired. It does
not authorize or access the pending annual-flow/ACS files, raw weeks, original
data-side code, employee files, coordinates or any new restricted data.

## Fixed question

For every 2019 final-file row, is the recorded `MSA_CODE` the CBSA containing
its recorded `destination_county` under the September 2018 definition?
This is internal compatibility with a proposed public reference, not an
independent geolocation audit. Neither field is assumed to be ground truth.
No outcome, visit weight, income, race, venue identity or worker field is read.

Use exact five-digit county strings, retaining leading zeroes; do not pad or
repair malformed private keys. Normalize integer-valued recorded area codes
only to their exact five-digit string. Missing/malformed keys, counties not
in the US50+DC 2019 county list, non-CBSA counties, unmatched recorded codes
and county/code disagreements remain distinct private diagnostics. They all
count as 'not demonstrated compatible' in the single national binary profile.
An unmatched code is not automatically a micropolitan or rural classification.
Puerto Rico is outside the proposed US50+DC primary reference and is reported
as outside its support, not repaired into a US county. No source code is
overwritten or recoded in the inherited data.

February 2013 and March 2020 definitions may be checked privately for diagnosis;
the September 2018 reference remains preselected. Do not choose whichever
definition yields the best fit, change the urban-scale protocol, or silently
drop conflicts. The original producer's geography method/vintage is needed
to adjudicate any disagreement. Public code-only reference comparisons are
separate from these private POI checks.

## Execution and disclosure

Read the existing private config without logging its paths. Require the
2019 filename and previously pinned SHA-256 before loading two columns.
Bind the script, public inputs and both new protocols; check input size/mtime
and code hashes after processing. Use a new private output directory outside
the repository and never overwrite. Verify counts against the Parquet footer.
Private code/county diagnostics stay in that directory. Errors must not print
data values or private paths. Do not transmit raw rows or detailed cells.

Only one proposed POI disclosure is allowed: the national 2019 binary profile
for the preselected September 2018 reference, showing compatible versus not
demonstrated compatible row counts and percentages. Require both groups to
contain at least 1,000 rows and at least 20 distinct nonmissing recorded area
codes. Otherwise withhold the entire profile, not just its small group.
This operational screen is not a formal privacy guarantee. Independent review
must inspect the exact candidate, source correspondence and whether the
combination with existing public output could expose restricted cells before
release. No other restricted counts, cross-vintage overlaps, county/code
identifiers, weighted sums or component diagnostics may leave private storage.

Passing this internal compatibility check would not establish source vintage,
correct geocoding, residential opportunity, contemporaneous contact or an
interpretable city-size regression. Failure stops attaching population to
the existing recorded areas without resolving the discrepancy. Retain all
earlier failed gates and unknowns. Original weekly replication remains separate.
