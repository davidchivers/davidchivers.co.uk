# Dated metropolitan population reference

19 October 2026. Prospective public-source check, written before acquisition
or calculation. Supplements the urban-scale protocol without changing it.

## Purpose and boundaries

Prepare population denominators and county membership on an explicitly dated
metro definition before examining a city-size gradient. Only official public
Census files are acquired. No POI, annual-flow, ACS microdata, private cell or
employee record is read. There is no regression or choice of a geography based
on an exposure coefficient. Original project files and protocols are unchanged.

Use the September 2018 OMB delineations and Vintage 2019 Population Estimates
Program (PEP) as the primary candidate reference for 2017-2019. The official
CBSA file layout states that the statistical areas use September 2018
delineations and other geographic boundaries are as of 1 January 2019.
This is a proposed common boundary for comparison, not proof that the
inherited POI or PUMS data use it. Preserve February 2013 and March 2020 county
memberships as outcome-blind comparison vintages. Do not silently overwrite
the older project PUMA-MSA2013 allocation.

## Official inputs

The Census historical-delineation page links `list1.xls` (2013),
`list1_Sep_2018.xls` (2018), and `list1_2020.xls` (2020). The official
2010-2019 PEP metro/county totals directories link `cbsa-est2019-alldata.csv`,
`co-est2019-alldata.csv`, and their PDF file layouts. Save those seven inputs
outside Git, with URL, retrieval date, bytes and SHA-256. Never substitute a
mirror or a more recent vintage without a new recorded decision. Retain the
source bytes; reruns use the exact acquired hashes rather than redownload.

## Construction and checks

1. Parse source headers, classify metropolitan versus micropolitan areas
   explicitly, and retain the county-component tables. Separate Puerto Rico
   from the 50 states plus DC; do not silently include it in US denominators.
   CBSA totals, metropolitan divisions and county components must not be
   summed together. Reject ambiguous code/type/name or county assignments.
2. Read PEP July 1 population estimates for 2017, 2018 and 2019 from one
   vintage. Validate finite positive integer populations and unique county
   keys. For each US CBSA, sum its September 2018 county components and
   reconcile exactly to each published CBSA total for all three years. Require
   exact county membership agreement between the two sources as well.
3. Produce a public reference for both metros and micros, retaining type,
   population year, population vintage, boundary vintage, county set and
   explicit US/PR scope. The intended future city regression uses metros only;
   this construction does not select a restricted-data analysis sample.
4. Compare each common code's county set and metro/micro type across 2013,
   September 2018 and March 2020. Distinguish same-code changed boundaries,
   changed classifications, and codes present on one side only. A common code
   is not sufficient evidence of a common geographic object. For comparison,
   sum the same 2019 county populations under older/newer memberships only
   where every county key matches. Otherwise leave population missing and
   list the unmatched public counties; do not invent a historical crosswalk.
5. Check a second implementation of the county-to-CBSA sums. Use artificial
   tests for duplicate/ambiguous keys, missing counties, invalid population,
   misleading same-code boundaries, population-year labels, non-US scope and
   arithmetic mismatch. Rerun from staged files and compare deterministic
   output fields and hashes. A separate reviewer checks definitions and code.

## Output and interpretation

Detailed public reference tables may remain with the public inputs outside
Git; safe aggregate checks, code, methods and explanatory graphs may enter
the project. No file is merged into the licensed POI release in this phase.
Any material population or boundary discrepancy stops readiness rather than
being repaired by choosing the best-fitting vintage. A validated public
reference still requires a separate county/venue assignment audit before it
can validate inherited `MSA_CODE` or be used for inference. Metropolitan
population is neither a city-proper count, venue count, residential diversity
benchmark nor an observation count for standard errors.
