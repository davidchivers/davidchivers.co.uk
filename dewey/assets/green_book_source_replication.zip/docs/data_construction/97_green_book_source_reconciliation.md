# Construction log: Green Book derivative consistency

19 October 2026. Local public-source audit only. No restricted files, NC layer
features or source images were read. No row-level public records were saved.

## Inputs and scope

The prior allowlist is
`output/green_book_feasibility_20261019/nypl_schema_inventory.json`.
Only its three 1947 files were processed; the 1956 derivative was excluded.
Both pinned CC0 licence texts and the pinned converter were read/fingerprinted
but the remote converter was not executed. The run refuses a data hash or
byte-length mismatch and bounds each download to five million bytes. Responses
are parsed in memory. The earlier inventory, protocol and code hashes are
stored with each aggregate-only run receipt.

| Input | SHA-256 |
|---|---|
| `greenbooks/geojson/1947.geojson` | `30a75aef82df2107d9ef1e3518efcaeb281d2b055903b6d58b4df44c2354c804` |
| `greenbook-map/scripts/data/1947.geojson` | `0bff94b57c3d6fc507b9c9f05d5e7ea75537025713812696641e1d5daf487259` |
| `greenbook-map/data/greenbook_1947.json` | `5094852115717693fd8bab259a18f12f40c0b510505aa88ad8d92940f3f57a34` |

The exact immutable URLs, byte counts, supporting-source hashes and resolved
URLs are in the safe run JSON. Repository commits are
`45328936f4984830f6916922238ed5e8c4e024b6` and
`4e5520002ee8ffcf45a1df8d81a0f1c2293ca79d` respectively.

## Transformations

The runner validates feature containers and the two geometry spellings,
excluding the one null map-source entry. It does not delete non-null records.
The source key retains exact JSON representations of year, image ID and
image region. The separate text key uses Unicode NFKC, case folding and
whitespace normalization only. Missing components invalidate that key.
Groups are counted before joining: only keys unique on both sides form
one-to-one diagnostic pairs; multiplicity is retained in multiset overlap.

Coordinates must be finite numeric Point longitude/latitude pairs in valid
ranges. Haversine displacement uses radius 6,371,008.8 metres and the frozen
bands. Validity and agreement are not independently validated historical
location. State counts map full names or two-letter labels to a fixed
50-state/DC dictionary. Unknown values remain a labelled residual.

Full-feature equality aligns the geometry spelling and removes only the
map-specific `scribe_url` property. All remaining property differences are
retained. Category possibilities use the inspected substring map, not a new
substantive classification. Ambiguous outputs are not selected to fit data.
The separate compatibility check compares each row's seven non-category
fields in order and asks whether its displayed category is permitted. It
does not recover the actual original Python 2 dictionary order.

## Execution and correction history

- Initial execution: 1.8196895 seconds; `first_run.json`, SHA-256
  `bd4fa4736d75c9c805a2ec46e6cbe889e07020bed5c999f33766aee9c7a2e274`.
  The first 19 synthetic tests passed. State counts were misreported because
  the lookup recognized abbreviations only. This is corrected, not suppressed.
  The code is retained as `audit_code_first_run.py` alongside that receipt.
- Dated addendum: `docs/protocols/green_book_source_reconciliation_addendum_20261019.md`.
  State-label fix and compatibility diagnostics were recorded before reruns.
  The original protocol and first-run outputs remain unchanged.
- Corrected run: 0.5963201 seconds; `corrected_run.json`, SHA-256
  `f7a152776dc4e95f21976546692fc03f8171ec640d83393c21c0124865d5881e`.
- Repeat: 0.7424236 seconds; `replication_run.json`, SHA-256
  `f0322cdd27dc028a0356abf50d5008e66237f4f5a812fd81f5342cf5b627468d`.
  All deterministic result fields and source identities match. Times and
  timestamps necessarily differ. The 23 then-current synthetic tests pass.
- Independent review requested direct normalized-field/category-set coverage.
  Three further regression tests were added without changing the analysis
  runner or empirical results. All 26 current synthetic tests pass. The
  execution receipts omit addendum/test hashes; the separate documentation
  manifest binds both without altering those preserved receipts.

Both corrected receipts identify the same runner and original protocol. The
documentation manifest additionally fingerprints the addendum, tests,
construction log, result note, original inventory and independent review.
No empirical income measure, modern dataset or regression was rerun.

## Reproduction

From the project root, with Python 3 standard library and network access to
the public pinned sources:

```powershell
python -B -m unittest discover -s code/analysis -p test_green_book_sources.py
python -B code/analysis/audit_green_book_sources.py --output output/green_book_source_reconciliation_20261019/new_replication.json
```

Use a new output name: the runner refuses to overwrite an existing receipt.
The prior inventory must be present at the documented project-relative path.
The plotting/publication helper additionally uses the existing Matplotlib
and Pandoc installations; no new package or service was purchased/installed.

## Interpretation and publication boundary

Only national/source-level counts, field-disagreement counts, state counts,
hashes and documentation are eligible for publication. No names, addresses,
coordinate values, source-region values, row hashes or match tables are
exported. Exact source-region equality is not firm identity. The unverified
original parser ordering is not called reproduced. No completeness, historical
ground truth, closure, discrimination or modern survival inference follows.

Website, Space and Project delivery have distinct receipts. A sourcebook
prepared locally is not a Project upload. The Project's earlier 40-file limit
and pending consolidation decision are not bypassed by this audit.
