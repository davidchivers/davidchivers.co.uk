# Diagnostic corrections after the first public-source pass

19 October 2026. The original comparison protocol and first-run receipt are
retained, not rewritten. The first run took 1.82 seconds and revealed:

- The state summary recognized two-letter codes only. All source values were
  consequently placed in `other_or_missing`. That output is a reporting bug,
  not evidence of absent geography. Add a fixed 50-state/DC name-to-code
  dictionary and synthetic tests, including Texas. Retain unknown labels in
  the explicit residual group. No state is inferred from coordinates.
- Six map-source category strings match more than one distinct output in the
  original Python 2 dictionary-based substring map. The unambiguous 790-row
  subset matches the display multiset exactly; a deterministic 796-row
  reproduction must not be claimed. Add a separate row-order check that all
  seven non-category fields agree and that each displayed category belongs
  to the permitted set for that row. Even if this passes, the original
  Python 2 dictionary ordering remains unverified.
- Add normalized-string and parser-category-set disagreement counts for the
  already prespecified source-region pairs. Raw category disagreement alone
  may reflect capitalization/format changes. This explanatory diagnostic
  does not replace raw-field counts or change the match keys.

These are transparent post-result reporting additions, not new linkage rules,
historical outcomes or an attempt to make the two source frames agree. Save
the initial code and receipt. Run the corrected code twice; retain exact
input hashes and distinguish these reruns from the initial pass.
