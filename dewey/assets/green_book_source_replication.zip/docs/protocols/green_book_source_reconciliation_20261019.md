# Green Book source reconciliation

Recorded 19 October 2026 before the record comparison. This is a public-source
consistency audit under rank 3, not a historical-modern linkage or an exposure
regression. The existing NC inventory, dated-status and file-specific rights
requirements remain unchanged.

## Scope and inputs

Use only three already inspected CC0 files at the commits and SHA256 values
in `output/green_book_feasibility_20261019/nypl_schema_inventory.json`:

- `greenbooks/geojson/1947.geojson` (the 1,056-feature derivative).
- `greenbook-map/scripts/data/1947.geojson` (797 entries, one null).
- `greenbook-map/data/greenbook_1947.json` (796 display rows).

Fetch bytes into memory; require exact earlier hashes before parsing. Inspect
and fingerprint the two pinned repository licences and the pinned
`parse_geojson.py`, but do not execute downloaded code. No listing, address,
coordinate, image-region identifier, row hash or matched-pair file is saved
or returned to an assistant. No 1956 data, scans, NC layer features, modern
POIs, proprietary files or additional historical datasets are included.

## Comparisons fixed before execution

1. Reimplement the inspected display conversion locally: non-null features
   with `geomotry` and properties, the eight declared output fields,
   longitude/latitude reversal and the documented category map. Compare
   row sequence and multiset with the display file. Check category-substring
   ambiguity separately: Python 2 dictionary iteration did not promise a
   stable first-match order. Do not silently impose an ordering if two
   distinct category outputs are possible.
2. Compare the two GeoJSON sources using two independent exact-key schemes.
   The source-region key is `(year, image_id, image_region)` with nonempty
   fields and exact JSON region representation. The text key is
   `(year, name, address, city, state)` after Unicode NFKC, case folding and
   whitespace normalization only. Require all fields. Do not strip street
   numbers, punctuation or abbreviations and do not fuzzy-match.
3. For each scheme, report missing keys, duplicate keys/rows, multiset overlap
   and uniquely paired rows. Never form Cartesian joins of duplicate keys.
   Compare the two sets of uniquely paired indices to quantify agreement;
   neither key is assumed to identify a historical firm.
4. Among unique source-region pairs, count field disagreements and coordinate
   displacement in predeclared bands: exact, (0,25m], (25,100m], (100,1000m],
   over 1000m, or invalid. These are differences between derivatives, not
   geolocation accuracy against ground truth. Report label-normalized state
   coverage for both sources and unmatched rows, not listing-level outputs.
5. Report exact full-feature multiset overlap after aligning the geometry key
   and excluding only the map-source-only `scribe_url` property. Separately
   retain the less restrictive comparisons above; do not force counts to fit.

## Verification and decision

Use synthetic cases for missing keys, duplicate multiplicities, Unicode,
category ambiguity, geometry spelling, coordinate order, row permutation and
distance boundaries. Run the real public-source comparison twice; compare
all deterministic results and input/code/protocol hashes. A focused independent
review checks parser equivalence and whether conclusions exceed the evidence.

The audit may resolve a technical source-version discrepancy. It cannot
establish complete edition coverage, national coverage, historical business
identity, discrimination, closure, survival or present-day mixing. If
differences remain, retain them explicitly rather than manufacture a bridge.
Any publication uses only reviewed aggregate diagnostics and documentation.
