"""Synthetic-only tests for public derivative comparison."""

from copy import deepcopy
import math
import unittest

from audit_green_book_sources import (
    COLS, audit, canonical_feature, category_outputs, coordinate, display_rows,
    distance_band, distance_metres, features, match_summary, norm, row_comparison,
    source_key, text_key, display_compatibility, state_counts, STATE_MAP, pair_diagnostics,
)


def feature(name="Example", address="1 Test St", region=None, geometry="geomotry"):
    return {"type": "Feature", geometry: {"type": "Point", "coordinates": [-80, 35]},
            "properties": {"name": name, "address": address, "category": "HOTELS",
                           "city": "Example City", "state": "NC", "year": 1947,
                           "image_id": "page-a", "image_region": [1, 2, 3, 4] if region is None else region,
                           "dc_url": "https://example.test/page-a"}}


def collection(*rows):
    return {"type": "FeatureCollection", "features": list(rows)}


class PublicSourceTests(unittest.TestCase):
    def test_normalization_preserves_punctuation(self):
        self.assertEqual(norm("  TEST\tStreet. "), "test street.")
        self.assertNotEqual(norm("1 Main St."), norm("1 Main Street"))

    def test_normalization_unicode(self):
        self.assertEqual(norm("\uff21"), "a")
        self.assertEqual(norm(None), "")

    def test_text_key_requires_fields(self):
        f = feature(name=" ")
        self.assertIsNone(text_key(f))

    def test_source_key_requires_region(self):
        self.assertIsNone(source_key(feature(region=[])))
        self.assertIsNone(source_key(feature(region="")))

    def test_source_key_type_is_exact(self):
        self.assertNotEqual(source_key(feature(region=[1,2])), source_key(feature(region="[1,2]")))

    def test_duplicate_keys_not_cartesian(self):
        f = feature()
        summary, pairs = match_summary([f, f], [f, f, f], source_key)
        self.assertEqual(summary["multiset_key_overlap"], 2)
        self.assertEqual(summary["unique_pairs"], 0)
        self.assertEqual(summary["shared_ambiguous_keys"], 1)
        self.assertEqual(pairs, set())

    def test_unique_pairs_and_missing(self):
        a, b, c = feature(), feature(region=[5]), feature(region=[])
        summary, pairs = match_summary([a,b,c], [b,a], source_key)
        self.assertEqual(pairs, {(0,1),(1,0)})
        self.assertEqual(summary["left"]["missing_key_rows"], 1)

    def test_multiset_does_not_hide_duplicate_loss(self):
        result = row_comparison([[1],[1]], [[1]])
        self.assertFalse(result["multiset_equal"])
        self.assertEqual(result["left_unmatched"], 1)

    def test_sequence_and_multiset_distinct(self):
        result = row_comparison([[1],[2]], [[2],[1]])
        self.assertFalse(result["sequence_equal"])
        self.assertTrue(result["multiset_equal"])

    def test_parse_coordinate_order(self):
        rows, info = display_rows(collection(feature(), None))
        self.assertEqual(rows[0][4], [35,-80])
        self.assertEqual(rows[0][2], "Hotel")
        self.assertEqual(info, {"rejected": 1, "ambiguous_category": 0})

    def test_original_parser_rejects_correct_spelling(self):
        rows, info = display_rows(collection(feature(geometry="geometry")))
        self.assertEqual(rows, [])
        self.assertEqual(info["rejected"], 1)

    def test_ambiguous_category_not_arbitrary(self):
        f = feature()
        f["properties"]["category"] = "hotel restaurant"
        rows, info = display_rows(collection(f))
        self.assertEqual(rows, [])
        self.assertEqual(info["ambiguous_category"], 1)

    def test_category_fallback_and_plural(self):
        self.assertEqual(category_outputs("OTHER"), {"Other"})
        self.assertEqual(category_outputs("Tourists Homes"), {"Tourist home"})
        with self.assertRaises(ValueError):
            category_outputs(None)

    def test_state_names_and_abbreviations(self):
        a, b = feature(), feature()
        a["properties"]["state"] = " North Carolina "
        b["properties"]["state"] = "Texas"
        self.assertEqual(state_counts([a,b,feature()]), {"NC": 2, "TX": 1})
        self.assertEqual(len(set(STATE_MAP.values())), 51)

    def test_unknown_state_not_assigned(self):
        f = feature()
        f["properties"]["state"] = "not a state"
        self.assertEqual(state_counts([f]), {"<other_or_missing>": 1})

    def test_ambiguous_display_compatible_not_deterministically_reproduced(self):
        f = feature()
        rows, _ = display_rows(collection(f))
        f["properties"]["category"] = "Hotels Restaurants"
        result = display_compatibility(collection(f), {"rows": rows})
        self.assertTrue(result["every_row_individually_compatible"])
        self.assertEqual(result["ambiguous_category_rows"], 1)
        self.assertFalse(result["original_python2_dictionary_order_verified"])
        rows[0][2] = "Other"
        self.assertFalse(display_compatibility(collection(f), {"rows": rows})["every_row_individually_compatible"])

    def test_display_missing_extra_rows_not_compatible(self):
        rows, _ = display_rows(collection(feature()))
        self.assertFalse(display_compatibility(collection(feature()), {"rows": rows + rows})["every_row_individually_compatible"])

    def test_raw_only_disagreement(self):
        a, b = feature(), feature()
        b["properties"]["category"] = " hotels "
        b["properties"]["city"] = " example city "
        result = pair_diagnostics([a],[b],{(0,0)})
        self.assertEqual(result["raw_property_disagreement_counts"]["category"],1)
        self.assertEqual(result["normalized_text_disagreement_counts"]["category"],0)
        self.assertEqual(result["raw_property_disagreement_counts"]["city"],1)
        self.assertEqual(result["normalized_text_disagreement_counts"]["city"],0)
        self.assertEqual(result["parser_category_output_sets_differ"],0)

    def test_category_sets_unequal_but_intersect(self):
        a, b = feature(), feature()
        b["properties"]["category"] = "Hotels and Restaurants"
        result = pair_diagnostics([a],[b],{(0,0)})
        self.assertEqual(result["parser_category_output_sets_differ"],1)
        self.assertEqual(result["parser_category_output_sets_disjoint"],0)

    def test_category_sets_disjoint(self):
        a, b = feature(), feature()
        b["properties"]["category"] = "Restaurants"
        result = pair_diagnostics([a],[b],{(0,0)})
        self.assertEqual(result["parser_category_output_sets_differ"],1)
        self.assertEqual(result["parser_category_output_sets_disjoint"],1)

    def test_coordinate_invalid(self):
        for c in ([181,0], [0,91], [math.nan,0], [True,0], [0], "0,0"):
            with self.subTest(coordinate_type=type(c).__name__):
                f = feature()
                f["geomotry"]["coordinates"] = c
                self.assertIsNone(coordinate(f))

    def test_distance_known_and_symmetric(self):
        self.assertEqual(distance_metres((0,0),(0,0)), 0)
        self.assertAlmostEqual(distance_metres((0,0),(1,0)), 111195.0802335329)
        self.assertEqual(distance_metres((-80,35),(-75,40)), distance_metres((-75,40),(-80,35)))

    def test_distance_bands(self):
        for value, label in ((None,"invalid"),(0,"exact"),(1,"0_to_25m"),(25,"0_to_25m"),
                             (25.01,"25_to_100m"),(100,"25_to_100m"),
                             (100.01,"100_to_1000m"),(1000,"100_to_1000m"),(1001,"over_1000m")):
            with self.subTest(value=value):
                self.assertEqual(distance_band(value), label)

    def test_null_feature_removed_but_schema_checked(self):
        self.assertEqual(len(features(collection(None,feature()))), 1)
        f = feature()
        f["geometry"] = f["geomotry"]
        with self.assertRaises(ValueError):
            features(collection(f))

    def test_canonical_feature_aligns_only_intended_fields(self):
        a, b = feature(geometry="geometry"), feature()
        b["properties"]["scribe_url"] = "synthetic"
        self.assertEqual(canonical_feature(a), canonical_feature(b))
        b["properties"]["name"] = "Different"
        self.assertNotEqual(canonical_feature(a), canonical_feature(b))

    def test_full_audit_detects_distinct_source_and_text_partners(self):
        a, b = feature(), feature(name="Second", address="2 Test St", region=[5])
        c, d = deepcopy(a), deepcopy(b)
        c["properties"]["image_region"], d["properties"]["image_region"] = [5], [1,2,3,4]
        left, right = collection(a,b), collection(c,d)
        rows, _ = display_rows(right)
        result = audit(left,right,{"rows":rows,"cols":COLS,"totalrows":2,"year":"1947"})
        self.assertTrue(result["display_reproduction"]["sequence_equal"])
        self.assertEqual(result["key_agreement"]["different_partners_among_dual_linked"], 2)
        self.assertEqual(result["source_region_pair_diagnostics"]["raw_property_disagreement_counts"]["name"], 2)


if __name__ == "__main__":
    unittest.main()
