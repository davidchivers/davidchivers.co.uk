"""Compare three pinned public CC0 derivatives in memory; emit no listing rows."""

from __future__ import annotations

import argparse
from collections import Counter, defaultdict
from datetime import datetime, timezone
import hashlib
import json
import math
from pathlib import Path
import time
import unicodedata
from urllib.request import Request, urlopen

ROOT = Path(__file__).resolve().parents[2]
BASELINE = ROOT / "output/green_book_feasibility_20261019/nypl_schema_inventory.json"
PROTOCOL = ROOT / "docs/protocols/green_book_source_reconciliation_20261019.md"
COLS = ["name", "address", "type", "year", "latlng", "url", "image_id", "image_region"]
TYPE_MAP = [
    ("tourist ho", "tourist home"), ("tourists ho", "tourist home"),
    ("hotel", "hotel"), ("motel", "motel"), ("restaurant", "restaurant"),
    ("tavern", "tavern"), ("service station", "service station"),
    ("liquor store", "liquor store"), ("night club", "night club"),
    ("road house", "road house"),
]
STATE_NAMES = """AL|Alabama;AK|Alaska;AZ|Arizona;AR|Arkansas;CA|California;
CO|Colorado;CT|Connecticut;DE|Delaware;DC|District of Columbia;FL|Florida;
GA|Georgia;HI|Hawaii;ID|Idaho;IL|Illinois;IN|Indiana;IA|Iowa;KS|Kansas;
KY|Kentucky;LA|Louisiana;ME|Maine;MD|Maryland;MA|Massachusetts;MI|Michigan;
MN|Minnesota;MS|Mississippi;MO|Missouri;MT|Montana;NE|Nebraska;NV|Nevada;
NH|New Hampshire;NJ|New Jersey;NM|New Mexico;NY|New York;NC|North Carolina;
ND|North Dakota;OH|Ohio;OK|Oklahoma;OR|Oregon;PA|Pennsylvania;RI|Rhode Island;
SC|South Carolina;SD|South Dakota;TN|Tennessee;TX|Texas;UT|Utah;VT|Vermont;
VA|Virginia;WA|Washington;WV|West Virginia;WI|Wisconsin;WY|Wyoming"""
STATE_MAP = {label.upper(): code for pair in STATE_NAMES.split(";")
             for code, name in [pair.strip().split("|")] for label in (code, name)}


def digest(data):
    return hashlib.sha256(data).hexdigest()


def frozen(value):
    return json.dumps(value, sort_keys=True, ensure_ascii=True, allow_nan=False,
                      separators=(",", ":"))


def norm(value):
    if value is None:
        return ""
    return " ".join(unicodedata.normalize("NFKC", str(value)).casefold().split())


def present(value):
    return value is not None and value != "" and value != [] and value != {}


def fetch(url, expected=None):
    request = Request(url, headers={"User-Agent": "Dewey-public-source-audit/1.0"})
    with urlopen(request, timeout=45) as response:
        if response.status != 200:
            raise ValueError("Public source did not return HTTP 200")
        data = response.read(5_000_001)
        final_url = response.url
    if len(data) > 5_000_000:
        raise ValueError("Public source exceeds the bounded download limit")
    if expected is not None and digest(data) != expected:
        raise ValueError("Pinned public source hash differs from prior inventory")
    return data, {"url": url, "resolved_url": final_url, "bytes": len(data),
                  "sha256": digest(data)}


def category_outputs(value):
    if not isinstance(value, str):
        raise ValueError("Unexpected category type; no rows emitted")
    candidates = {replacement.capitalize() for part, replacement in TYPE_MAP
                  if part in value.lower()}
    return candidates or {value.lower().capitalize()}


def display_rows(collection):
    rows = []
    rejected = ambiguous = 0
    for feature in collection["features"]:
        if not feature or "geomotry" not in feature or "properties" not in feature:
            rejected += 1
            continue
        p = feature["properties"]
        choices = category_outputs(p["category"])
        if len(choices) != 1:
            ambiguous += 1
            continue
        coord = feature["geomotry"]["coordinates"]
        rows.append([p["name"], p["address"], next(iter(choices)), p["year"],
                     [coord[1], coord[0]], p["dc_url"], p["image_id"], p["image_region"]])
    return rows, {"rejected": rejected, "ambiguous_category": ambiguous}


def row_comparison(left, right):
    a, b = Counter(map(frozen, left)), Counter(map(frozen, right))
    return {"left_rows": len(left), "right_rows": len(right),
            "sequence_equal": left == right, "multiset_equal": a == b,
            "multiset_overlap": sum((a & b).values()),
            "left_unmatched": sum((a-b).values()), "right_unmatched": sum((b-a).values())}


def display_compatibility(collection, display):
    selected = [f for f in collection["features"]
                if f and "geomotry" in f and "properties" in f]
    same_length = len(selected) == len(display["rows"])
    noncategory_mismatches = incompatible = ambiguous = 0
    for f, row in zip(selected, display["rows"]):
        p, c = f["properties"], f["geomotry"]["coordinates"]
        expected = [p["name"], p["address"], p["year"], [c[1], c[0]],
                    p["dc_url"], p["image_id"], p["image_region"]]
        actual = [v for i, v in enumerate(row) if i != 2]
        noncategory_mismatches += expected != actual
        choices = category_outputs(p["category"])
        incompatible += row[2] not in choices
        ambiguous += len(choices) > 1
    return {"same_row_count": same_length, "noncategory_sequence_mismatch_rows": noncategory_mismatches,
            "category_output_incompatible_rows": incompatible, "ambiguous_category_rows": ambiguous,
            "every_row_individually_compatible": same_length and noncategory_mismatches == incompatible == 0,
            "original_python2_dictionary_order_verified": False}


def features(collection):
    if collection.get("type") != "FeatureCollection":
        raise ValueError("Unexpected GeoJSON container")
    valid = []
    for f in collection["features"]:
        if f is None:
            continue
        if f.get("type") != "Feature" or not isinstance(f.get("properties"), dict):
            raise ValueError("Unexpected feature schema; no rows emitted")
        if ("geometry" in f) == ("geomotry" in f):
            raise ValueError("Need exactly one geometry spelling per feature")
        valid.append(f)
    return valid


def source_key(f):
    p = f["properties"]
    fields = [p.get(k) for k in ("year", "image_id", "image_region")]
    if not all(present(v) for v in fields):
        return None
    return tuple(map(frozen, fields))


def text_key(f):
    p = f["properties"]
    fields = tuple(norm(p.get(k)) for k in ("year", "name", "address", "city", "state"))
    return fields if all(fields) else None


def match_summary(left, right, key):
    groups = []
    metadata = []
    for rows in (left, right):
        group = defaultdict(list)
        missing = 0
        for i, f in enumerate(rows):
            k = key(f)
            if k is None:
                missing += 1
            else:
                group[k].append(i)
        groups.append(group)
        metadata.append({"rows": len(rows), "missing_key_rows": missing,
                         "distinct_keys": len(group),
                         "duplicate_keys": sum(len(v) > 1 for v in group.values()),
                         "rows_in_duplicate_keys": sum(len(v) for v in group.values() if len(v) > 1)})
    a, b = groups
    common = a.keys() & b.keys()
    pairs = {(a[k][0], b[k][0]) for k in common if len(a[k]) == len(b[k]) == 1}
    matched_left = {i for i, _ in pairs}
    matched_right = {j for _, j in pairs}
    overlap = sum(min(len(a[k]), len(b[k])) for k in common)
    return {"left": metadata[0], "right": metadata[1], "shared_keys": len(common),
            "multiset_key_overlap": overlap, "unique_pairs": len(pairs),
            "shared_ambiguous_keys": sum(len(a[k]) != 1 or len(b[k]) != 1 for k in common),
            "left_rows_without_unique_pair": len(left)-len(matched_left),
            "right_rows_without_unique_pair": len(right)-len(matched_right)}, pairs


def coordinate(f):
    geom = f.get("geometry", f.get("geomotry"))
    if not isinstance(geom, dict) or geom.get("type") != "Point":
        return None
    c = geom.get("coordinates")
    if not isinstance(c, list) or len(c) != 2:
        return None
    if any(isinstance(v, bool) or not isinstance(v, (int, float)) or not math.isfinite(v) for v in c):
        return None
    lon, lat = c
    return (lon, lat) if -180 <= lon <= 180 and -90 <= lat <= 90 else None


def distance_metres(a, b):
    lon1, lat1, lon2, lat2 = map(math.radians, (*a, *b))
    h = math.sin((lat2-lat1)/2)**2 + math.cos(lat1)*math.cos(lat2)*math.sin((lon2-lon1)/2)**2
    return 6371008.8 * 2 * math.asin(math.sqrt(min(1, max(0, h))))


def distance_band(value):
    if value is None:
        return "invalid"
    for bound, label in ((0, "exact"), (25, "0_to_25m"), (100, "25_to_100m"),
                         (1000, "100_to_1000m")):
        if value <= bound:
            return label
    return "over_1000m"


def state_counts(rows):
    result = Counter()
    for f in rows:
        label = norm(f["properties"].get("state")).upper()
        result[STATE_MAP.get(label, "<other_or_missing>")] += 1
    return dict(sorted(result.items()))


def coverage(rows):
    coords = [coordinate(f) for f in rows]
    city_states = {(norm(f["properties"].get("city")), norm(f["properties"].get("state"))) for f in rows}
    return {"rows": len(rows), "state_counts": state_counts(rows),
            "city_state_labels": len(city_states),
            "valid_coordinates": sum(c is not None for c in coords),
            "unique_valid_coordinates": len({c for c in coords if c is not None})}


def canonical_feature(f):
    return {"properties": {k: v for k, v in f["properties"].items() if k != "scribe_url"},
            "geometry": f.get("geometry", f.get("geomotry")), "type": f["type"]}


def pair_diagnostics(left, right, pairs):
    fields = sorted({k for i, j in pairs for p in (left[i]["properties"], right[j]["properties"]) for k in p})
    disagreement = Counter({k: 0 for k in fields})
    normalized_disagreement = Counter({k: 0 for k in ("name", "address", "city", "state", "category")})
    category_disjoint = category_sets_different = 0
    bands = Counter({k: 0 for k in ("exact", "0_to_25m", "25_to_100m", "100_to_1000m", "over_1000m", "invalid")})
    for i, j in pairs:
        a, b = left[i], right[j]
        for k in fields:
            pa, pb = a["properties"], b["properties"]
            if (k in pa) != (k in pb) or frozen(pa.get(k)) != frozen(pb.get(k)):
                disagreement[k] += 1
        for k in normalized_disagreement:
            normalized_disagreement[k] += norm(a["properties"].get(k)) != norm(b["properties"].get(k))
        ac = category_outputs(a["properties"]["category"])
        bc = category_outputs(b["properties"]["category"])
        category_disjoint += not bool(ac & bc)
        category_sets_different += ac != bc
        ca, cb = coordinate(a), coordinate(b)
        bands[distance_band(distance_metres(ca, cb) if ca is not None and cb is not None else None)] += 1
    return {"unique_source_region_pairs": len(pairs), "raw_property_disagreement_counts": dict(disagreement),
            "normalized_text_disagreement_counts": dict(normalized_disagreement),
            "parser_category_output_sets_differ": category_sets_different,
            "parser_category_output_sets_disjoint": category_disjoint,
            "coordinate_displacement_bands": dict(bands),
            "left_without_unique_pair_state_counts": state_counts([f for i, f in enumerate(left) if i not in {x for x, _ in pairs}]),
            "right_without_unique_pair_state_counts": state_counts([f for j, f in enumerate(right) if j not in {y for _, y in pairs}])}


def audit(a, b, display):
    left, right = features(a), features(b)
    rebuilt, parse_info = display_rows(b)
    canonical_rebuilt, canonical_info = display_rows(a)
    region, rpairs = match_summary(left, right, source_key)
    text, tpairs = match_summary(left, right, text_key)
    rmap = dict(rpairs)
    tmap = dict(tpairs)
    dual = rmap.keys() & tmap.keys()
    return {"coverage": {"greenbooks": coverage(left), "map_source": coverage(right)},
            "display_reproduction": {**row_comparison(rebuilt, display["rows"]), **parse_info,
                                     "columns_equal": display["cols"] == COLS,
                                     "declared_count_equal": display["totalrows"] == len(display["rows"]),
                                     "declared_year_is_1947": str(display["year"]) == "1947"},
            "display_compatibility": display_compatibility(b, display),
            "literal_original_parser_on_greenbooks": {**canonical_info, "rows": len(canonical_rebuilt)},
            "source_region_key": region, "normalized_text_key": text,
            "key_agreement": {"pair_intersection": len(rpairs & tpairs), "region_pairs_only": len(rpairs-tpairs),
                              "text_pairs_only": len(tpairs-rpairs), "left_rows_linked_by_both_keys": len(dual),
                              "different_partners_among_dual_linked": sum(rmap[i] != tmap[i] for i in dual)},
            "source_region_pair_diagnostics": pair_diagnostics(left, right, rpairs),
            "full_feature_comparison": row_comparison([canonical_feature(f) for f in left],
                                                       [canonical_feature(f) for f in right])}


def run(output):
    start = time.perf_counter()
    baseline_bytes = BASELINE.read_bytes()
    baseline = json.loads(baseline_bytes)
    inputs = []
    objects = {}
    for entry in baseline["files"]:
        url = entry["url"]
        if "1956" in url:
            continue
        data, receipt = fetch(url, entry["sha256"])
        if len(data) != entry["bytes"]:
            raise ValueError("Pinned source length mismatch")
        inputs.append(receipt)
        label = "display" if url.endswith("greenbook_1947.json") else "map" if "/greenbook-map/" in url else "canonical"
        if label in objects:
            raise ValueError("Unexpected repeated source role")
        objects[label] = json.loads(data)
    if set(objects) != {"canonical", "map", "display"}:
        raise ValueError("Missing approved source")
    supporting = []
    for repo in baseline["repositories"]:
        url = repo["url"].replace("https://github.com/", "https://raw.githubusercontent.com/") + "/" + repo["commit"] + "/LICENSE"
        data, receipt = fetch(url)
        if b"CC0" not in data or b"1.0" not in data:
            raise ValueError("Pinned licence does not contain expected CC0 identifier")
        supporting.append(receipt)
    _, receipt = fetch(baseline["scripts_read_not_executed"][0])
    supporting.append(receipt)
    report = {"schema_version": 1, "checked_at_utc": datetime.now(timezone.utc).isoformat(),
              "elapsed_seconds": time.perf_counter()-start,
              "handling": "Pinned public CC0 derivatives parsed in memory; aggregate-only output; no raw persistence or historical-modern linkage.",
              "inputs": inputs, "supporting_sources": supporting,
              "local_sources": {"prior_inventory_sha256": digest(baseline_bytes),
                                "code_sha256": digest(Path(__file__).read_bytes()),
                                "protocol_sha256": digest(PROTOCOL.read_bytes())},
              "results": audit(objects["canonical"], objects["map"], objects["display"])}
    report["elapsed_seconds"] = time.perf_counter()-start
    output = Path(output)
    output.parent.mkdir(parents=True, exist_ok=True)
    if output.exists():
        raise ValueError("Refusing to overwrite an existing audit receipt")
    output.write_text(json.dumps(report, indent=2, ensure_ascii=True, allow_nan=False)+"\n", encoding="utf-8")
    print(json.dumps({"output": output.name, "sha256": digest(output.read_bytes()),
                      "elapsed_seconds": report["elapsed_seconds"], "display_exact": report["results"]["display_reproduction"]["sequence_equal"]}))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    run(args.output)
