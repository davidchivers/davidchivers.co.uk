"""Bounded local adapter; currently exercised only on artificial Parquet files.

No default input paths, CLI data runner, downloads or public export. The explicit
execution acknowledgement is a guard, not human authorization or a licence.
Every output, including city aggregates and diagnostics, remains private.
"""

from __future__ import annotations

from collections import Counter
from datetime import datetime, timezone
from decimal import Decimal
import hashlib
import json
import math
from numbers import Integral, Real
from pathlib import Path
import platform
import re
import sqlite3
import time

import numpy as np
import pandas as pd
import pyarrow
import pyarrow.parquet as pq

from urban_scale_flow_contract import reconstruct_income_mass
from urban_scale_information import decompose_city_year_information


PROJECT = Path(__file__).resolve().parents[2]
REPOSITORY = PROJECT.parents[1]
VARIANTS = ("tdw", "strict")
RTOL, ATOL = 1e-9, 1e-8
SOURCE_ROLES = ("flow", "lookup", "poi")
METRICS = {
    "ses_frac_nat": "fractionalization",
    "ses_entropy_nat": "entropy_nats",
    "ses_entropy_norm_nat": "entropy_normalized",
    "nat_decile_flow_coverage": "coverage_of_known_positive_weight",
}
LOOKUP_COLUMNS = ("cbg", "nat_decile_tdw", "nat_decile_nhgis", "nat_decile_strict")
FLOW_COLUMNS = ("ID_STORE", "MSA_CODE", "combined_category", "cbg_visits_json")
POI_COLUMNS = (
    "year", "ID_STORE", "MSA_CODE", "combined_category", "SUB_CATEGORY",
    "destination_county", "total_origin_visit_weight",
    *(f"{metric}_{variant}" for variant in VARIANTS for metric in METRICS),
)
EXECUTION_FILES = (
    Path(__file__).resolve(),
    Path(__file__).with_name("urban_scale_flow_contract.py"),
    Path(__file__).with_name("urban_scale_information.py"),
    PROJECT / "docs/protocols/urban_scale_information_pilot_20261019.md",
    PROJECT / "docs/protocols/urban_scale_engineering_adapter_20261019.md",
)


class PilotError(ValueError):
    """A fixed, source-value-free error suitable for the calling log."""


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def selected_id(identifier: str, modulus: int, bucket: int) -> bool:
    digest = hashlib.sha256(identifier.encode("utf-8")).digest()
    return int.from_bytes(digest[:8], "big") % modulus == bucket


def _missing(value) -> bool:
    return value is None or isinstance(value, float) and math.isnan(value)


def _label(value):
    if value is None:
        return None
    if not isinstance(value, str):
        raise PilotError("Invalid string metadata type")
    return value if value.strip() else None


def _identifier(value):
    result = _label(value)
    if result is None:
        raise PilotError("Missing identifier")
    return result


def _area_code(value):
    if value is None:
        return None
    if isinstance(value, str):
        if not value.strip():
            return None
        if re.fullmatch(r"[0-9]{5}", value):
            return value
    elif not isinstance(value, bool) and isinstance(value, (Integral, Decimal)):
        if value.is_finite() if isinstance(value, Decimal) else True:
            if 0 <= value <= 99999 and value == int(value):
                return f"{int(value):05d}"
    raise PilotError("Invalid recorded area code")


def _county(value):
    value = _label(value)
    if value is not None and not re.fullmatch(r"[0-9]{5}", value):
        raise PilotError("Invalid destination county code")
    return value


def _group(value):
    if _missing(value):
        return None
    if isinstance(value, bool) or not isinstance(value, Integral) or not 1 <= value <= 10:
        raise PilotError("Invalid income-group label; missing codes require explicit review")
    return int(value)


def _metric(value):
    if _missing(value):
        return None
    if isinstance(value, bool) or not isinstance(value, Real) or not math.isfinite(value):
        raise PilotError("Invalid final-file numeric metric")
    return float(value)


def _rows(path, columns, batch_size):
    with pq.ParquetFile(path) as source:
        names = source.schema_arrow.names
        if len(names) != len(set(names)) or not set(columns).issubset(names):
            raise PilotError("Missing or duplicated required Parquet columns")
        for batch in source.iter_batches(batch_size=batch_size, columns=list(columns)):
            # No table/row is returned to the terminal or a model-facing log.
            yield from batch.to_pylist()


def _json_safe(value):
    if isinstance(value, dict):
        return {str(key): _json_safe(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [_json_safe(item) for item in value]
    if isinstance(value, float) and math.isnan(value):
        return None
    if hasattr(value, "item"):
        return _json_safe(value.item())
    return value


def _write_json(path, value):
    try:
        encoded = json.dumps(_json_safe(value), indent=2, allow_nan=False) + "\n"
        with path.open("x", encoding="utf-8") as stream:
            stream.write(encoded)
    except (OSError, TypeError, ValueError):
        raise PilotError("Private JSON output could not be safely written; paths suppressed") from None


def _compare(checks, name, rebuilt, inherited):
    entry = checks.setdefault(name, {"checked": 0, "mismatches": 0, "max_absolute_error": 0.0})
    entry["checked"] += 1
    if rebuilt is None or inherited is None:
        same = rebuilt is None and inherited is None
    else:
        difference = abs(rebuilt - inherited)
        if not math.isfinite(difference):
            raise PilotError("Metric difference overflow; comparison is undefined")
        entry["max_absolute_error"] = max(entry["max_absolute_error"], difference)
        same = math.isclose(rebuilt, inherited, rel_tol=RTOL, abs_tol=ATOL)
    entry["mismatches"] += int(not same)


def _load_lookup(path, batch_size, cap, diagnostics):
    maps = {variant: {} for variant in VARIANTS}
    for row in _rows(path, LOOKUP_COLUMNS, batch_size):
        cbg = row["cbg"]
        if not isinstance(cbg, str) or not re.fullmatch(r"[0-9]{12}", cbg):
            raise PilotError("Invalid CBG lookup identifier")
        if cbg in maps["tdw"]:
            raise PilotError("Duplicate CBG lookup identifier")
        if len(maps["tdw"]) >= cap:
            raise PilotError("Lookup resource cap exceeded; no truncation performed")
        groups = {variant: _group(row[f"nat_decile_{variant}"]) for variant in VARIANTS}
        if groups["tdw"] != _group(row["nat_decile_nhgis"]):
            raise PilotError("Preferred and NHGIS group aliases disagree")
        for variant in VARIANTS:
            maps[variant][cbg] = groups[variant]
        diagnostics["lookup_rows"] += 1
    if not diagnostics["lookup_rows"]:
        raise PilotError("Empty lookup")
    return maps


def _load_pois(con, path, batch_size, diagnostics):
    con.execute("CREATE TABLE poi (id TEXT PRIMARY KEY, payload TEXT NOT NULL)")
    for row in _rows(path, POI_COLUMNS, batch_size):
        if isinstance(row["year"], bool) or not isinstance(row["year"], Integral) or row["year"] != 2019:
            raise PilotError("Unexpected final-file year")
        identifier = _identifier(row["ID_STORE"])
        payload = {
            "city": _area_code(row["MSA_CODE"]),
            "combined": _label(row["combined_category"]),
            "category": _label(row["SUB_CATEGORY"]),
            "area": _county(row["destination_county"]),
            "total_origin_visit_weight": _metric(row["total_origin_visit_weight"]),
        }
        for variant in VARIANTS:
            for metric in METRICS:
                name = f"{metric}_{variant}"
                payload[name] = _metric(row[name])
        try:
            con.execute("INSERT INTO poi VALUES (?,?)", (identifier, json.dumps(payload, allow_nan=False)))
        except sqlite3.IntegrityError:
            raise PilotError("Duplicate final-file venue identifier") from None
        diagnostics["poi_rows"] += 1
        if diagnostics["poi_rows"] % batch_size == 0:
            con.commit()
    con.commit()
    if not diagnostics["poi_rows"]:
        raise PilotError("Empty final POI input")


def _load_flows(con, path, maps, config, diagnostics):
    con.execute("CREATE TABLE seen_flow (id TEXT PRIMARY KEY)")
    con.execute("""CREATE TABLE retained (
        id TEXT, variant TEXT, city TEXT, category TEXT, area TEXT, masses TEXT,
        PRIMARY KEY (id,variant))""")
    totals = {variant: {name: [] for name in (
        "known_positive_weight", "classified_weight", "unclassified_weight"
    )} for variant in VARIANTS}
    for row in _rows(path, FLOW_COLUMNS, config["batch_size"]):
        identifier = _identifier(row["ID_STORE"])
        try:
            con.execute("INSERT INTO seen_flow VALUES (?)", (identifier,))
        except sqlite3.IntegrityError:
            raise PilotError("Duplicate annual-flow venue identifier") from None
        diagnostics["flow_rows"] += 1
        if diagnostics["flow_rows"] % config["batch_size"] == 0:
            con.commit()
        selected = selected_id(identifier, config["sample_modulus"], config["sample_bucket"])
        diagnostics["selected_flow_rows"] += int(selected)
        if diagnostics["selected_flow_rows"] > config["max_selected_venues"]:
            raise PilotError("Selected-venue resource cap exceeded; no truncation performed")
        city, combined = _area_code(row["MSA_CODE"]), _label(row["combined_category"])
        match = con.execute("SELECT payload FROM poi WHERE id=?", (identifier,)).fetchone()
        if match is None:
            diagnostics["flow_without_poi"] += 1
            continue
        poi = json.loads(match[0])
        diagnostics["matched_ids"] += 1
        metadata_ok = True
        for name, observed in (("city", city), ("combined", combined)):
            if observed != poi[name]:
                diagnostics["metadata_conflicts"][name] += 1
                metadata_ok = False
        if not selected or not metadata_ok:
            continue
        diagnostics["selected_matched_rows"] += 1
        for variant in VARIANTS:
            try:
                mass = reconstruct_income_mass(row["cbg_visits_json"], maps[variant])
            except (TypeError, ValueError, OverflowError):
                raise PilotError("Selected origin flow failed its reconstruction contract") from None
            if variant == "tdw":
                _compare(diagnostics["reconciliation"], "total_origin_visit_weight",
                         mass.known_positive_weight, poi["total_origin_visit_weight"])
            for prefix, attribute in METRICS.items():
                name = f"{prefix}_{variant}"
                _compare(diagnostics["reconciliation"], name, getattr(mass, attribute), poi[name])
            for name in totals[variant]:
                totals[variant][name].append(getattr(mass, name))
            coverage = diagnostics["variant_support"][variant]
            coverage["null_weight_entries"] += mass.null_weight_entries
            coverage["zero_weight_entries"] += mass.zero_weight_entries
            flags = {
                "missing_recorded_area": poi["city"] is None,
                "missing_destination_county": poi["area"] is None,
                "missing_subcategory": poi["category"] is None,
                "no_classified_mass": mass.classified_weight <= 0,
            }
            for name, present in flags.items():
                coverage["overlapping_exclusion_flags"][name] += int(present)
            exclusion = next((name for name, present in flags.items() if present), None)
            if exclusion:
                coverage["disjoint_exclusions"][exclusion] += 1
                continue
            coverage["retained_venues"] += 1
            con.execute("INSERT INTO retained VALUES (?,?,?,?,?,?)", (
                identifier, variant, poi["city"], poi["category"], poi["area"],
                json.dumps(mass.group_mass, allow_nan=False),
            ))
    con.commit()
    diagnostics["poi_without_flow"] = con.execute("""SELECT count(*) FROM poi p
        LEFT JOIN seen_flow f ON p.id=f.id WHERE f.id IS NULL""").fetchone()[0]
    for variant in VARIANTS:
        coverage = diagnostics["variant_support"][variant]
        coverage["mass_scope"] = "selected_matched_metadata_consistent_rows_before_geography_exclusions"
        coverage.update({name: math.fsum(values) for name, values in totals[variant].items()})
        total = coverage["known_positive_weight"]
        coverage["coverage_of_known_positive_weight"] = coverage["classified_weight"] / total if total else None
        if (coverage["retained_venues"] + sum(coverage["disjoint_exclusions"].values())
                != diagnostics["selected_matched_rows"]):
            raise PilotError("Selected support ledger failed to reconcile")
    if not diagnostics["flow_rows"]:
        raise PilotError("Empty annual-flow input")
    if diagnostics["flow_without_poi"] or diagnostics["poi_without_flow"]:
        raise PilotError("Venue ID rosters differ; every decomposition withheld")
    if sum(diagnostics["metadata_conflicts"].values()):
        raise PilotError("Venue metadata conflict; every decomposition withheld")
    if any(check["mismatches"] for check in diagnostics["reconciliation"].values()):
        raise PilotError("Inherited scalar reconciliation failed; every decomposition withheld")
    if not diagnostics["selected_matched_rows"]:
        raise PilotError("Deterministic engineering sample is empty")


def _decompose(con):
    results = []
    keys = con.execute("SELECT DISTINCT variant,city FROM retained ORDER BY variant,city").fetchall()
    for variant, city in keys:
        records = []
        for identifier, category, area, blob in con.execute("""SELECT id,category,area,masses
                FROM retained WHERE variant=? AND city=? ORDER BY id""", (variant, city)):
            for group, mass in enumerate(json.loads(blob), start=1):
                records.append({"city": city, "year": 2019, "venue": identifier,
                                "category": category, "area": area, "group": group, "mass": mass})
        frame = pd.DataFrame.from_records(records)
        outcome = decompose_city_year_information(
            frame, group_universe=tuple(range(1, 11)), missing_group_cells="error"
        ).to_dict("records")[0]
        outcome["variant"] = variant
        outcome["interpretation"] = "destination_based_engineering_sample_not_a_city_population_estimate"
        results.append(outcome)
    return results


def execute_pilot(
    paths, expected_sha256, private_output, *, source_kind,
    acknowledge_local_processing=False, year=2019, acs_end_year=2019,
    cbg_vintage=2020, sample_modulus=1000, sample_bucket=0,
    batch_size=1024, max_lookup_rows=500000, max_selected_venues=20000,
):
    """Run only with separately documented human approval for the exact inputs.

    Tests pass source_kind='synthetic_fixture' and use temporary artificial files.
    The implementation does not certify the caller's declaration or permission.
    Hash equality and size/mtime stability do not establish source correctness.
    The returned value is the private receipt path, never the data or results.
    """
    if acknowledge_local_processing is not True:
        raise PilotError("Explicit execution acknowledgement required; not a substitute for human permission")
    if source_kind not in ("synthetic_fixture", "restricted_local"):
        raise PilotError("Source kind must be explicitly declared")
    if any(isinstance(value, bool) or not isinstance(value, Integral) for value in (year, acs_end_year, cbg_vintage)):
        raise PilotError("Explicit integer provenance years are required")
    if (year, acs_end_year, cbg_vintage) != (2019, 2019, 2020):
        raise PilotError("This adapter is only for the predeclared 2019 harmonized pilot")
    config = dict(sample_modulus=sample_modulus, sample_bucket=sample_bucket,
                  batch_size=batch_size, max_lookup_rows=max_lookup_rows,
                  max_selected_venues=max_selected_venues)
    if any(isinstance(value, bool) or not isinstance(value, Integral) for value in config.values()):
        raise PilotError("Integer sampling and resource settings required")
    if not (sample_modulus >= 1 and 0 <= sample_bucket < sample_modulus and
            1 <= batch_size <= 16384 and 1 <= max_lookup_rows <= 500000 and
            1 <= max_selected_venues <= 20000):
        raise PilotError("Sampling or bounded resource configuration is invalid")
    if source_kind == "restricted_local" and (sample_modulus, sample_bucket) != (1000, 0):
        raise PilotError("Restricted engineering selection must follow the frozen protocol")
    if set(paths) != set(SOURCE_ROLES) or set(expected_sha256) != set(SOURCE_ROLES):
        raise PilotError("Exactly three explicitly fingerprinted source roles are required")
    if any(not isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{64}", value)
           for value in expected_sha256.values()):
        raise PilotError("Valid expected SHA-256 fingerprints are required")
    try:
        sources = {role: Path(paths[role]).resolve(strict=True) for role in SOURCE_ROLES}
    except (OSError, TypeError, ValueError):
        raise PilotError("A named input is unavailable; source paths suppressed") from None
    if len(set(sources.values())) != len(SOURCE_ROLES):
        raise PilotError("The three source files must be distinct")
    try:
        dest = Path(private_output).resolve()
    except (OSError, TypeError, ValueError):
        raise PilotError("Private output path is unavailable; paths suppressed") from None
    if dest.is_relative_to(REPOSITORY):
        raise PilotError("Private output must be outside the repository")
    try:
        if dest.exists():
            raise PilotError("Output already exists; preserve the previous run")
        dest.mkdir(parents=True, exist_ok=False)
    except PilotError:
        raise
    except (OSError, TypeError, ValueError):
        raise PilotError("Private output directory is unavailable; paths suppressed") from None
    start = time.perf_counter()
    diagnostics = {
        **{key: 0 for key in ("lookup_rows", "poi_rows", "flow_rows", "matched_ids",
                             "flow_without_poi", "poi_without_flow", "selected_flow_rows",
                             "selected_matched_rows")},
        "metadata_conflicts": Counter(city=0, combined=0), "reconciliation": {},
        "variant_support": {variant: {
            "retained_venues": 0, "null_weight_entries": 0, "zero_weight_entries": 0,
            "disjoint_exclusions": Counter(), "overlapping_exclusion_flags": Counter(),
        } for variant in VARIANTS},
    }
    receipt = {
        "started_utc": datetime.now(timezone.utc).isoformat(), "source_kind": source_kind,
        "status": "started", "public_release_authorized": False,
        "city_size_regression_run": False, "source_correctness_verified": False,
        "source_year": year, "acs_end_year": acs_end_year, "cbg_vintage": cbg_vintage,
        "config": config, "absolute_tolerance": ATOL, "relative_tolerance": RTOL,
        "inputs": {}, "diagnostics": diagnostics,
        "environment": {"python": platform.python_version(), "numpy": np.__version__, "pandas": pd.__version__,
                        "pyarrow": pyarrow.__version__, "sqlite": sqlite3.sqlite_version},
    }
    con = None
    try:
        code_hashes = {str(path.relative_to(PROJECT)): sha256(path) for path in EXECUTION_FILES}
        receipt["execution_sha256"] = code_hashes
        signatures = {}
        for role, path in sources.items():
            stat = path.stat()
            signatures[role] = (stat.st_size, stat.st_mtime_ns)
            digest = sha256(path)
            receipt["inputs"][role] = {"filename": path.name, "bytes": stat.st_size,
                                      "mtime_ns": stat.st_mtime_ns, "sha256": digest}
            if digest != expected_sha256[role]:
                raise PilotError("Input fingerprint mismatch; no row processing permitted")
        maps = _load_lookup(sources["lookup"], batch_size, max_lookup_rows, diagnostics)
        con = sqlite3.connect(dest / "private_working.sqlite")
        con.execute("PRAGMA temp_store=MEMORY")
        con.execute("PRAGMA cache_size=-32768")
        _load_pois(con, sources["poi"], batch_size, diagnostics)
        _load_flows(con, sources["flow"], maps, config, diagnostics)
        outcomes = _decompose(con)
        for role, path in sources.items():
            stat = path.stat()
            if (stat.st_size, stat.st_mtime_ns) != signatures[role]:
                raise PilotError("Input size or mtime changed during execution; outputs withheld")
        if code_hashes != {str(path.relative_to(PROJECT)): sha256(path) for path in EXECUTION_FILES}:
            raise PilotError("Execution source changed during the run; outputs withheld")
        receipt["input_size_mtime_unchanged"] = True
        receipt["execution_sources_unchanged"] = True
        receipt["n_recorded_area_variant_outcomes"] = len(outcomes)
        receipt["outcome_availability"] = "available_on_retained_support" if outcomes else "no_classified_geographic_support"
        _write_json(dest / "private_area_outcomes.json", outcomes)
        receipt["outcome_sha256"] = sha256(dest / "private_area_outcomes.json")
        receipt["status"] = "completed_engineering_only"
    except Exception as exc:
        receipt["status"] = "failed_no_decomposition_release"
        receipt["error_type"] = type(exc).__name__
        receipt["error"] = str(exc) if isinstance(exc, PilotError) else "Processing failed; source values suppressed"
        raise PilotError(receipt["error"]) from None
    finally:
        if con is not None:
            con.close()
        receipt["elapsed_seconds"] = time.perf_counter() - start
        receipt["finished_utc"] = datetime.now(timezone.utc).isoformat()
        _write_json(dest / "private_execution_receipt.json", receipt)
    return dest / "private_execution_receipt.json"
