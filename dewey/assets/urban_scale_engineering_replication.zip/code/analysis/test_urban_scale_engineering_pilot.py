"""Artificial file-to-file tests. No project data files are opened."""

from collections import defaultdict
from decimal import Decimal
import json
import math
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

import pyarrow as pa
import pyarrow.parquet as pq

import run_urban_scale_engineering_pilot as adapter


ORIGINS = ("990000000001", "990000000002", "990000000003", "990000000004")
GROUPS = {"tdw": (1, 10, 3, None), "strict": (1, 10, None, None)}


def independent_metrics(flows, groups):
    masses = [math.fsum(weight for origin, weight in flows.items()
                        if weight is not None and weight > 0 and groups.get(origin) == group)
              for group in range(1, 11)]
    total = math.fsum(weight for weight in flows.values() if weight is not None and weight > 0)
    classified = math.fsum(masses)
    probabilities = [value / classified for value in masses if value] if classified else []
    entropy = math.fsum(-p * math.log(p) for p in probabilities) if probabilities else None
    return masses, {
        "total": total, "ses_frac_nat": 1 - math.fsum(p * p for p in probabilities) if probabilities else None,
        "ses_entropy_nat": entropy, "ses_entropy_norm_nat": entropy / math.log(10) if entropy is not None else None,
        "nat_decile_flow_coverage": classified / total if total else None,
    }


def fixture_rows(n=8):
    lookup = [{"cbg": origin, "nat_decile_tdw": GROUPS["tdw"][index],
               "nat_decile_nhgis": GROUPS["tdw"][index],
               "nat_decile_strict": GROUPS["strict"][index]} for index, origin in enumerate(ORIGINS)]
    patterns = ((6, 2, 4, 2), (2, 7, 2, 1), (9, 1, 0, 0), (1, 4, 3, 2),
                (7, 4, 1, 1), (5, 2, 9, 2), (4, 0, 0, 1), (0, 0, 0, 10))
    flow, poi = [], []
    for index in range(n):
        slot = index % 8
        weights = dict(zip(ORIGINS, patterns[slot]))
        weights["990000000098"] = None
        weights["990000000099"] = 0
        city = Decimal(10001 if slot < 6 else 10002)
        category = "Artificial service A" if slot % 3 else "Artificial service B"
        common = {"ID_STORE": f"artificial_venue_{index:06d}", "MSA_CODE": city,
                  "combined_category": category}
        flow.append({**common, "cbg_visits_json": json.dumps(weights)})
        row = {**common, "year": 2019, "SUB_CATEGORY": category,
               "destination_county": "99001" if slot % 2 else "99002"}
        for variant in adapter.VARIANTS:
            _, metrics = independent_metrics(weights, dict(zip(ORIGINS, GROUPS[variant])))
            row["total_origin_visit_weight"] = metrics["total"]
            row.update({f"{name}_{variant}": value for name, value in metrics.items() if name != "total"})
        poi.append(row)
    return {"flow": flow, "lookup": lookup, "poi": poi}


def write_fixture(root, rows):
    base = fixture_rows()
    paths = {}
    for role in adapter.SOURCE_ROLES:
        schema = pa.Table.from_pylist(base[role]).schema
        paths[role] = root / f"artificial_{role}.parquet"
        pq.write_table(pa.Table.from_pylist(rows[role], schema=schema), paths[role], row_group_size=2)
    return paths, {role: adapter.sha256(path) for role, path in paths.items()}


def independent_information(rows, variant, city):
    grouped = defaultdict(lambda: [0.0] * 10)
    matched = {row["ID_STORE"]: row for row in rows["poi"]}
    all_mass, venue_entropy = [0.0] * 10, 0.0
    by_category, by_area = defaultdict(lambda: [0.0] * 10), defaultdict(lambda: [0.0] * 10)
    for flow in rows["flow"]:
        poi = matched[flow["ID_STORE"]]
        if f"{int(poi['MSA_CODE']):05d}" != city:
            continue
        mass, values = independent_metrics(json.loads(flow["cbg_visits_json"]), dict(zip(ORIGINS, GROUPS[variant])))
        total = math.fsum(mass)
        if not total:
            continue
        venue_entropy += total * values["ses_entropy_nat"]
        for group, weight in enumerate(mass):
            all_mass[group] += weight
            grouped[poi["SUB_CATEGORY"], poi["destination_county"]][group] += weight
            by_category[poi["SUB_CATEGORY"]][group] += weight
            by_area[poi["destination_county"]][group] += weight
    total = math.fsum(all_mass)

    def weighted_h(vectors):
        result = 0.0
        for vector in vectors:
            subtotal = math.fsum(vector)
            result += math.fsum(-x * math.log(x / subtotal) for x in vector if x)
        return result / total

    h, hk, ha, hka, hj = (weighted_h([all_mass]), weighted_h(by_category.values()),
                          weighted_h(by_area.values()), weighted_h(grouped.values()), venue_entropy / total)
    return {"i_group_venue_nats": h - hj, "i_group_category_nats": h - hk,
            "i_group_area_given_category_nats": hk - hka,
            "i_group_venue_given_category_area_nats": hka - hj,
            "i_group_area_nats": h - ha, "i_group_category_given_area_nats": ha - hka,
            "h_group_nats": h, "total_mass": total}


class EngineeringPilotTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix="dewey_artificial_adapter_")
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.rows = fixture_rows()
        self.counter = 0

    def run_fixture(self, rows=None, **settings):
        self.counter += 1
        source_dir = self.root / f"inputs_{self.counter}"
        source_dir.mkdir()
        paths, hashes = write_fixture(source_dir, rows or self.rows)
        output = self.root / f"run_{self.counter}"
        self.last_paths, self.last_output, self.last_hashes = paths, output, hashes
        config = dict(sample_modulus=1, batch_size=2, source_kind="synthetic_fixture",
                      acknowledge_local_processing=True)
        config.update(settings)
        receipt = adapter.execute_pilot(paths, hashes, output, **config)
        return json.loads(receipt.read_text()), json.loads((output / "private_area_outcomes.json").read_text())

    def assert_failed_without_outcome(self, text=None):
        receipt = json.loads((self.last_output / "private_execution_receipt.json").read_text())
        self.assertEqual(receipt["status"], "failed_no_decomposition_release")
        self.assertFalse((self.last_output / "private_area_outcomes.json").exists())
        if text:
            self.assertIn(text, receipt["error"])
        return receipt

    def test_end_to_end_matches_independent_entropy_accounting(self):
        self.rows["poi"].reverse()
        receipt, outcomes = self.run_fixture()
        self.assertEqual(len(outcomes), 4)
        self.assertFalse(receipt["public_release_authorized"])
        self.assertFalse(receipt["city_size_regression_run"])
        self.assertTrue(receipt["execution_sources_unchanged"])
        self.assertEqual(receipt["diagnostics"]["matched_ids"], 8)
        for outcome in outcomes:
            expected = independent_information(self.rows, outcome["variant"], outcome["city"])
            for name, value in expected.items():
                self.assertAlmostEqual(outcome[name], value, places=12)
            self.assertEqual(outcome["n_missing_cells_filled"], 0)
        self.assertEqual({role: adapter.sha256(path) for role, path in self.last_paths.items()}, self.last_hashes)

    def test_single_group_normalization_is_undefined_not_zero(self):
        _, outcomes = self.run_fixture()
        for outcome in outcomes:
            if outcome["city"] == "10002":
                self.assertIsNone(outcome["i_group_venue_normalized"])
                self.assertFalse(outcome["normalization_defined"])
                self.assertEqual(outcome["normalization_undefined_reason"], "zero_group_entropy")

    def test_missing_income_and_null_weights_have_distinct_ledgers(self):
        receipt, _ = self.run_fixture()
        for variant in adapter.VARIANTS:
            support = receipt["diagnostics"]["variant_support"][variant]
            self.assertGreater(support["unclassified_weight"], 0)
            self.assertEqual(support["null_weight_entries"], 8)
            self.assertGreater(support["zero_weight_entries"], 8)
            self.assertAlmostEqual(support["known_positive_weight"], support["classified_weight"] + support["unclassified_weight"])
            self.assertEqual(support["disjoint_exclusions"]["no_classified_mass"], 1)

    def test_cross_batch_duplicates_reject_each_input(self):
        for role in adapter.SOURCE_ROLES:
            rows = fixture_rows()
            rows[role].append(rows[role][0].copy())
            with self.subTest(role=role), self.assertRaisesRegex(adapter.PilotError, "Duplicate"):
                self.run_fixture(rows)
            self.assert_failed_without_outcome()

    def test_nonselected_duplicate_still_rejects(self):
        modulus = 3
        row = next(row for row in self.rows["flow"] if not adapter.selected_id(row["ID_STORE"], modulus, 0))
        self.rows["flow"].append(row.copy())
        with self.assertRaisesRegex(adapter.PilotError, "Duplicate"):
            self.run_fixture(sample_modulus=modulus)
        self.assert_failed_without_outcome()

    def test_missing_side_rosters_stop_every_result(self):
        for role, count in (("flow", "poi_without_flow"), ("poi", "flow_without_poi")):
            rows = fixture_rows()
            rows[role].pop()
            with self.subTest(role=role), self.assertRaisesRegex(adapter.PilotError, "rosters"):
                self.run_fixture(rows)
            receipt = self.assert_failed_without_outcome()
            self.assertEqual(receipt["diagnostics"][count], 1)

    def test_metadata_conflict_in_unselected_row_stops(self):
        row = next(row for row in self.rows["flow"] if not adapter.selected_id(row["ID_STORE"], 3, 0))
        row["combined_category"] = "Artificial conflicting label"
        with self.assertRaisesRegex(adapter.PilotError, "metadata conflict"):
            self.run_fixture(sample_modulus=3)
        receipt = self.assert_failed_without_outcome()
        self.assertEqual(receipt["diagnostics"]["metadata_conflicts"]["combined"], 1)

    def test_area_conflict_stops(self):
        self.rows["flow"][0]["MSA_CODE"] = Decimal(10003)
        with self.assertRaisesRegex(adapter.PilotError, "metadata conflict"):
            self.run_fixture()
        self.assert_failed_without_outcome()

    def test_every_reconciled_metric_is_binding(self):
        names = ["total_origin_visit_weight", *(f"{metric}_{variant}" for variant in adapter.VARIANTS for metric in adapter.METRICS)]
        for name in names:
            rows = fixture_rows()
            rows["poi"][0][name] += 0.1
            with self.subTest(name=name), self.assertRaisesRegex(adapter.PilotError, "reconciliation failed"):
                self.run_fixture(rows)
            receipt = self.assert_failed_without_outcome()
            self.assertEqual(receipt["diagnostics"]["reconciliation"][name]["mismatches"], 1)

    def test_known_undefined_metric_mismatch_is_not_ignored(self):
        self.rows["poi"][-1]["ses_frac_nat_tdw"] = 0
        with self.assertRaisesRegex(adapter.PilotError, "reconciliation failed"):
            self.run_fixture()
        self.assert_failed_without_outcome()

    def test_preferred_nhgis_alias_is_checked(self):
        self.rows["lookup"][0]["nat_decile_nhgis"] = 2
        with self.assertRaisesRegex(adapter.PilotError, "aliases disagree"):
            self.run_fixture()
        self.assert_failed_without_outcome()

    def test_out_of_range_lookup_groups_do_not_become_missing(self):
        for invalid in (0, -1, 11):
            rows = fixture_rows()
            rows["lookup"][0]["nat_decile_tdw"] = invalid
            with self.subTest(invalid=invalid), self.assertRaisesRegex(adapter.PilotError, "income-group"):
                self.run_fixture(rows)
            self.assert_failed_without_outcome()

    def test_bad_flows_are_redacted_and_not_discarded(self):
        for value in (None, "", '{"secret_artificial_origin": 2, "secret_artificial_origin": 3}',
                      '{"secret_artificial_origin": -1}', '{"secret_artificial_origin": NaN}'):
            rows = fixture_rows()
            rows["flow"][0]["cbg_visits_json"] = value
            with self.subTest(value=value), self.assertRaises(adapter.PilotError) as caught:
                self.run_fixture(rows)
            self.assertNotIn("secret_artificial_origin", str(caught.exception))
            receipt = self.assert_failed_without_outcome()
            self.assertNotIn("secret_artificial_origin", json.dumps(receipt))

    def test_disjoint_exclusion_priority_and_overlapping_flags(self):
        self.rows["flow"][0]["MSA_CODE"] = None
        self.rows["poi"][0].update(MSA_CODE=None, destination_county=None, SUB_CATEGORY=None)
        self.rows["poi"][1].update(destination_county=None, SUB_CATEGORY=None)
        self.rows["poi"][2]["SUB_CATEGORY"] = None
        receipt, _ = self.run_fixture()
        for variant in adapter.VARIANTS:
            support = receipt["diagnostics"]["variant_support"][variant]
            self.assertEqual(support["retained_venues"], 4)
            self.assertEqual(support["disjoint_exclusions"], {
                "missing_recorded_area": 1, "missing_destination_county": 1,
                "missing_subcategory": 1, "no_classified_mass": 1})
            self.assertEqual(support["overlapping_exclusion_flags"]["missing_subcategory"], 3)

    def test_no_geographic_support_is_explicit(self):
        for row in self.rows["poi"]:
            row["destination_county"] = None
        receipt, outcomes = self.run_fixture()
        self.assertEqual(outcomes, [])
        self.assertEqual(receipt["outcome_availability"], "no_classified_geographic_support")

    def test_sampling_and_outcomes_invariant_to_order_and_batch_size(self):
        first, a = self.run_fixture(sample_modulus=2, batch_size=1)
        for rows in self.rows.values():
            rows.reverse()
        second, b = self.run_fixture(sample_modulus=2, batch_size=7)
        self.assertEqual(a, b)
        self.assertEqual(first["diagnostics"]["selected_flow_rows"], second["diagnostics"]["selected_flow_rows"])
        self.assertEqual(first["diagnostics"]["selected_flow_rows"], sum(adapter.selected_id(row["ID_STORE"], 2, 0) for row in self.rows["flow"]))

    def test_resource_caps_fail_without_truncation(self):
        for setting in ({"max_lookup_rows": 2}, {"max_selected_venues": 2}):
            with self.subTest(setting=setting), self.assertRaisesRegex(adapter.PilotError, "resource cap"):
                self.run_fixture(**setting)
            self.assert_failed_without_outcome()

    def test_acknowledgement_and_provenance_rejected_before_row_read(self):
        for setting in ({"acknowledge_local_processing": False}, {"year": 2018},
                        {"acs_end_year": 2020}, {"cbg_vintage": 2010}, {"year": True},
                        {"source_kind": "not_declared"}, {"sample_modulus": 0}, {"batch_size": 20000},
                        {"source_kind": "restricted_local", "sample_modulus": 1}):
            with self.subTest(setting=setting), patch.object(adapter, "_rows") as rows:
                with self.assertRaises(adapter.PilotError):
                    self.run_fixture(**setting)
                rows.assert_not_called()

    def test_output_overwrite_is_refused(self):
        self.run_fixture()
        with self.assertRaisesRegex(adapter.PilotError, "already exists"):
            adapter.execute_pilot(self.last_paths, self.last_hashes, self.last_output,
                                  source_kind="synthetic_fixture", acknowledge_local_processing=True)

    def test_repository_output_is_refused(self):
        self.run_fixture()
        with self.assertRaisesRegex(adapter.PilotError, "outside the repository"):
            adapter.execute_pilot(self.last_paths, self.last_hashes, adapter.PROJECT / "output/forbidden_private_adapter",
                                  source_kind="synthetic_fixture", acknowledge_local_processing=True)

    def test_fingerprint_mismatch_prevents_row_reads(self):
        self.run_fixture()
        hashes = dict(self.last_hashes, flow="0" * 64)
        output = self.root / "wrong_hash"
        with patch.object(adapter, "_rows") as reader, self.assertRaisesRegex(adapter.PilotError, "fingerprint mismatch"):
            adapter.execute_pilot(self.last_paths, hashes, output, source_kind="synthetic_fixture", acknowledge_local_processing=True)
        reader.assert_not_called()
        self.last_output = output
        self.assert_failed_without_outcome()

    def test_changed_input_withholds_outcomes(self):
        original = adapter._load_flows

        def mutate_after(*args):
            original(*args)
            with args[1].open("ab") as stream:
                stream.write(b"artificial change")

        with patch.object(adapter, "_load_flows", side_effect=mutate_after), self.assertRaisesRegex(adapter.PilotError, "changed during execution"):
            self.run_fixture()
        self.assert_failed_without_outcome()

    def test_changed_code_binding_withholds_outcomes(self):
        original, calls = adapter.sha256, defaultdict(int)

        def altered(path):
            calls[path] += 1
            if path == adapter.EXECUTION_FILES[0] and calls[path] == 2:
                return "0" * 64
            return original(path)

        with patch.object(adapter, "sha256", side_effect=altered), self.assertRaisesRegex(adapter.PilotError, "Execution source changed"):
            self.run_fixture()
        self.assert_failed_without_outcome()

    def test_empty_files_and_unexpected_year_fail(self):
        for role in adapter.SOURCE_ROLES:
            rows = fixture_rows()
            rows[role] = []
            with self.subTest(role=role), self.assertRaises(adapter.PilotError):
                self.run_fixture(rows)
            self.assert_failed_without_outcome()
        self.rows["poi"][0]["year"] = 2018
        with self.assertRaisesRegex(adapter.PilotError, "year"):
            self.run_fixture()


if __name__ == "__main__":
    unittest.main()
