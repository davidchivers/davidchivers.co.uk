"""Artificial examples only; no data files, production estimators or downloads."""
from collections import defaultdict
from decimal import Decimal, localcontext
from fractions import Fraction
from itertools import product
import math
import unittest

import numpy as np
import pandas as pd

from urban_scale_information import (
    FORWARD_COMPONENT_FIELDS,
    INFORMATION_FIELDS,
    REVERSE_COMPONENT_FIELDS,
    MassColumns,
    decompose_city_year_information,
)


GROUPS = ("low", "high")
LN2 = math.log(2)


def table(masses, categories=None, areas=None, groups=GROUPS, city="toy", year=2000):
    n = len(masses)
    categories = categories if categories is not None else ["service"] * n
    areas = areas if areas is not None else ["district"] * n
    return pd.DataFrame([
        (city, year, f"j{j}", categories[j], areas[j], group, mass)
        for j, row in enumerate(masses) for group, mass in zip(groups, row)
    ], columns=["city", "year", "venue", "category", "area", "group", "mass"])


def result(frame, groups=GROUPS, missing="error"):
    return decompose_city_year_information(
        frame, group_universe=groups, missing_group_cells=missing
    ).iloc[0]


def mixed_table():
    return table(
        [[9, 1, 0], [1, 3, 2], [2, 5, 1], [3, 1, 2], [0, 2, 8], [2, 2, 1]],
        categories=["food", "food", "food", "shop", "shop", "shop"],
        areas=["north", "north", "south", "north", "south", "east"],
        groups=("low", "middle", "high"),
    )


def independent_entropy_decomposition(frame):
    """70-digit joint-entropy differences, independent of implementation/KL code."""
    with localcontext() as context:
        context.prec = 70
        records = frame.to_dict("records")
        total = sum(Decimal(str(row["mass"])) for row in records)

        def entropy(keys):
            cells = defaultdict(Decimal)
            for row in records:
                cells[tuple(row[key] for key in keys)] += Decimal(str(row["mass"]))
            probabilities = [mass / total for mass in cells.values() if mass > 0]
            return -sum((p * p.ln() for p in probabilities), Decimal(0))

        hg = entropy(("group",))
        hk = entropy(("group", "category")) - entropy(("category",))
        ha = entropy(("group", "area")) - entropy(("area",))
        hka = entropy(("group", "category", "area")) - entropy(("category", "area"))
        hj = entropy(("group", "venue")) - entropy(("venue",))
        return tuple(float(value) for value in (hg - hj, hg - hk, hk - hka,
                                                hka - hj, hg - ha, ha - hka))


def poi_scalars(frame):
    """Deliberately discard group labels, as scalar venue indices do."""
    values = []
    for _, venue in frame.groupby("venue", sort=False):
        masses = venue["mass"].to_numpy(dtype=float)
        shares = masses / masses.sum()
        fractionalization = 1 - np.dot(shares, shares)
        entropy = -math.fsum(p * math.log(p) for p in shares if p > 0)
        values.append((masses.sum(), fractionalization, entropy))
    return values


class TestInformationAccounting(unittest.TestCase):
    def assert_identity(self, row):
        for fields, residual in (
            (FORWARD_COMPONENT_FIELDS, "additive_residual"),
            (REVERSE_COMPONENT_FIELDS, "reverse_additive_residual"),
        ):
            self.assertAlmostEqual(row["i_group_venue_nats"],
                                   math.fsum(row[name + "_nats"] for name in fields), places=12)
            self.assertAlmostEqual(row[residual + "_nats"], 0, places=12)
            if row["normalization_defined"]:
                self.assertAlmostEqual(row["i_group_venue_normalized"], math.fsum(
                    row[name + "_normalized"] for name in fields), places=12)
                self.assertAlmostEqual(row[residual + "_normalized"], 0, places=12)
        self.assertAlmostEqual(row["probability_sum"], 1, places=14)

    def assert_forward(self, row, expected):
        for name, value in zip(FORWARD_COMPONENT_FIELDS, expected):
            self.assertAlmostEqual(row[name + "_nats"], value, places=12)
        self.assert_identity(row)

    def test_category_only(self):
        row = result(table([[10, 0], [0, 10]], categories=["food", "shop"]))
        self.assert_forward(row, (LN2, 0, 0))
        self.assertAlmostEqual(row["h_group_nats"], LN2)
        self.assertAlmostEqual(row["i_group_venue_normalized"], 1)

    def test_area_only(self):
        row = result(table([[10, 0], [0, 10]], areas=["north", "south"]))
        self.assert_forward(row, (0, LN2, 0))

    def test_within_area_only(self):
        self.assert_forward(result(table([[10, 0], [0, 10]])), (0, 0, LN2))

    def test_mixed_exact_three_bits(self):
        groups = tuple(f"g{i}" for i in range(8))
        frame = table(np.eye(8, dtype=int), categories=[i // 4 for i in range(8)],
                      areas=[(i // 2) % 2 for i in range(8)], groups=groups)
        row = result(frame, groups)
        self.assert_forward(row, (LN2, LN2, LN2))
        self.assertAlmostEqual(row["h_group_nats"], math.log(8))
        for field in FORWARD_COMPONENT_FIELDS:
            self.assertAlmostEqual(row[field + "_normalized"], 1 / 3)

    def test_repeated_area_labels_require_category_conditioning(self):
        frame = table([[10, 0], [0, 10], [0, 10], [10, 0]],
                      categories=["a", "a", "b", "b"],
                      areas=["north", "south", "north", "south"])
        row = result(frame)
        self.assert_forward(row, (0, LN2, 0))
        self.assertAlmostEqual(row["i_group_area_nats"], 0)
        self.assertAlmostEqual(row["i_group_category_given_area_nats"], LN2)

    def test_disjoint_areas_across_categories_are_allowed(self):
        frame = table([[7, 1], [1, 3], [2, 9]], categories=["a", "a", "b"],
                      areas=["north", "south", "east"])
        row = result(frame)
        self.assert_identity(row)
        self.assertAlmostEqual(row["i_group_venue_given_category_area_nats"], 0)

    def test_reverse_order_same_total_and_within_cell_information(self):
        frame = mixed_table()
        row = result(frame, ("low", "middle", "high"))
        forward = [row[name + "_nats"] for name in FORWARD_COMPONENT_FIELDS]
        reverse = [row[name + "_nats"] for name in REVERSE_COMPONENT_FIELDS]
        self.assertAlmostEqual(math.fsum(forward), math.fsum(reverse), places=14)
        self.assertEqual(forward[2], reverse[2])
        swapped = frame.rename(columns={"category": "area", "area": "category"})
        flipped = result(swapped, ("low", "middle", "high"))
        for field, value in zip(FORWARD_COMPONENT_FIELDS, reverse):
            self.assertAlmostEqual(flipped[field + "_nats"], value, places=14)
        self.assertAlmostEqual(flipped["i_group_venue_nats"], row["i_group_venue_nats"])

    def test_category_area_attribution_depends_on_order(self):
        frame = table([[10, 0], [0, 10]], categories=["food", "shop"],
                      areas=["north", "south"])
        row = result(frame)
        self.assert_forward(row, (LN2, 0, 0))
        self.assertAlmostEqual(row["i_group_area_nats"], LN2)
        self.assertAlmostEqual(row["i_group_category_given_area_nats"], 0)

    def test_independent_high_precision_joint_entropy_vs_kl(self):
        frame = mixed_table()
        row = result(frame, ("low", "middle", "high"))
        for name, expected in zip(INFORMATION_FIELDS, independent_entropy_decomposition(frame)):
            self.assertAlmostEqual(row[name + "_nats"], expected, places=14)
        self.assertTrue(all(row[name + "_nats"] > 0 for name in INFORMATION_FIELDS))
        self.assert_identity(row)

    def test_seeded_artificial_tables_against_independent_entropy(self):
        rng = np.random.default_rng(20261019)
        for draw in range(24):
            with self.subTest(draw=draw):
                n = int(rng.integers(2, 10))
                g = int(rng.integers(2, 6))
                groups = tuple(f"g{i}" for i in range(g))
                frame = table(rng.integers(0, 30, size=(n, g)),
                              categories=rng.integers(0, 3, size=n),
                              areas=rng.integers(0, 4, size=n), groups=groups)
                row = result(frame, groups)
                for name, expected in zip(INFORMATION_FIELDS, independent_entropy_decomposition(frame)):
                    self.assertAlmostEqual(row[name + "_nats"], expected, places=13)
                self.assert_identity(row)

    def test_relabel_row_order_and_group_order_invariance(self):
        frame = mixed_table()
        groups = ("low", "middle", "high")
        expected = result(frame, groups)
        changed = frame.copy()
        for key in ["city", "year", "venue", "category", "area", "group"]:
            changed[key] = changed[key].map(lambda value: f"renamed_{key}_{value}")
        changed = changed.sample(frac=1, random_state=42)
        actual = result(changed, tuple(f"renamed_group_{group}" for group in reversed(groups)))
        for name in INFORMATION_FIELDS:
            for suffix in ("_nats", "_normalized"):
                self.assertAlmostEqual(expected[name + suffix], actual[name + suffix], places=14)

    def test_scale_invariance(self):
        frame = mixed_table()
        groups = ("low", "middle", "high")
        expected = result(frame, groups)
        for scale in (1e-200, 0.003, 17, 1e200):
            with self.subTest(scale=scale):
                actual = result(frame.assign(mass=frame["mass"] * scale), groups)
                for name in INFORMATION_FIELDS:
                    for suffix in ("_nats", "_normalized"):
                        self.assertAlmostEqual(expected[name + suffix], actual[name + suffix], places=13)
                self.assertAlmostEqual(actual["total_mass"] / scale, expected["total_mass"])

    def test_one_venue_has_zero_information(self):
        row = result(table([[3, 7]]))
        self.assert_forward(row, (0, 0, 0))
        self.assertGreater(row["h_group_nats"], 0)

    def test_identical_venue_distributions_have_zero_information(self):
        frame = table([[2, 3], [4, 6], [8, 12]], categories=["a", "b", "b"],
                      areas=["x", "x", "y"])
        self.assert_forward(result(frame), (0, 0, 0))

    def test_same_composition_venue_split_preserves_information(self):
        original = table([[8, 2], [2, 8]])
        split = table([[4, 1], [4, 1], [2, 8]])
        for name in INFORMATION_FIELDS:
            self.assertAlmostEqual(result(original)[name + "_nats"],
                                   result(split)[name + "_nats"], places=14)

    def test_multiple_cities_years_are_not_pooled(self):
        frames = [table([[1, 0], [0, 1]], city="one", year=2000),
                  table([[1, 1], [1, 1]], city="one", year=2001),
                  table([[1, 0], [0, 1]], categories=["a", "b"], city="two", year=2000)]
        rows = decompose_city_year_information(pd.concat(frames), group_universe=GROUPS,
                                              missing_group_cells="error")
        self.assertEqual(len(rows), 3)
        for frame, (_, row) in zip(frames, rows.iterrows()):
            expected = result(frame)
            for name in INFORMATION_FIELDS:
                self.assertAlmostEqual(row[name + "_nats"], expected[name + "_nats"])

    def test_zero_entropy_is_undefined_not_zero_normalized(self):
        row = result(table([[10, 0], [3, 0]], categories=["a", "b"]))
        self.assertEqual(row["h_group_nats"], 0)
        self.assertFalse(row["normalization_defined"])
        self.assertEqual(row["normalization_undefined_reason"], "zero_group_entropy")
        self.assertEqual(row["absent_groups"], ("high",))
        for name in INFORMATION_FIELDS:
            self.assertEqual(row[name + "_nats"], 0)
            self.assertTrue(math.isnan(row[name + "_normalized"]))
        self.assertTrue(math.isnan(row["additive_residual_normalized"]))
        self.assertTrue(math.isnan(row["reverse_additive_residual_normalized"]))
        self.assert_identity(row)

    def test_single_declared_group_is_valid_but_normalization_undefined(self):
        row = result(table([[4], [5]], groups=("only",)), ("only",))
        self.assertEqual(row["n_groups_positive"], 1)
        self.assertFalse(row["normalization_defined"])

    def test_absent_group_retained_without_smoothing(self):
        frame = table([[8, 2, 0], [2, 8, 0]], groups=("low", "high", "absent"))
        row = result(frame, ("low", "high", "absent"))
        self.assertEqual(row["n_groups_declared"], 3)
        self.assertEqual(row["n_groups_positive"], 2)
        self.assertEqual(row["absent_groups"], ("absent",))
        self.assertAlmostEqual(row["h_group_nats"], LN2)
        self.assertAlmostEqual(row["i_group_venue_normalized"],
                               result(table([[8, 2], [2, 8]]))["i_group_venue_normalized"])

    def test_sparse_known_zeros_equal_complete_table(self):
        complete = table([[1, 0, 0], [0, 1, 0]], groups=("low", "high", "absent"))
        sparse = complete.loc[complete["mass"] > 0]
        groups = ("low", "high", "absent")
        expected, actual = result(complete, groups), result(sparse, groups, "zero")
        self.assertEqual(actual["n_missing_cells_filled"], 4)
        self.assertEqual(actual["absent_groups"], ("absent",))
        for name in INFORMATION_FIELDS:
            self.assertEqual(actual[name + "_nats"], expected[name + "_nats"])

    def test_zero_mass_venue_is_reported_not_given_equal_weight(self):
        row = result(table([[8, 2], [2, 8], [0, 0]], categories=["a", "a", "zero"],
                           areas=["x", "x", "unused"]))
        self.assertEqual(row["n_venues_declared"], 3)
        self.assertEqual(row["n_venues_positive"], 2)
        self.assertEqual(row["n_explicit_zero_cells"], 2)
        self.assertAlmostEqual(row["i_group_venue_nats"],
                               result(table([[8, 2], [2, 8]]))["i_group_venue_nats"])

    def test_normalization_uses_h_group_not_log_universe_size(self):
        row = result(table([[9, 0], [0, 1]]))
        self.assertLess(row["h_group_nats"], LN2)
        self.assertAlmostEqual(row["i_group_venue_normalized"], 1)

    def test_tiny_positive_entropy_remains_defined(self):
        row = result(table([[1, 0], [0, 1e-100]]))
        self.assertGreater(row["h_group_nats"], 0)
        self.assertTrue(row["normalization_defined"])
        self.assertAlmostEqual(row["i_group_venue_normalized"], 1)

    def test_fractionalization_and_entropy_are_distinct(self):
        frame = table([[1, 1]])
        _, fractionalization, entropy = poi_scalars(frame)[0]
        self.assertEqual(fractionalization, 0.5)
        self.assertAlmostEqual(entropy, LN2)
        self.assertAlmostEqual(result(frame)["h_group_nats"], entropy)
        self.assertNotEqual(fractionalization, entropy)

    def test_identical_poi_scalars_cannot_recover_pooled_alignment(self):
        split = table([[10, 0], [0, 10]], categories=["a", "b"])
        aligned = table([[10, 0], [10, 0]], categories=["a", "b"])
        self.assertEqual(poi_scalars(split), poi_scalars(aligned))
        first, second = result(split), result(aligned)
        self.assertAlmostEqual(first["h_group_nats"], LN2)
        self.assertEqual(second["h_group_nats"], 0)
        self.assertAlmostEqual(first["i_group_category_nats"], LN2)
        self.assertEqual(second["i_group_category_nats"], 0)
        self.assertFalse(second["normalization_defined"])

    def test_same_pooled_totals_and_poi_scalars_still_do_not_identify_components(self):
        categories = ["a", "a", "b", "b"]
        separated = table([[1, 0], [1, 0], [0, 1], [0, 1]], categories=categories)
        alternating = table([[1, 0], [0, 1], [1, 0], [0, 1]], categories=categories)
        self.assertEqual(poi_scalars(separated), poi_scalars(alternating))
        pd.testing.assert_series_equal(separated.groupby("group")["mass"].sum(),
                                       alternating.groupby("group")["mass"].sum())
        first, second = result(separated), result(alternating)
        self.assertAlmostEqual(first["i_group_venue_nats"], second["i_group_venue_nats"])
        self.assert_forward(first, (LN2, 0, 0))
        self.assert_forward(second, (0, 0, LN2))

    def test_finite_sample_mechanics_by_complete_iid_enumeration(self):
        # Four independent fair group draws: true G is independent of venue.
        # All 16 assignments are equally likely; this is not Monte Carlo.
        expected_h = 0.5 * (-0.25 * math.log(0.25) - 0.75 * math.log(0.75)) + 0.375 * LN2
        expectations = []
        for sizes in ((4,), (2, 2), (1, 1, 1, 1)):
            values = []
            undefined = 0
            for labels in product((0, 1), repeat=4):
                start, masses = 0, []
                for size in sizes:
                    high = sum(labels[start:start + size])
                    masses.append([size - high, high])
                    start += size
                row = result(table(masses))
                values.append(row["i_group_venue_nats"])
                undefined += not row["normalization_defined"]
                self.assert_identity(row)
            self.assertEqual(undefined, 2)
            expectations.append(math.fsum(values) / 16)
        np.testing.assert_allclose(expectations, [0, expected_h - 0.5 * LN2, expected_h],
                                   atol=1e-14, rtol=0)
        self.assertLess(expectations[0], expectations[1])
        self.assertLess(expectations[1], expectations[2])

    def test_scaling_counts_is_not_an_independent_sample_bias_correction(self):
        frame = table([[1, 0], [0, 1]])
        self.assertEqual(result(frame)["i_group_venue_nats"],
                         result(frame.assign(mass=frame["mass"] * 1000))["i_group_venue_nats"])

    def test_identical_sample_design_weights_give_additive_population_slopes(self):
        rows = []
        for i in range(8):
            frame = table([[i + 1, 2], [2, 9 - i], [3, i + 2], [9 - i, 1]],
                          categories=["a", "a", "b", "b"], areas=["x", "y", "x", "x"],
                          city=f"c{i}", year=2000 + i % 2)
            rows.append(result(frame))
        outcomes = pd.DataFrame(rows)
        population = np.array([10, 14, 18, 27, 44, 60, 91, 150], dtype=float)
        design = np.column_stack((np.ones(8), np.log(population), np.arange(8) % 2))
        weights = np.sqrt(np.arange(1, 9))

        def fit(y):
            return np.linalg.lstsq(design * weights[:, None], y * weights, rcond=None)[0]

        for suffix in ("_nats", "_normalized"):
            total = fit(outcomes["i_group_venue" + suffix].to_numpy())
            for components in (FORWARD_COMPONENT_FIELDS, REVERSE_COMPONENT_FIELDS):
                slopes = [fit(outcomes[name + suffix].to_numpy()) for name in components]
                np.testing.assert_allclose(total, np.sum(slopes, axis=0), atol=1e-14, rtol=0)


class TestInputContract(unittest.TestCase):
    def test_missing_semantics_must_be_explicit(self):
        with self.assertRaises(TypeError):
            decompose_city_year_information(table([[1, 1]]), group_universe=GROUPS)
        with self.assertRaisesRegex(ValueError, "explicitly"):
            result(table([[1, 1]]), missing="impute")

    def test_missing_group_cell_is_not_implicitly_zero(self):
        with self.assertRaisesRegex(ValueError, "Missing venue-group"):
            result(table([[1, 0], [0, 1]]).iloc[1:])

    def test_invalid_mass_values(self):
        for value in (-1, np.nan, np.inf, -np.inf, "3", True, 1 + 0j, None,
                      Fraction(-1, 10 ** 400)):
            with self.subTest(value=repr(value)):
                frame = table([[1, 1]])
                frame["mass"] = frame["mass"].astype(object)
                frame.at[0, "mass"] = value
                with self.assertRaises(ValueError):
                    result(frame, missing="zero")

    def test_missing_or_invalid_keys(self):
        for key in ("city", "year", "venue", "category", "area", "group"):
            for value in (None, np.nan, np.inf, [], complex(float("inf"), 0),
                          Decimal("Infinity")):
                with self.subTest(key=key, value=repr(value)):
                    frame = table([[1, 1]])
                    frame[key] = frame[key].astype(object)
                    frame.at[0, key] = value
                    with self.assertRaises(ValueError):
                        result(frame)

    def test_invalid_universe(self):
        for groups in ((), ("low", "low"), ("low", None), ("low", np.inf),
                       ("low", []), "low", {"low", "high"}):
            with self.subTest(groups=repr(groups)):
                with self.assertRaises(ValueError):
                    result(table([[1, 1]]), groups)

    def test_undeclared_group_rejected_even_at_zero_mass(self):
        frame = table([[1, 0]])
        frame.loc[1, "group"] = "unknown"
        with self.assertRaisesRegex(ValueError, "outside"):
            result(frame)

    def test_duplicate_cells_rejected_even_at_zero_mass(self):
        frame = table([[1, 0]])
        with self.assertRaisesRegex(ValueError, "Duplicate"):
            result(pd.concat([frame, frame.iloc[[1]]]))

    def test_invalid_membership_including_zero_rows(self):
        for key in ("category", "area"):
            with self.subTest(key=key):
                frame = table([[1, 0]])
                frame.loc[1, key] = "different"
                with self.assertRaisesRegex(ValueError, "one category and one area"):
                    result(frame)

    def test_all_zero_city_rejects_whole_batch(self):
        positive = table([[1, 1]], city="positive")
        zero = table([[0, 0]], city="zero")
        with self.assertRaisesRegex(ValueError, "positive total mass"):
            result(pd.concat([positive, zero]))

    def test_empty_table_rejected(self):
        with self.assertRaisesRegex(ValueError, "nonempty"):
            result(table([[1, 1]]).iloc[:0])

    def test_missing_and_duplicate_columns(self):
        frame = table([[1, 1]])
        with self.assertRaisesRegex(ValueError, "required column"):
            result(frame.drop(columns="mass"))
        with self.assertRaisesRegex(ValueError, "unique"):
            result(pd.concat([frame, frame[["mass"]]], axis=1))

    def test_custom_key_mapping(self):
        frame = table([[1, 0], [0, 1]])
        names = ["c", "t", "j", "k", "a", "g", "m"]
        renamed = frame.set_axis(names, axis=1)
        actual = decompose_city_year_information(renamed, group_universe=GROUPS,
            missing_group_cells="error", columns=MassColumns(*names)).iloc[0]
        self.assertEqual(actual["city"], "toy")
        self.assertEqual(actual["i_group_venue_nats"], result(frame)["i_group_venue_nats"])
        with self.assertRaisesRegex(ValueError, "unique"):
            decompose_city_year_information(frame, group_universe=GROUPS,
                missing_group_cells="error", columns=MassColumns(area="category"))

    def test_overflow_and_positive_support_underflow_fail_closed(self):
        for masses, message in (([[1e308, 1e308]], "total mass"),
                                ([[1e300, 1e-300]], "underflows")):
            with self.subTest(message=message):
                with self.assertRaisesRegex(ValueError, message):
                    result(table(masses))

    def test_float_conversion_does_not_drop_positive_support(self):
        with self.assertRaisesRegex(ValueError, "underflows during float64 conversion"):
            result(table([[1, Fraction(1, 10 ** 400)]]))

    def test_smallest_representable_equal_masses_normalize(self):
        smallest = np.nextafter(0.0, 1.0)
        row = result(table([[smallest, 0], [0, smallest]]))
        self.assertEqual(row["n_groups_positive"], 2)
        self.assertAlmostEqual(row["i_group_venue_nats"], LN2)
        self.assertAlmostEqual(row["i_group_venue_normalized"], 1)

    def test_categorical_keys_do_not_create_unobserved_city_years(self):
        frame = table([[1, 0], [0, 1]])
        frame["city"] = pd.Categorical(frame["city"], categories=["toy", "unused"])
        rows = decompose_city_year_information(frame, group_universe=GROUPS,
                                              missing_group_cells="error")
        self.assertEqual(len(rows), 1)

    def test_input_not_modified(self):
        frame = table([[1, 0], [0, 1]])
        before = frame.copy(deep=True)
        result(frame)
        pd.testing.assert_frame_equal(frame, before)


if __name__ == "__main__":
    unittest.main()
