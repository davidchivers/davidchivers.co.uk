"""Pure origin-flow reconstruction helpers; no file I/O or empirical runner."""

from dataclasses import dataclass
import json
import math
from numbers import Integral, Real
from typing import Mapping


@dataclass(frozen=True)
class IncomeMass:
    group_mass: tuple[float, ...]
    known_positive_weight: float
    classified_weight: float
    unclassified_weight: float
    null_weight_entries: int
    zero_weight_entries: int
    fractionalization: float | None
    entropy_nats: float | None
    entropy_normalized: float | None
    coverage_of_known_positive_weight: float | None


def _unique_pairs(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate origin key; values must not be silently overwritten")
        result[key] = value
    return result


def _finite_sum(values):
    try:
        result = math.fsum(values)
    except OverflowError as exc:
        raise ValueError("Flow mass overflow") from exc
    if not math.isfinite(result):
        raise ValueError("Nonfinite aggregate flow mass")
    return result


def reconstruct_income_mass(
    blob: str,
    origin_group: Mapping[str, int | None],
    *,
    n_groups: int = 10,
) -> IncomeMass:
    """Classify recorded positive mass, excluding missing groups, never imputing.

    The caller must validate the lookup and map missing group codes to None.
    Null flow weights are counted but have unknown mass. Coverage is therefore
    explicitly conditional on known positive weights. An absent pair is not
    manufactured as an observed zero. Do not interpret masses as iid people.
    """
    if isinstance(n_groups, bool) or not isinstance(n_groups, Integral) or n_groups < 2:
        raise ValueError("At least two explicitly defined groups are required")
    if not isinstance(blob, str) or not blob.strip():
        raise ValueError("Unavailable flow is not an observed zero-mass object")
    try:
        flows = json.loads(blob, object_pairs_hook=_unique_pairs)
    except json.JSONDecodeError as exc:
        # Do not expose source rows or origin identifiers in error messages.
        raise ValueError("Invalid origin-flow JSON") from exc
    if not isinstance(flows, dict):
        raise ValueError("Origin-flow JSON must be an object")
    masses = [[] for _ in range(n_groups)]
    unknown = []
    null_entries = zero_entries = 0
    for origin, raw_weight in flows.items():
        if raw_weight is None:
            null_entries += 1
            continue
        if isinstance(raw_weight, bool) or not isinstance(raw_weight, Real):
            raise ValueError("Flow weight must be numeric, not boolean or string")
        weight = float(raw_weight)
        if not math.isfinite(weight) or weight < 0:
            raise ValueError("Flow weight must be finite and nonnegative")
        if weight == 0:
            zero_entries += 1
            continue
        group = origin_group.get(origin)
        if group is None:
            unknown.append(weight)
        else:
            if isinstance(group, bool) or not isinstance(group, Integral) or not 1 <= group <= n_groups:
                raise ValueError("Lookup group is invalid; explicitly normalize missing codes")
            masses[group - 1].append(weight)
    group_mass = tuple(_finite_sum(values) for values in masses)
    classified = _finite_sum(group_mass)
    unclassified = _finite_sum(unknown)
    total = _finite_sum((classified, unclassified))
    if classified > 0:
        shares = [mass / classified for mass in group_mass if mass > 0]
        entropy = -math.fsum(p * math.log(p) for p in shares)
        fractionalization = 1.0 - math.fsum(p * p for p in shares)
        normalized = entropy / math.log(n_groups)
    else:
        fractionalization = entropy = normalized = None
    return IncomeMass(
        group_mass, total, classified, unclassified, null_entries, zero_entries,
        fractionalization, entropy, normalized,
        classified / total if total > 0 else None,
    )
