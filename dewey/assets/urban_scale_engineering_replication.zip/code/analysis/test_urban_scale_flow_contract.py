"""Synthetic flow contracts only: no source-file reads."""

import math
import unittest

from urban_scale_flow_contract import reconstruct_income_mass


class FlowContractTests(unittest.TestCase):
    def test_missing_income_excluded_and_renormalized(self):
        result = reconstruct_income_mass(
            '{"origin_A": 30, "origin_B": 10, "origin_C": 60}',
            {"origin_A": 1, "origin_B": 10, "origin_C": None},
        )
        self.assertEqual(result.classified_weight, 40)
        self.assertEqual(result.unclassified_weight, 60)
        self.assertEqual(result.coverage_of_known_positive_weight, 0.4)
        self.assertAlmostEqual(result.fractionalization, 0.375)
        self.assertAlmostEqual(result.entropy_nats, -0.75 * math.log(0.75) - 0.25 * math.log(0.25))
        self.assertEqual(len(result.group_mass), 10)

    def test_unknown_origin_is_not_imputed(self):
        result = reconstruct_income_mass('{"unknown": 5}', {})
        self.assertEqual(result.unclassified_weight, 5)
        self.assertIsNone(result.fractionalization)
        self.assertIsNone(result.entropy_nats)
        self.assertEqual(result.coverage_of_known_positive_weight, 0)

    def test_null_weight_is_distinct_from_observed_zero(self):
        result = reconstruct_income_mass('{"a": null, "b": 0, "c": 3}', {"c": 2})
        self.assertEqual(result.null_weight_entries, 1)
        self.assertEqual(result.zero_weight_entries, 1)
        self.assertEqual(result.known_positive_weight, 3)
        self.assertEqual(result.fractionalization, 0)

    def test_empty_object_has_undefined_distribution(self):
        result = reconstruct_income_mass('{}', {})
        self.assertEqual(result.known_positive_weight, 0)
        self.assertIsNone(result.entropy_nats)
        self.assertIsNone(result.coverage_of_known_positive_weight)

    def test_unavailable_and_invalid_json_rejected(self):
        for blob in (None, '', ' ', 'null', '[]', '{'):
            with self.subTest(blob=blob), self.assertRaises(ValueError):
                reconstruct_income_mass(blob, {})

    def test_duplicate_origins_rejected(self):
        with self.assertRaisesRegex(ValueError, 'Duplicate'):
            reconstruct_income_mass('{"a": 2, "a": 3}', {"a": 1})

    def test_invalid_weights_rejected_without_identifiers_in_error(self):
        for value in ('-1', 'NaN', 'Infinity', 'true', '"3"', '{}', '[]'):
            with self.subTest(value=value), self.assertRaises(ValueError) as caught:
                reconstruct_income_mass('{"sensitive_key": ' + value + '}', {})
            self.assertNotIn('sensitive_key', str(caught.exception))

    def test_invalid_groups_rejected(self):
        for group in (0, -1, 11, 1.5, True, '1', float('nan')):
            with self.subTest(group=group), self.assertRaises(ValueError):
                reconstruct_income_mass('{"a": 1}', {'a': group})

    def test_scale_invariance(self):
        a = reconstruct_income_mass('{"a": 2, "b": 3}', {'a': 1, 'b': 2})
        b = reconstruct_income_mass('{"a": 200, "b": 300}', {'a': 1, 'b': 2})
        self.assertEqual(a.entropy_nats, b.entropy_nats)
        self.assertEqual(a.fractionalization, b.fractionalization)

    def test_group_universe_required(self):
        for n_groups in (1, 0, True, 2.5):
            with self.subTest(n_groups=n_groups), self.assertRaises(ValueError):
                reconstruct_income_mass('{}', {}, n_groups=n_groups)

    def test_mass_overflow_rejected(self):
        with self.assertRaisesRegex(ValueError, 'overflow'):
            reconstruct_income_mass('{"a": 1e308, "b": 1e308}', {'a': 1, 'b': 1})


if __name__ == '__main__':
    unittest.main()
