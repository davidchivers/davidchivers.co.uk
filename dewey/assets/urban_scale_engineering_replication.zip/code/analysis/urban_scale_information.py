"""Exact city-year information accounting on caller-supplied group-venue masses.

No file/network I/O, production pipeline imports, estimation or bias correction.
For deterministic venue attributes K (category) and A (destination area):
    I(G;J) = I(G;K) + I(G;A|K) + I(G;J|A,K).
Also report the reverse order, I(G;A) + I(G;K|A) + I(G;J|A,K).
Attribution to category versus area depends on order and is not causal.
All logarithms are natural. Fractionalization is a different index and is not
used here. Tests and examples use artificial masses only. Entropy scalars do
not recover group vectors; county/MSA labels do not supply precise coordinates
or neighborhood geography. This interface implies no empirical authorization.
"""
from __future__ import annotations

from collections.abc import Hashable, Sequence
from dataclasses import astuple, dataclass
import math
from numbers import Number, Real
from typing import Literal

import numpy as np
import pandas as pd


@dataclass(frozen=True)
class MassColumns:
    """Explicit input column mapping; output keys are always city and year."""

    city: str = "city"
    year: str = "year"
    venue: str = "venue"
    category: str = "category"
    area: str = "area"
    group: str = "group"
    mass: str = "mass"


INFORMATION_FIELDS = (
    "i_group_venue",
    "i_group_category",
    "i_group_area_given_category",
    "i_group_venue_given_category_area",
    "i_group_area",
    "i_group_category_given_area",
)
FORWARD_COMPONENT_FIELDS = INFORMATION_FIELDS[1:4]
REVERSE_COMPONENT_FIELDS = (INFORMATION_FIELDS[4], INFORMATION_FIELDS[5], INFORMATION_FIELDS[3])
_CANONICAL = ("city", "year", "venue", "category", "area", "group", "mass")
_NUMERICAL_TOLERANCE = 1e-12  # Floating-point QA only, never an empirical gate.


def _valid_key(value: object) -> bool:
    if not pd.api.types.is_scalar(value) or not isinstance(value, Hashable):
        return False
    if pd.isna(value):
        return False
    if isinstance(value, Number):
        try:
            return math.isfinite(abs(value))
        except (OverflowError, TypeError, ValueError):
            return False
    return True


def _validate(
    table: pd.DataFrame,
    group_universe: Sequence[Hashable],
    missing_group_cells: str,
    columns: MassColumns,
) -> tuple[pd.DataFrame, tuple[Hashable, ...]]:
    if missing_group_cells not in ("error", "zero"):
        raise ValueError("missing_group_cells must explicitly be 'error' or 'zero'")
    if not isinstance(group_universe, Sequence) or isinstance(group_universe, str):
        raise ValueError("group_universe must be a nonempty ordered sequence")
    groups = tuple(group_universe)
    if not groups or not all(_valid_key(group) for group in groups):
        raise ValueError("group_universe must contain nonmissing scalar keys")
    if len(set(groups)) != len(groups):
        raise ValueError("group_universe contains duplicate keys")
    if not isinstance(table, pd.DataFrame) or table.empty:
        raise ValueError("A nonempty pandas mass table is required")
    if not isinstance(columns, MassColumns):
        raise ValueError("columns must be a MassColumns mapping")
    names = astuple(columns)
    if not all(isinstance(name, str) and name for name in names):
        raise ValueError("Mapped column names must be nonempty strings")
    if len(set(names)) != len(names) or not table.columns.is_unique:
        raise ValueError("Input and mapped column names must be unique")
    if not set(names).issubset(table.columns):
        raise ValueError("Mass table is missing a required column")
    frame = table.loc[:, list(names)].copy()
    frame.columns = list(_CANONICAL)
    for key in _CANONICAL[:-1]:
        if not all(_valid_key(value) for value in frame[key]):
            raise ValueError("All keys must be nonmissing, finite, hashable scalars")
    if not frame["group"].isin(groups).all():
        raise ValueError("Table contains a group outside the declared universe")
    if not all(
        isinstance(value, Real) and not isinstance(value, (bool, np.bool_))
        for value in frame["mass"]
    ):
        raise ValueError("Masses must be real numeric values, not strings or booleans")
    if any(value < 0 for value in frame["mass"]):
        raise ValueError("Masses must be finite and nonnegative; missing is not zero")
    try:
        mass = frame["mass"].to_numpy(dtype=np.float64)
    except (OverflowError, TypeError, ValueError) as exc:
        raise ValueError("Masses must be representable as float64") from exc
    if not np.isfinite(mass).all() or (mass < 0).any():
        raise ValueError("Masses must be finite and nonnegative; missing is not zero")
    originally_positive = np.array([value > 0 for value in frame["mass"]])
    if (originally_positive & (mass == 0)).any():
        raise ValueError("Positive mass underflows during float64 conversion")
    frame["mass"] = mass

    venue_key = ["city", "year", "venue"]
    membership = frame.groupby(venue_key, sort=False, observed=True)[
        ["category", "area"]
    ].nunique()
    if membership.gt(1).any().any():
        raise ValueError("Each city-year venue must have one category and one area")
    if frame.duplicated(venue_key + ["group"]).any():
        raise ValueError("Duplicate city-year-venue-group cells are not aggregated")
    if missing_group_cells == "error":
        counts = frame.groupby(venue_key, sort=False, observed=True).size()
        if counts.ne(len(groups)).any():
            raise ValueError("Missing venue-group cells require explicit zero semantics")
    return frame, groups


def _conditional_logs(joint: np.ndarray) -> np.ndarray:
    """Row-conditional log probabilities; unused zero cells contribute zero."""
    row_mass = joint.sum(axis=1, keepdims=True)
    conditional = np.zeros_like(joint)
    np.divide(joint, row_mass, out=conditional, where=row_mass > 0)
    logs = np.zeros_like(joint)
    np.log(conditional, out=logs, where=joint > 0)
    return logs


def _information(child: np.ndarray, parent: np.ndarray) -> float:
    """Weighted KL against the corresponding parent distribution for each row."""
    terms = child * (_conditional_logs(child) - _conditional_logs(parent))
    return math.fsum(terms.ravel())


def _conditional_entropy(joint: np.ndarray) -> float:
    return -math.fsum((joint * _conditional_logs(joint)).ravel())


def _aggregate(joint: np.ndarray, codes: np.ndarray) -> np.ndarray:
    result = np.zeros((int(codes.max()) + 1, joint.shape[1]), dtype=np.float64)
    np.add.at(result, codes, joint)
    return result


def _city_result(frame: pd.DataFrame, groups: tuple[Hashable, ...]) -> dict:
    masses = frame["mass"].to_numpy(dtype=np.float64)
    if not (masses > 0).any():
        raise ValueError("Every represented city-year must have positive total mass")
    try:
        total_mass = math.fsum(masses)
    except OverflowError as exc:
        raise ValueError("City-year total mass exceeds float64 range") from exc
    scaled = masses / masses.max()
    probabilities = scaled / math.fsum(scaled)
    if ((masses > 0) & (probabilities == 0)).any():
        raise ValueError("Positive mass underflows during normalization")

    venues = frame.drop_duplicates("venue")
    venue_codes, _ = pd.factorize(frame["venue"], sort=False)
    group_index = {group: index for index, group in enumerate(groups)}
    group_codes = frame["group"].map(group_index).to_numpy(dtype=int)
    joint = np.zeros((len(venues), len(groups)), dtype=np.float64)
    joint[venue_codes, group_codes] = probabilities
    category_codes, _ = pd.factorize(venues["category"], sort=False)
    area_label_codes, _ = pd.factorize(venues["area"], sort=False)
    # Area labels can recur across categories; conditioning requires the pair.
    area_codes, _ = pd.factorize(
        pd.MultiIndex.from_frame(venues[["category", "area"]]), sort=False
    )
    category = _aggregate(joint, category_codes)
    category_area = _aggregate(joint, area_codes)
    area = _aggregate(joint, area_label_codes)
    group_mass = joint.sum(axis=0, keepdims=True)
    # Each pair has one parent category and one parent area. Neither marginal
    # partition must be nested in the other.
    parent_category = np.empty(len(category_area), dtype=int)
    parent_area = np.empty(len(category_area), dtype=int)
    parent_category[area_codes] = category_codes
    parent_area[area_codes] = area_label_codes
    raw = (
        _information(joint, np.broadcast_to(group_mass, joint.shape)),
        _information(category, np.broadcast_to(group_mass, category.shape)),
        _information(category_area, category[parent_category]),
        _information(joint, category_area[area_codes]),
        _information(area, np.broadcast_to(group_mass, area.shape)),
        _information(category_area, area[parent_area]),
    )
    h_group = _conditional_entropy(group_mass)
    h_category = _conditional_entropy(category)
    h_category_area = _conditional_entropy(category_area)
    h_area = _conditional_entropy(area)
    h_venue = _conditional_entropy(joint)
    entropy_check = (h_group - h_venue, h_group - h_category,
                     h_category - h_category_area, h_category_area - h_venue,
                     h_group - h_area, h_area - h_category_area)
    residual = raw[0] - math.fsum(raw[1:4])
    reverse_residual = raw[0] - math.fsum((raw[4], raw[5], raw[3]))
    probability_sum = math.fsum(joint.ravel())
    tolerance = _NUMERICAL_TOLERANCE
    if abs(probability_sum - 1) > tolerance:
        raise ArithmeticError("City-year probabilities do not sum to one")
    if not all(math.isfinite(value) for value in (*raw, h_group)):
        raise ArithmeticError("Nonfinite information calculation")
    if any(value < -tolerance or value > h_group + tolerance for value in raw):
        raise ArithmeticError("Information is outside entropy bounds")
    if max(abs(residual), abs(reverse_residual)) > tolerance or any(
        abs(kl - entropy) > tolerance for kl, entropy in zip(raw, entropy_check)
    ):
        raise ArithmeticError("Information chain rule or entropy cross-check failed")

    defined = h_group > 0
    normalized = tuple(value / h_group for value in raw) if defined else (math.nan,) * len(raw)
    normalized_residual = (
        normalized[0] - math.fsum(normalized[1:4]) if defined else math.nan
    )
    reverse_normalized_residual = (
        normalized[0] - math.fsum((normalized[4], normalized[5], normalized[3]))
        if defined else math.nan
    )
    if defined and (
        not all(math.isfinite(value) and -tolerance <= value <= 1 + tolerance
                for value in normalized)
        or max(abs(normalized_residual), abs(reverse_normalized_residual)) > tolerance
    ):
        raise ArithmeticError("Normalized information bounds or additivity failed")

    present = group_mass.ravel() > 0
    result = {
        "city": frame["city"].iloc[0],
        "year": frame["year"].iloc[0],
        "group_universe": groups,
        "absent_groups": tuple(group for group, exists in zip(groups, present) if not exists),
        "n_groups_declared": len(groups),
        "n_groups_positive": int(present.sum()),
        "n_venues_declared": len(venues),
        "n_venues_positive": int((joint.sum(axis=1) > 0).sum()),
        "n_missing_cells_filled": joint.size - len(frame),
        "n_explicit_zero_cells": int((masses == 0).sum()),
        "total_mass": total_mass,
        "probability_sum": probability_sum,
        "probability_sum_residual": probability_sum - 1,
        "h_group_nats": h_group,
        "h_group_given_category_nats": h_category,
        "h_group_given_category_area_nats": h_category_area,
        "h_group_given_area_nats": h_area,
        "h_group_given_venue_nats": h_venue,
        "additive_residual_nats": residual,
        "reverse_additive_residual_nats": reverse_residual,
        "normalization_defined": defined,
        "normalization_undefined_reason": None if defined else "zero_group_entropy",
        "additive_residual_normalized": normalized_residual,
        "reverse_additive_residual_normalized": reverse_normalized_residual,
    }
    result.update({name + "_nats": value for name, value in zip(INFORMATION_FIELDS, raw)})
    result.update({name + "_normalized": value
                   for name, value in zip(INFORMATION_FIELDS, normalized)})
    return result


def decompose_city_year_information(
    table: pd.DataFrame,
    *,
    group_universe: Sequence[Hashable],
    missing_group_cells: Literal["error", "zero"],
    columns: MassColumns = MassColumns(),
) -> pd.DataFrame:
    """Return one decomposition per city-year, without modifying the input.

    Each unique city-year-venue-group row supplies joint mass, NOT a diversity
    scalar or an automatically equal-weighted venue share. Group keys must use
    the same declared, exhaustive definition throughout. Explicit zeros are
    structural zeros. 'error' requires every declared group at every venue;
    'zero' asserts omitted cells are known zeros, never missing/suppressed data.
    Missing values/keys are always errors. Entirely omitted venues/cities cannot
    be discovered: the caller must supply every intended venue, including zero
    rows when necessary, and account for excluded/unknown demographic mass.

    Membership J -> (K,A) is validated within city-year, including zero rows.
    Area keys must identify the same geography across categories; disjoint
    category-specific areas are permitted when they have distinct keys. Both
    ordering conventions are returned. Their total and within-pair component
    agree, but category versus area attribution is order-dependent, not causal.
    All-zero cities fail; zero venues and absent groups are reported without
    pseudo-counts. Normalized
    quantities divide by city-year H(G), NOT log(number of groups); they and
    their residual are NaN with an explicit reason when H(G)=0. Raw numerical
    residuals and tiny floating-point negatives are retained, not clipped.

    Numerical work is float64, exact accounting up to rounding. Nonrepresentable
    totals and loss of positive support through underflow fail closed. The
    in-memory workspace is O(venues * declared groups) per city-year. This is
    not a production adapter or a disclosure-reviewed export function. Annual
    masses do not establish integer independent observations or sample sizes.
    """
    frame, groups = _validate(table, group_universe, missing_group_cells, columns)
    records = [_city_result(city, groups) for _, city in frame.groupby(
        ["city", "year"], sort=False, observed=True
    )]
    return pd.DataFrame.from_records(records)
