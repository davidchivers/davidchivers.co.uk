"""Independent artificial-file audit. Never discovers or reads empirical inputs.

Run: python -B -m unittest discover -s code/analysis -p test_urban_scale_adapter_independent.py -v
All reported defects have normal regression tests after main's fixes.
"""

from copy import deepcopy
import hashlib
import json
import math
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

import pyarrow as pa
import pyarrow.parquet as pq

import run_urban_scale_engineering_pilot as adapter


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def scalar_metrics(masses, total):
    classified = sum(masses)
    if not classified:
        return (None, None, None, 0.0 if total else None)
    probabilities = [value / classified for value in masses if value]
    entropy = -sum(value * math.log(value) for value in probabilities)
    return (1 - sum(value ** 2 for value in probabilities), entropy,
            entropy / math.log(10), classified / total)


def direct_information(vectors, partition):
    """Direct joint KL of group versus a declared venue partition."""
    totals = [sum(vector[g] for vector in vectors) for g in range(3)]
    total = sum(totals)
    cells = {}
    for key, vector in zip(partition, vectors):
        target = cells.setdefault(key, [0.0] * 3)
        for g, value in enumerate(vector):
            target[g] += value
    return sum(value / total * math.log(value * total / (sum(cell) * totals[g]))
               for cell in cells.values() for g, value in enumerate(cell) if value)


class IndependentAdapterTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix="urban_adapter_independent_")
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.counter = 0
        self.origins = [f"{i:012d}" for i in range(1, 8)]
        self.vectors = [(6, 2, 1), (1, 7, 3), (4, 4, 0), (0, 8, 2)]
        self.lookup = [dict(cbg=self.origins[i], nat_decile_tdw=tdw,
                            nat_decile_nhgis=tdw, nat_decile_strict=strict)
                       for i, (tdw, strict) in enumerate(((1, 1), (2, None), (3, 2),
                                                         (None, None)))]
        self.flow = []
        self.poi = []
        for i, vector in enumerate(self.vectors):
            row = dict(ID_STORE=f"artificial-venue-{i}", MSA_CODE="12345",
                       combined_category="artificial-combined")
            weights = dict(zip(self.origins[:3], vector))
            weights.update({self.origins[3]: 1, self.origins[4]: 2,
                            self.origins[5]: None, self.origins[6]: 0})
            self.flow.append(dict(row, cbg_visits_json=json.dumps(weights)))
            poi = dict(row, year=2019, SUB_CATEGORY="K" + str(i // 2),
                       destination_county="01001" if i % 2 else "01003",
                       total_origin_visit_weight=float(sum(vector) + 3))
            for variant, masses in (("tdw", vector), ("strict", (vector[0], vector[2]))):
                for prefix, value in zip(adapter.METRICS,
                                         scalar_metrics(masses, sum(vector) + 3)):
                    poi[f"{prefix}_{variant}"] = value
            self.poi.append(poi)

    def sources(self, flow=None, poi=None, lookup=None):
        self.counter += 1
        folder = self.root / str(self.counter)
        folder.mkdir()
        paths = {}
        for role, rows in (("flow", self.flow if flow is None else flow),
                           ("poi", self.poi if poi is None else poi),
                           ("lookup", self.lookup if lookup is None else lookup)):
            paths[role] = folder / (role + ".parquet")
            pq.write_table(pa.Table.from_pylist(rows), paths[role], row_group_size=1)
        return paths, {role: digest(path) for role, path in paths.items()}, folder / "out"

    def run_sources(self, paths, hashes, out, **settings):
        options = dict(source_kind="synthetic_fixture", acknowledge_local_processing=True,
                       sample_modulus=1, batch_size=1)
        options.update(settings)
        receipt_path = adapter.execute_pilot(paths, hashes, out, **options)
        return (json.loads(receipt_path.read_text()),
                json.loads((out / "private_area_outcomes.json").read_text()))

    def reject(self, sources, **settings):
        paths, hashes, out = sources
        with self.assertRaises(adapter.PilotError):
            self.run_sources(paths, hashes, out, **settings)
        self.assertFalse((out / "private_area_outcomes.json").exists())
        receipt = json.loads((out / "private_execution_receipt.json").read_text())
        self.assertEqual(receipt["status"], "failed_no_decomposition_release")
        self.assertFalse(receipt["public_release_authorized"])
        self.assertNotIn(str(self.root), json.dumps(receipt))
        self.assertEqual(hashes, {role: digest(path) for role, path in paths.items()})
        return receipt

    def test_independent_kl_both_orders_variants_and_mass_ledger(self):
        paths, hashes, out = self.sources()
        receipt, outcomes = self.run_sources(paths, hashes, out)
        self.assertEqual(hashes, {role: digest(path) for role, path in paths.items()})
        self.assertEqual(len(outcomes), 2)
        self.assertEqual(receipt["outcome_sha256"], digest(out / "private_area_outcomes.json"))
        self.assertEqual(len(receipt["execution_sha256"]), 5)
        self.assertFalse(receipt["public_release_authorized"])
        self.assertEqual(receipt["status"], "completed_engineering_only")
        categories = [row["SUB_CATEGORY"] for row in self.poi]
        areas = [row["destination_county"] for row in self.poi]
        for outcome in outcomes:
            variant = outcome["variant"]
            vectors = self.vectors if variant == "tdw" else [(x, z, 0) for x, y, z in self.vectors]
            venue = direct_information(vectors, list(range(4)))
            category = direct_information(vectors, categories)
            area = direct_information(vectors, areas)
            pair = direct_information(vectors, list(zip(categories, areas)))
            expected = dict(i_group_venue_nats=venue, i_group_category_nats=category,
                            i_group_area_given_category_nats=pair - category,
                            i_group_venue_given_category_area_nats=venue - pair,
                            i_group_area_nats=area, i_group_category_given_area_nats=pair - area)
            for key, value in expected.items():
                self.assertAlmostEqual(outcome[key], value, places=13)
                self.assertAlmostEqual(outcome[key.replace("_nats", "_normalized")],
                                       value / outcome["h_group_nats"], places=13)
            support = receipt["diagnostics"]["variant_support"][variant]
            self.assertEqual(support["known_positive_weight"], 50)
            self.assertEqual(support["classified_weight"], sum(map(sum, vectors)))
            self.assertEqual(support["null_weight_entries"], 4)
            self.assertGreaterEqual(support["zero_weight_entries"], 4)
            self.assertEqual(support["retained_venues"], 4)

    def test_reordering_and_batching_do_not_change_outcomes(self):
        _, first = self.run_sources(*self.sources())
        _, second = self.run_sources(*self.sources(flow=self.flow[::-1],
                                                   poi=self.poi[1:] + self.poi[:1],
                                                   lookup=self.lookup[::-1]), batch_size=3)
        self.assertEqual(first, second)

    def test_unselected_roster_and_metadata_are_still_gates(self):
        bucket = int.from_bytes(hashlib.sha256(self.flow[0]["ID_STORE"].encode()).digest()[:8], "big") % 2
        index = next(i for i, row in enumerate(self.flow)
                     if not adapter.selected_id(row["ID_STORE"], 2, bucket))
        for change in ("id", "city", "combined"):
            with self.subTest(change=change):
                rows = deepcopy(self.flow)
                rows[index][{"id": "ID_STORE", "city": "MSA_CODE",
                             "combined": "combined_category"}[change]] = {
                                 "id": "artificial-extra", "city": "54321", "combined": "other"}[change]
                self.reject(self.sources(flow=rows), sample_modulus=2, sample_bucket=bucket)

    def test_cross_batch_duplicates_each_source(self):
        for role in ("flow", "poi", "lookup"):
            with self.subTest(role=role):
                rows = deepcopy(getattr(self, role))
                rows.append(rows[0])
                self.reject(self.sources(**{role: rows}))

    def test_scalar_and_definedness_mismatches_stop_every_outcome(self):
        for name in ["total_origin_visit_weight"] + [f"{metric}_{variant}"
                     for variant in adapter.VARIANTS for metric in adapter.METRICS]:
            for missing in (False, True):
                with self.subTest(metric=name, missing=missing):
                    rows = deepcopy(self.poi)
                    rows[0][name] = None if missing else rows[0][name] + 0.01
                    self.reject(self.sources(poi=rows))

    def test_missingness_exclusion_priority_and_undefined_city(self):
        rows = deepcopy(self.poi)
        flows = deepcopy(self.flow)
        rows[0].update(MSA_CODE=None, destination_county=None, SUB_CATEGORY=None)
        flows[0]["MSA_CODE"] = None
        rows[1].update(destination_county=None, SUB_CATEGORY=None)
        rows[2]["SUB_CATEGORY"] = None
        for variant in adapter.VARIANTS:
            columns = dict(zip(adapter.METRICS, scalar_metrics((8,), 10)))
            for name, value in columns.items():
                rows[3][f"{name}_{variant}"] = value
        rows[3]["total_origin_visit_weight"] = 10.0
        flows[3]["cbg_visits_json"] = json.dumps({self.origins[0]: 8, self.origins[4]: 2})
        receipt, outcomes = self.run_sources(*self.sources(flow=flows, poi=rows))
        for outcome in outcomes:
            self.assertFalse(outcome["normalization_defined"])
            self.assertIsNone(outcome["i_group_venue_normalized"])
        for support in receipt["diagnostics"]["variant_support"].values():
            self.assertEqual(support["disjoint_exclusions"], {
                "missing_recorded_area": 1, "missing_destination_county": 1, "missing_subcategory": 1})
            self.assertEqual(support["overlapping_exclusion_flags"]["missing_subcategory"], 3)

    def test_all_unknown_income_has_no_outcome_not_zero(self):
        lookup = deepcopy(self.lookup)
        for row in lookup:
            row.update(nat_decile_tdw=None, nat_decile_nhgis=None, nat_decile_strict=None)
        pois = deepcopy(self.poi)
        for row in pois:
            for variant in adapter.VARIANTS:
                for prefix, value in zip(adapter.METRICS, (None, None, None, 0.0)):
                    row[f"{prefix}_{variant}"] = value
        receipt, outcomes = self.run_sources(*self.sources(poi=pois, lookup=lookup))
        self.assertEqual(outcomes, [])
        self.assertEqual(receipt["outcome_availability"], "no_classified_geographic_support")
        for support in receipt["diagnostics"]["variant_support"].values():
            self.assertEqual(support["disjoint_exclusions"], {"no_classified_mass": 4})

    def test_group_alias_invalid_group_and_caps_fail_closed(self):
        for value in (0, 11, True):
            with self.subTest(value=value):
                lookup = deepcopy(self.lookup)
                lookup[0]["nat_decile_tdw"] = value
                lookup[0]["nat_decile_nhgis"] = value
                # Homogeneous Arrow typing is needed for the boolean counterexample.
                if value is True:
                    for row in lookup:
                        row["nat_decile_tdw"] = row["nat_decile_nhgis"] = True
                self.reject(self.sources(lookup=lookup))
        lookup = deepcopy(self.lookup)
        lookup[0]["nat_decile_nhgis"] = 2
        self.reject(self.sources(lookup=lookup))
        self.reject(self.sources(), max_lookup_rows=3)
        self.reject(self.sources(), max_selected_venues=3)

    def test_malformed_flows_redacted_and_no_outcomes(self):
        for blob in (None, "", "[]", '{"artificial-secret": -1}',
                     '{"artificial-secret": NaN}', '{"artificial-secret": true}',
                     '{"artificial-secret": 1, "artificial-secret": 2}',
                     '{"artificial-secret": "bad"}', '{"artificial-secret":'):
            with self.subTest(case=type(blob).__name__):
                rows = deepcopy(self.flow)
                rows[0]["cbg_visits_json"] = blob
                receipt = self.reject(self.sources(flow=rows))
                self.assertNotIn("artificial-secret", json.dumps(receipt))

    def test_hash_precedes_row_reads_and_preserves_input_bytes(self):
        paths, hashes, out = self.sources()
        hashes["flow"] = "0" * 64
        with patch.object(adapter, "_rows", side_effect=AssertionError("must not read rows")):
            with self.assertRaises(adapter.PilotError):
                self.run_sources(paths, hashes, out)
        receipt = json.loads((out / "private_execution_receipt.json").read_text())
        self.assertEqual(receipt["diagnostics"]["lookup_rows"], 0)
        self.assertFalse((out / "private_area_outcomes.json").exists())

    def test_ordinary_input_change_withholds_outcomes(self):
        sources = self.sources()
        original = adapter._decompose
        def change_then_decompose(con):
            result = original(con)
            path = sources[0]["flow"]
            path.touch()
            # Set a distinct mtime even on filesystems with coarse timestamp resolution.
            import os
            stat = path.stat()
            os.utime(path, ns=(stat.st_atime_ns, stat.st_mtime_ns + 2000000000))
            return result
        with patch.object(adapter, "_decompose", side_effect=change_then_decompose):
            receipt = self.reject(sources)
        self.assertIn("mtime", receipt["error"])

    def test_code_fingerprint_change_withholds_outcomes(self):
        original = adapter.sha256
        calls = {}
        def changed_hash(path):
            calls[path] = calls.get(path, 0) + 1
            if path == adapter.EXECUTION_FILES[0] and calls[path] > 1:
                return "0" * 64
            return original(path)
        with patch.object(adapter, "sha256", side_effect=changed_hash):
            receipt = self.reject(self.sources())
        self.assertIn("Execution source changed", receipt["error"])

    def test_existing_output_not_overwritten(self):
        paths, hashes, out = self.sources()
        self.run_sources(paths, hashes, out)
        before = digest(out / "private_execution_receipt.json")
        with self.assertRaises(adapter.PilotError):
            self.run_sources(paths, hashes, out)
        self.assertEqual(before, digest(out / "private_execution_receipt.json"))

    def test_preflight_source_path_errors_are_redacted(self):
        paths, hashes, out = self.sources()
        paths["flow"] = self.root / "artificial-private-marker" / "missing.parquet"
        try:
            self.run_sources(paths, hashes, out)
        except Exception as exc:
            # Do not echo the path-bearing exception into the test log.
            redacted = isinstance(exc, adapter.PilotError) and "artificial-private-marker" not in str(exc)
            self.assertTrue(redacted, "preflight error is not a redacted PilotError")
        else:
            self.fail("missing input was accepted")

    def test_extreme_scalar_mismatch_still_writes_failure_receipt(self):
        # Both sides finite; their difference overflows. No large fixture needed.
        flow = deepcopy(self.flow[:1])
        flow[0]["cbg_visits_json"] = json.dumps({self.origins[0]: 1e308})
        poi = deepcopy(self.poi[:1])
        poi[0]["total_origin_visit_weight"] = -1e308
        for variant in adapter.VARIANTS:
            for name, value in zip(adapter.METRICS, scalar_metrics((1e308,), 1e308)):
                poi[0][f"{name}_{variant}"] = value
        paths, hashes, out = self.sources(flow=flow, poi=poi)
        try:
            self.run_sources(paths, hashes, out)
        except Exception as exc:
            correct_type = isinstance(exc, adapter.PilotError)
        else:
            correct_type = False
        try:
            receipt = json.loads((out / "private_execution_receipt.json").read_text())
            valid_receipt = receipt["status"] == "failed_no_decomposition_release"
        except (OSError, ValueError, KeyError):
            valid_receipt = False
        self.assertTrue(correct_type and valid_receipt,
                        "scalar overflow masks the gate error and corrupts its receipt")

    def test_output_parent_error_is_redacted(self):
        paths, hashes, out = self.sources()
        # A regular synthetic fixture file cannot be an output parent directory.
        invalid_output = paths["flow"] / "artificial-output-marker"
        try:
            self.run_sources(paths, hashes, invalid_output)
        except Exception as exc:
            redacted = isinstance(exc, adapter.PilotError) and str(self.root) not in str(exc)
            self.assertTrue(redacted, "output filesystem error is not a redacted PilotError")
        else:
            self.fail("regular input file was accepted as output parent")

    def test_json_nonfinite_serialization_does_not_create_partial_output(self):
        out = self.root / "artificial-json-output.json"
        with self.assertRaises(adapter.PilotError):
            adapter._write_json(out, {"artificial_metric": math.inf})
        self.assertFalse(out.exists())

    def test_json_io_error_redacted_and_exclusive_output_preserved(self):
        paths, hashes, out = self.sources()
        try:
            adapter._write_json(paths["flow"] / "artificial-output.json", {})
        except Exception as exc:
            redacted = isinstance(exc, adapter.PilotError) and str(self.root) not in str(exc)
            self.assertTrue(redacted, "JSON filesystem error is not a redacted PilotError")
        else:
            self.fail("regular file was accepted as JSON output parent")
        output = self.root / "artificial-exclusive.json"
        adapter._write_json(output, {"artificial_metric": 1})
        before = digest(output)
        with self.assertRaises(adapter.PilotError):
            adapter._write_json(output, {"artificial_metric": 2})
        self.assertEqual(before, digest(output))


if __name__ == "__main__":
    unittest.main()
