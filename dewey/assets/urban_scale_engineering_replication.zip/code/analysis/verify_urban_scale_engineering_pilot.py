"""Reproducible artificial-only integration check; no private input arguments."""

import argparse
from datetime import datetime, timezone
import io
import json
from pathlib import Path
import tempfile
import unittest

from run_urban_scale_engineering_pilot import EXECUTION_FILES, PROJECT, execute_pilot, selected_id, sha256
from test_urban_scale_engineering_pilot import fixture_rows, independent_information, write_fixture


TEST_NAMES = ("test_urban_scale_information", "test_urban_scale_flow_contract",
              "test_urban_scale_engineering_pilot", "test_urban_scale_adapter_independent")
FILES = (*EXECUTION_FILES, Path(__file__).resolve(),
         *(Path(__file__).with_name(name + ".py") for name in TEST_NAMES))


def write_json(path, value):
    with path.open("x", encoding="utf-8") as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write("\n")


def verify(output):
    if output.exists():
        raise ValueError("Preserve the preceding verification directory")
    output.mkdir(parents=True)
    before = {path.relative_to(PROJECT).as_posix(): sha256(path) for path in FILES}
    stream = io.StringIO()
    suite = unittest.TestSuite(unittest.defaultTestLoader.loadTestsFromName(name) for name in TEST_NAMES)
    result = unittest.TextTestRunner(stream=stream, verbosity=2).run(suite)
    (output / "synthetic_test_log.txt").write_text(stream.getvalue(), encoding="utf-8")
    if not result.wasSuccessful():
        raise ValueError("Synthetic suite failed; no completed verification receipt")
    with tempfile.TemporaryDirectory(prefix="dewey_artificial_batch_smoke_") as name:
        temporary = Path(name)
        rows = fixture_rows(10000)
        paths, hashes = write_fixture(temporary, rows)
        receipts, outcomes = [], []
        for batch_size in (17, 257):
            dest = temporary / f"run_batch_{batch_size}"
            path = execute_pilot(paths, hashes, dest, source_kind="synthetic_fixture",
                                 acknowledge_local_processing=True, sample_modulus=10,
                                 batch_size=batch_size)
            receipt = json.loads(path.read_text(encoding="utf-8"))
            receipts.append(receipt)
            outcomes.append(json.loads((dest / "private_area_outcomes.json").read_text(encoding="utf-8")))
            write_json(output / f"artificial_run_batch{batch_size}.json", receipt)
        if outcomes[0] != outcomes[1] or receipts[0]["diagnostics"] != receipts[1]["diagnostics"]:
            raise ValueError("Artificial outcomes or support differ by batch size")
        if hashes != {role: sha256(path) for role, path in paths.items()}:
            raise ValueError("Artificial source bytes changed")
        selected = [row for row in rows["flow"] if selected_id(row["ID_STORE"], 10, 0)]
        sample = {"flow": selected, "poi": rows["poi"]}
        largest_error = 0.0
        for outcome in outcomes[0]:
            expected = independent_information(sample, outcome["variant"], outcome["city"])
            for field, value in expected.items():
                error = abs(outcome[field] - value)
                largest_error = max(largest_error, error)
                if error > 1e-10:
                    raise ValueError("Artificial independent information calculation differs")
        summary = {
            "artificial_source_venues": 10000, "engineering_modulus": 10,
            "selected_artificial_venues": len(selected), "batch_sizes": [17, 257],
            "recorded_area_variant_outcomes": len(outcomes[0]),
            "elapsed_seconds": [receipt["elapsed_seconds"] for receipt in receipts],
            "outcomes_and_support_identical": True,
            "independent_max_absolute_error": largest_error,
            "artificial_input_hashes_unchanged": True,
            "temporary_artificial_files_retained": False,
            "full_volume_runtime_or_peak_memory_estimate": None,
        }
    after = {path.relative_to(PROJECT).as_posix(): sha256(path) for path in FILES}
    if before != after:
        raise ValueError("Verification source changed during execution")
    verification = {
        "verified_utc": datetime.now(timezone.utc).isoformat(),
        "scope": "artificial_files_only_not_empirical_reconstruction",
        "tests_run": result.testsRun, "tests_passed": result.wasSuccessful(),
        "synthetic_smoke": summary, "source_sha256": after,
        "test_log_sha256": sha256(output / "synthetic_test_log.txt"),
        "original_data_read": False, "new_city_size_result": False,
        "annual_flow_acs_approval": "still_pending",
    }
    write_json(output / "synthetic_verification.json", verification)
    print(json.dumps({"tests": result.testsRun, "artificial_smoke": summary,
                      "empirical_run": False}, allow_nan=False))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, required=True)
    verify(parser.parse_args().output.resolve())
