# Urban scale and income sorting: prospective implementation protocol

Date: 19 October 2026. Status: calculation implementation and synthetic tests;
empirical reconstruction not yet authorized or run under this protocol.
This is a new branch of the existing venue-variety question, not a replacement
for notes 74, 75, 89 or 91, nor a restart of a failed causal design.

## 1. Question and order of work

Do larger metropolitan areas exhibit more separation of recorded visits by
visitors' **home-area income group**, and does that association arise across
service categories, across destination areas, or across individual venues
within the same category and destination area?

First reconstruct and validate group-by-venue masses. Then establish a
consistent metropolitan population/geography reference and describe the
city-size association. Only then investigate comparable local menus and
independent product differentiation. Do not estimate co-patron preferences
from a residual or fit a structural model before these checks.

The previous venue-count pilot is not this analysis. Its units were recorded
area-category-year cells, its predictor was venue count, and it used racial
within/between diversity summaries. A correlation after area/category controls
is neither a city-population gradient nor the share caused by venue variety.

## 2. Current input contract and what was actually checked

`output/urban_scale_followup_20261019/source_schema_receipt.json` records an
executed footer/schema-only check. No row groups or individual data values
were read. Matching footer row counts do not verify a one-to-one merge.

| Existing input | Verified footer | Role and limitation |
|---|---|---|
| `poi_annual_cbg_flows_2019.parquet` | 3,526,891 rows; 4.909 GB decimal | `ID_STORE`, recorded `MSA_CODE`, `combined_category`, `cbg_visits_json`. Candidate source of annual origin-to-venue weights, not a complete observed choice set. |
| `acs2019_cbg_harmonized_2020.parquet` | 242,747 rows; 30.295 MB decimal | Origin CBG lookup, income variables and national/MSA decile labels. Does not contain an explicit origin-MSA identifier or venue coordinates. |
| `poi_indices_harmonized_2019.parquet` | 3,526,891 rows; 2.472 GB decimal | Venue ID, subcategory, recorded MSA, destination county, coverage, visits and scalar indices. Contains income entropy/fractionalization, but not the ten income-group masses/shares; no latitude/longitude. |

The three files have unchanged size/mtime across the metadata check. This is
not a new full-content hash verification. Source-file paths remain in private
execution configuration, not in a public packet.

The previous approval covers named final POI files and private summaries for
bounded checks. A separate request now names the annual-flow file and ACS
lookup for local, read-only 2019 reconstruction. Do not process their rows
until David approves and DATA_POLICY records that scope. No new acquisitions,
employee files, original weekly flows, or external-model transmission follow
from that approval.

## 3. Group definitions and retained observation universe

For the engineering pilot, use the existing `nat_decile_tdw` labels, 1-10,
with the preferred NHGIS-harmonized lookup. This reproduces the project's
existing national **CBG median-household-income** ranking; it is not a ranking
of individuals, wages, or per-capita income. The historical construction uses
unweighted CBG quantiles, not equal population groups. Keep the ACS 5-year
release ending in the mobility year: 2015-2019 ACS for 2019, as documented in
construction log 20. Do not switch the income variable or ACS wave silently.

For the substantive city comparison, a local-rank definition requires an
audited origin-CBG-to-metro map and common vintage. Existing origin-MSA decile
labels alone cannot establish that an incoming visitor is ranked against the
destination metro. Freeze one of the following before estimating:

1. Resident-based activity: origins resident in a metro, destinations visited
   by those residents, with explicit treatment of out-of-metro destinations.
2. Destination-based clientele: venues inside a metro and all retained origins,
   using national groups, or a separately constructed destination-relative
   threshold assignment applicable to all origins.

The first technical pilot is explicitly the second, using national groups and
recorded area codes. It is not the resident exposure/attitudes object and not
a definitive large-city result. Display this on every empirical output.

Rebuild observed group mass `x[g,j]` by summing valid positive origin weights
whose income group is known. Unknown CBG income is excluded from numerator
and denominator; never impute zero, the median or a group. Report excluded
known-weight mass separately from null/invalid weights whose mass is unknown.
Track strict and preferred linkage variants as a planned sensitivity, not a
post-result selection. Absent origin-venue pairs are unreported, not observed
zero visitation. The conditional distribution describes retained recorded
flows; it does not repair upstream suppression or unequal observation.

## 4. Exact decomposition

Within one city-year and one fixed retained universe, let `x[g,j]` be valid
group-by-venue mass, `T = sum(g,j) x[g,j]`, and `p[g,j] = x[g,j]/T`.
Every venue has exactly one category K and destination area A in that run.
Let H denote entropy in natural-log units (nats).

`I(G;J) = H(G) - sum(j) p[j] H(G | j)`

Category-first chain rule:

`I(G;J) = I(G;K) + I(G;A | K) + I(G;J | A,K)`.

Area-first sensitivity:

`I(G;J) = I(G;A) + I(G;K | A) + I(G;J | A,K)`.

Both totals and the final within-area/category term must agree. Attribution
between the first two terms depends on the ordering; neither is a causal
effect. An optional order-averaged allocation must be labelled an accounting
convention, not an identified contribution of geography or category.

Report raw nats and components divided by the same city-year H(G). H(G)=0
means normalized separation is undefined, not zero. Also report H(G), retained
mass, support and coverage. Do not normalize each component by a different
conditional entropy or compare different samples and call the sum exact.
Income-group composition and group thresholds can affect comparisons even
after entropy normalization.

Scalar entropy/fractionalization at each venue cannot recover this object:
two homogeneous venues may serve the same group or entirely different groups.
Their individual diversity scores are identical in both cases; the pooled
composition and between-venue separation are different. Group identities and
masses must therefore be reconstructed. Do not infer them from venue means.

## 5. Empirical stages and stop rules

### A. Bounded 2019 reconstruction, only after permission

- Hash the named inputs once, record source sizes/mtime and code/environment.
- Audit unique venue IDs in both files and unique CBG IDs in the lookup.
  Join explicitly by ID, never by row position or equal row counts.
- Compare flow and final-file recorded MSA/category metadata. Preserve and
  report conflicts; do not silently choose the convenient version.
- Reconstruct national-group masses in bounded batches. Retain detailed
  diagnostics in a new PRS directory, with inputs read-only and no raw logging.
- Reconcile total positive flow, national-group coverage, national entropy
  and fractionalization against their existing final-file counterparts on the
  same rows/variants. Use explicit absolute/relative numerical tolerances,
  record every exclusion class, and stop inference on unexplained failures.
- Compute the accounting only on verified common support. Initial A is
  destination county because that is present, not a neighbourhood or centre.
  Produce coverage diagnostics before interpreting levels or comparisons.
- A deterministic small engineering sample establishes code feasibility only;
  it is not a national estimate. Freeze any sample selection before running.

### B. City-size gradient, not available from the three files alone

Audit a fixed county-to-metro definition, distinguish metropolitan from
micropolitan codes, and acquire/verify a population denominator for that same
year and boundary. Do not substitute venue count for population or label all
933 recorded codes metropolitan areas. Freeze the sample/weights/controls
before reading gradients. Initial descriptive regression for each component:

`D[m] = alpha + beta * log(population[m]) + error[m]`.

Use the same metro sample and design matrix for the total and all components.
Then OLS component slopes add to the total slope by linearity. This is an
accounting decomposition of an association, not a mediation or causal model.
Report unweighted-metro results first and a predeclared population-weighted
sensitivity, with support, leverage and uncertainty appropriate to metro
units. Any pooled 2017-2019 specification needs year effects and dependence
across repeated metros; 2019-only is the first independent implementation.
Do not present beta as a causal effect of growing a city.

### C. Fine-area and shared-menu mechanisms

Obtain a licensed historical `ID_STORE`-to-coordinates/brand bridge and audit
its identity, date and match-selection. County-within-metro is too coarse to
establish sorting within a shared commercial centre. Freeze multiple spatial
definitions (fixed-size grids and independently defined centres) rather than
choosing the one yielding the desired gradient.

For nearby-origin/shared-menu tests, require independent venue availability,
origin/destination geography and credible travel costs. Jointly visited
venues are selected outcomes, not a feasible menu. Restricting to a chain
controls only some differentiation; it does not fix prices, hours, size or
access. Without these inputs, report descriptive conditional distributions,
not taste parameters. Aggregate home-origin records do not reveal direct
home-venue-home trips.

### D. Simulations, model and causal follow-ups

Synthetic permutations may illustrate the mechanical rise in measured
separation with smaller venue samples. Do not permute annualized weights as
independent people or treat their sum as a sample size. An empirical
finite-observation correction needs the provider's actual observation and
suppression process, effective counts, and an appropriate dependence model.

Only after A-C pass, consider a common-parameter gravity/choice model with
held-out cities. Estimate access/attractiveness/product terms before any
co-patron term. Endogenous crowd composition is not a separately identified
preference. Product/menu counterfactuals must reallocate visits and account
for capacity; dropping venues or merging labels is measurement sensitivity,
not a behavioural counterfactual.

An openings design requires credible externally driven variation, complete
nearby-network reallocation and residential/pretrend checks. Ordinary entry
is endogenous. A randomized menu/differentiation experiment would need a new
protocol, budget and ethics approvals. None is launched by this document.

## 6. Verification, disclosure and interpretation

Use independent entropy and direct-KL calculations; test category-only,
area-only, within-cell-only and mixed cases; compare both chain orders;
test relabeling and scale invariance, absent groups, invalid nesting,
duplicates, negative/nonfinite weights, and zero-entropy groups. Synthetic
tests establish calculation behavior, not source-data quality.

Detailed cell/venue results and private provenance stay in PRS. Release only
separately disclosure-reviewed aggregates: prohibit overlapping counts/means
that reveal small complements, including via differencing with earlier
releases. Do not reuse concentration bounds for a different signed component.
No public raw flows, venue group vectors, locations or origin identifiers.

Retain null gradients and all planned sensitivities. The substantive question
is whether the pattern survives measurement checks, not how to obtain a
positive coefficient. Historical correction 70a, negative equal-county
validation, failed worker-score/concentration gates and stopped causal
designs are unaffected. This work cannot identify personal income, face-to-
face contact, worker demographics, preferences, or attitude effects.
