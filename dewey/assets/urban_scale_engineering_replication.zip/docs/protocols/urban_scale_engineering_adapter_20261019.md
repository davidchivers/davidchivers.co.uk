# Urban-scale engineering adapter: prospective scope

19 October 2026. Frozen before the first adapter test. This supplements, and
does not replace, `urban_scale_information_pilot_20261019.md`.

## Purpose and authorization

Connect the existing pure flow parser and information decomposition through a
bounded, file-to-file engineering pilot. This implementation round uses only
artificial Parquet fixtures in temporary storage. No annual-flow or ACS rows
are authorized by this protocol or by a software execution flag. Their named
processing request remains unanswered. No original construction is changed.

## Fixed source and interpretation contract

- Year 2019; ACS five-year release ending in 2019; 2020 CBG geography as in the
  existing harmonized release. These are asserted provenance requirements,
  not facts inferred from a filename.
- Join `ID_STORE` by exact string in annual flow and final POI files, never by
  row order. Reject duplicate IDs in either input and duplicate `cbg` lookup
  keys. Scan the full input ID/metadata rosters even for a small pilot.
- Compare recorded `MSA_CODE` and `combined_category` in both venue inputs.
  Count missing-side IDs and conflicting metadata; any discrepancy stops all
  decomposition. Nulls are not silently matched to a real geography/category.
- Use literal final-file `SUB_CATEGORY` as K and `destination_county` as A.
  This is not the frozen 136-category comparison bridge or a fine-area menu.
  `MSA_CODE` is a recorded area code, not proof of metropolitan status.
- Reconstruct both `nat_decile_tdw` and `nat_decile_strict` separately. In the
  reviewed NHGIS builder, the preferred `tdw` slots are overwritten by the
  NHGIS values and `nat_decile_nhgis` is copied from `nat_decile_tdw`. Check
  this alias row by row when loading the lookup; never select a variant by its
  result. Null lookup groups mean unknown, not zero-income people. Other
  out-of-range labels fail instead of being silently recoded.
- Weights are recorded annual origin-flow mass, not annualized matched visits
  and not independent people. Missing income is excluded and the remaining
  positive mass renormalized. Retain known unclassified mass and null/zero
  weight counts. Absent flows are not observed zeros.

## Deterministic engineering selection and memory

The proposed empirical pilot selects IDs where the unsigned big-endian integer
formed by the first eight bytes of SHA-256 of the exact UTF-8 ID is congruent
to zero modulo 1,000. Freeze this before seeing outcomes. This is an engineering
sample, not a national or city estimate; no selection weight is introduced.
Synthetic tests may explicitly use smaller moduli or all artificial IDs.

Use Parquet batches and a disk-backed SQLite join/uniqueness index outside the
repository. Keep the small lookup in memory, with a 500,000-row hard cap, and
retain at most 20,000 selected venues. Stop if either cap is exceeded; do not
silently downsample or truncate. Decompose one recorded area and variant at a
time through the already tested information function. Do not use a successful
small artificial run as a full-volume performance forecast.

## Reconciliation and failure behavior

For every selected matched venue, compare each variant's reconstructed
fractionalization, entropy in nats, entropy divided by log(10), and national
decile coverage to the corresponding final-file columns. Compare total known
positive origin mass to `total_origin_visit_weight`, never to the annualized
matched-visit variable. Numerical tolerances are fixed at absolute 1e-8 and
relative 1e-9. A known-versus-undefined disagreement fails. Null weights still
have unknown mass even if the known positive total reconciles.

Unavailable or malformed flow objects, negative/nonfinite weights, invalid
labels, duplicate JSON origins, changed input fingerprints or unhandled schema
values fail closed. Preserve aggregate counts of scalar and metadata conflicts
in private diagnostics. Do not simply discard discrepant selected venues and
estimate on the remaining ones. Withhold every decomposition when an input or
reconciliation gate fails.

After reconciliation, explicitly account for selected rows excluded for missing
recorded area, county, subcategory, or no classified mass. Use that priority for
disjoint exclusion counts and report overlapping flags separately. A city with
no classified support has no outcome. Single-group city entropy yields an
undefined normalized outcome, never zero. Each variant has its own documented
support; this is not a fixed-support comparison between variants.

## Provenance, verification and disclosure

Require exact expected SHA-256 hashes of all three inputs before row reads;
record size/mtime before hashing and verify them after processing. This checks
ordinary concurrent changes, not a malicious writer preserving metadata.
Bind the adapter, parser, decomposition and both protocols with hashes before
and after execution. New output directories must be outside the repository;
never overwrite an old run. SQLite working tables, city outcomes and receipts
stay private. No automatic publication, release certification, network call,
regression, source discovery or path default is provided.

Tests must independently construct expected venue metrics, reorder inputs,
alter one join/metric/group at a time, exercise cross-batch duplicates and
sample invariance, and compare end-to-end output with independent artificial
information calculations. Test failure receipts, unchanged input hashes,
resource caps and redacted errors. A larger artificial smoke run establishes
batching and reproducibility only. Record actual tests and limitations in a
separate construction log without retroactively editing this protocol.
