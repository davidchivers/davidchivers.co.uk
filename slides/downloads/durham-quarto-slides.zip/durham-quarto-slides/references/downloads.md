# Optional PDF and PowerPoint downloads

Use when the user selects downloadable copies. A full review should offer this
option once, not automatically generate extra formats. For example:

> Would you like a downloadable PDF, PowerPoint, both, or neither? Generating and
> checking these can take a while, especially for a long deck or several lectures.

Existing explicit choices count; do not ask again. Continue the requested review
while a download choice is pending. Do not promise a fixed completion time without
a basis in the deck size, export method and available tools.

- Build from the current reviewed slides. Reuse an existing export only after
  verifying that it contains the same current content; do not substitute an older
  source PowerPoint after the web slides have been revised.
- Explain the PowerPoint tradeoff before choosing an export method: editable
  objects may need layout adjustments; slide images preserve the appearance but
  flatten the content. Ask when that choice is unresolved and material. Students
  can still add notes to a flattened copy. PDF is static; animations, video and
  interactive explanations remain in the HTML.
- Use the available presentation/PDF tools and their authoring guidance. Prefer
  semantic, accessible output where supported. If the chosen export is image-based,
  say so, retain useful descriptions/online links where possible, and keep the
  accessible HTML available. Do not describe a flattened copy as an editable master
  or claim accessibility checks that were not performed.
- If a download control is requested, offer only the selected, completed formats.
  For one format, use a direct **Download** link, naming the file type in its
  accessible label;
  a small **Download** menu is useful only when there are multiple formats. Keep
  it clear of content, footer, logo and navigation, and check keyboard access.
  Do not add an editing control.
- Check slide count/order, equations, diagrams, tables and links in the actual
  exported files. Confirm each browser capture displays the intended slide before
  packaging; a changed slide ID alone can precede the displayed frame. Render the
  exports and check for missing, repeated or clipped pages.
- For requested online delivery, follow [publishing.md](publishing.md). Keep stable
  file URLs and verify both the menu and real downloads. Regenerate affected copies
  after content changes so they stay in step with the web slides. Preserve binary
  PDF/PPTX bytes in Git and existing Blackboard link visibility.

Report which formats were delivered, whether PowerPoint content is editable or
flattened, and any remaining export limitations. Keep the editable source project.

## Repair a download that opens a preview

Start from the reported route: Blackboard link, HTML presentation, then its
download control. Establish whether a file is actually saved or another preview
opens. Inspect the final response after redirects. A `.pptx` suffix, HTTP 200,
`target="_blank"` or HTML `download` attribute alone does not prove a download;
the attribute is ignored for ordinary cross-origin URLs, and app behaviour varies.

Use a stable file endpoint that sends `Content-Disposition: attachment` with an
appropriate filename. Reuse the approved host where possible. For public slides
hosted on GitHub Pages, a GitHub release asset under a fixed tag and filename is
an established option; repository preview and raw-file links are not substitutes.
Follow [publishing.md](publishing.md) for updates and separate Blackboard links.
Do not add blob-fetch workarounds or change browser settings before testing the
direct attachment route.

Click the delivered link and verify the saved file's extension, size and content
or checksum against the current export. A preview opening is not success. A
new-window download may close its temporary tab without producing a download
event on the original tab; verify the newly saved file before concluding it failed.
State the environment actually tested. Desktop browser checks, a phone-sized
viewport and staff access do not establish native Blackboard app behaviour or
student permissions.

Keep one HTML link per lecture when its download works and this is the user's
preferred layout. If the embedded route still fails, use a separate direct
PowerPoint link beneath the existing HTML link when the user has authorized that
fallback. Keep the HTML link and match its visibility. If this has not been
authorized, report the tested result and offer the fallback. Do not quietly replace
HTML with PowerPoint or create duplicate uploaded copies as the first repair.

References: [HTML download behaviour](https://developer.mozilla.org/en-US/docs/Web/HTML/Reference/Elements/a#download),
[Content-Disposition](https://developer.mozilla.org/en-US/docs/Web/HTTP/Reference/Headers/Content-Disposition).
