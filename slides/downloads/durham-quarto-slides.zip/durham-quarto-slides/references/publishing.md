# Publish slides and link them from Blackboard

Use this workflow when the user requests online publishing or Blackboard delivery.
Reuse the established destination and student links where available. Resolve the
course, academic year, folder, title and visibility from the request and live UI;
ask only for details that remain ambiguous. Keep browser editing disabled in the
student release.

## Choose the destination

- For interactive HTML, use an approved website such as GitHub Pages. Publish the
  rendered HTML and required assets, and use the website URL rather than a GitHub
  repository, raw-file or commit link. Verify the actual deployed page before
  adding it to Blackboard. Public hosting requires the user's agreement that the
  material can be public; existing explicit authorization counts.
- For PowerPoint, PDF or downloadable HTML, OneDrive/SharePoint can provide a
  stable sharing link with the intended view permissions. Verify the actual file
  and link: an HTML preview or download is not proof that its interactive slides
  run. Do not describe ordinary OneDrive file sharing as a web-hosting service.
  Use the institution's available sharing options and leave sign-in/MFA to the
  user when needed.
- Use a stable filename/path. Update the existing hosted file; for a cloud file,
  retain its item and sharing link where supported and check the link after the
  update. Do not delete and recreate cloud items merely to replace their contents.
- If unlisted public hosting is requested, keep links out of public navigation
  and sitemaps and add `noindex`. Explain that this does not restrict access.
  Hiding a Blackboard item does not make its externally hosted file private.

## Add the Web Link

In Blackboard Ultra, use the plus at the intended position, then **Create → Link
→ Web Link**. Match the requested display name, enter the verified hosted or
sharing URL, and use **Open in a new window** for a full presentation view.
Preserve the user's visibility choice; if none is specified, create the item
hidden for review. When asked to place it below a PowerPoint, use that item's
insertion control and preserve its exact title if requested.

Keep the existing single HTML link when its download works and that is the user's
preferred layout. When separate downloads are requested, keep the HTML lecture link and add
**Lecture 1 - PowerPoint** immediately beneath it (and likewise for each selected
lecture). Use that HTML item's insertion control, the verified direct attachment
URL and **Open in a new window**. Match the corresponding HTML item's visibility;
do not release a hidden lecture just because its download is ready. Avoid
duplicates by inspecting existing entries first. This is also the fallback for
an unreliable embedded download, when authorized by the user.

After saving, verify the title, destination, position and visibility from the
course content list. Check the link opens correctly. Staff access alone does not
prove student permissions: use an appropriate student access check when available
and report any remaining access uncertainty. Do not unhide a review draft solely
to test it. If browser/connector access is unavailable, finish the files and give
the user the exact URL and remaining UI steps instead of claiming completion.

## Keep HTML and downloads current

For later updates, rebuild the affected HTML and selected exports, publish at
the same destinations, and leave the Blackboard items and visibility unchanged
unless asked. Reuse verified exports when their content is unchanged. A stable
link does not generate a new PowerPoint by itself: check the export matches the
current slides before publishing. Students must download again to obtain a new
copy; their existing annotated files are not updated.

For approved public GitHub hosting, use a fixed release tag and asset filename,
for example `releases/download/course-downloads/lecture_1.pptx`. The release asset
serves the file as an attachment. If the project has a publishing workflow, have
it update the release asset when regenerated exports are published and verify the
asset's size/checksum. Reuse existing automation rather than creating parallel
delivery systems. Verify the final attachment response and a real download as
well as the HTML deployment; GitHub Pages success alone does not verify release
assets. Restricted material still belongs behind the intended university access
controls, not in a public release.

Record the source, stable HTML/download URLs, export workflow and Blackboard
placement/visibility in the project README. Report native-app and student-access
checks as untested when those environments were unavailable.

References: [GitHub Pages](https://docs.github.com/en/pages/getting-started-with-github-pages/what-is-github-pages),
[Blackboard Web Links](https://help.anthology.com/blackboard/instructor/en/course-and-content-management/add-content/web-links.html),
[Microsoft file previews](https://support.microsoft.com/en-us/onedrive/file-types-supported-for-previewing-files-in-onedrive-sharepoint-and-teams).
